# Deployment Guide

## Quick start (local Docker test)

```
cp .env.example .env
# Edit .env: set DB_PASSWORD and JWT_SECRET (see comments in that file for
# how to generate strong values). OPENAI_API_KEY is optional.

docker compose up -d --build
```

This starts three containers: MySQL, the Spring Boot backend, and Caddy
(reverse proxy). Visit `http://localhost` — Caddy will serve a self-signed
cert for `localhost` (your browser will warn about it; that's expected for
local testing, not a real deployment).

Check everything's healthy:
```
docker compose ps
curl http://localhost/actuator/health
```

## Going to a real server

1. **Get a domain and point it at your server.** Add an A record for e.g.
   `api.edulinkgh.com` pointing at your server's public IP.

2. **Edit `Caddyfile`** — replace `localhost` with your real domain. Caddy
   will automatically get a real Let's Encrypt certificate the first time
   it starts, as long as port 80 is reachable from the internet (needed for
   the ACME HTTP-01 challenge) and your DNS is already pointing correctly.

3. **Set `APP_BASE_URL`** in `.env` to `https://api.edulinkgh.com` (your
   real domain) — this is used to build links like the mock payment
   checkout page.

4. **Copy the whole `edulinkgh/` folder to your server** (or better: set up
   the CI pipeline to build and push a Docker image, then pull it on the
   server — ask if you want help wiring that up once you've picked a host).

5. **Run `docker compose up -d --build`** on the server.

6. **Firewall**: only ports 80 and 443 need to be open to the internet.
   MySQL and the backend itself are not exposed — Docker Compose keeps them
   on an internal network only Caddy can reach.

## What's already wired up

- **Health checks**: `/actuator/health` (public, no auth needed — used by
  Docker's own HEALTHCHECK and any external uptime monitor)
- **Metrics**: `/actuator/prometheus` (requires authentication — Prometheus
  scrape configs need to send a valid JWT; this is deliberate, since raw
  metrics can leak internal details and shouldn't be world-readable)
- **Structured logging**: set `SPRING_PROFILES_ACTIVE=prod,json` (already
  the default in docker-compose.yml) for JSON logs any log aggregator can
  parse. Omit the `json` profile for plain readable text logs.
- **Non-root container**: the backend runs as a dedicated `edulink` user
  inside its container, not root.
- **Persistent uploads**: certificates, photos, and chat attachments are
  stored in a named Docker volume (`uploads_data`) that survives container
  rebuilds — don't remove that volume unless you mean to delete all
  uploaded files.

## What's NOT yet wired up (ask if you want these built)

- **Centralized log viewing**: logs currently go to each container's
  stdout (`docker compose logs -f backend`) — fine for a single server, but
  you'll want something like Grafana Loki, or your host's built-in log
  viewer, once you're running multiple servers or want log history/search.
- **Automated CI→CD deployment**: `.github/workflows/ci.yml` builds and
  tests on every push but does not deploy anywhere yet — see the comments
  at the bottom of that file for what a deploy job would look like once
  you've picked a hosting provider.
- **Database backups**: `docker compose down` does NOT delete the
  `mysql_data` volume, so data survives normal restarts — but there's no
  automated backup-to-offsite-storage yet. Set one up before you have real
  user data you can't afford to lose.
- **Log rotation**: Docker's default logging driver can grow unbounded on
  a long-running server. Consider setting `logging: driver: "json-file"`
  with `max-size`/`max-file` options per service in docker-compose.yml, or
  configure it at the Docker daemon level.
