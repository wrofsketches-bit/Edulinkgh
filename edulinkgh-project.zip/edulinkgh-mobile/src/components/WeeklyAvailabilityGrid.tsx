import React from 'react';
import { Text, View } from 'react-native';
import { useAppTheme } from '../theme/ThemeContext';
import { AvailabilityWindow, DayOfWeek } from '../api/types';

const DAY_ORDER: DayOfWeek[] = ['MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY', 'SATURDAY', 'SUNDAY'];
const DAY_LABELS: Record<DayOfWeek, string> = {
  MONDAY: 'Mon',
  TUESDAY: 'Tue',
  WEDNESDAY: 'Wed',
  THURSDAY: 'Thu',
  FRIDAY: 'Fri',
  SATURDAY: 'Sat',
  SUNDAY: 'Sun',
};

function formatTime(time: string): string {
  // "14:00:00" -> "2:00 PM"
  const [hourStr, minuteStr] = time.split(':');
  const hour = parseInt(hourStr, 10);
  const minute = minuteStr;
  const period = hour >= 12 ? 'PM' : 'AM';
  const hour12 = hour % 12 === 0 ? 12 : hour % 12;
  return `${hour12}:${minute} ${period}`;
}

interface Props {
  windows: AvailabilityWindow[];
  onRemove?: (id: number) => void;
}

export function WeeklyAvailabilityGrid({ windows, onRemove }: Props) {
  const { theme } = useAppTheme();

  const byDay = DAY_ORDER.map((day) => ({
    day,
    slots: windows.filter((w) => w.dayOfWeek === day).sort((a, b) => a.startTime.localeCompare(b.startTime)),
  }));

  const hasAny = windows.length > 0;

  if (!hasAny) {
    return (
      <Text style={{ color: theme.colors.textMuted }}>
        No availability set yet.
      </Text>
    );
  }

  return (
    <View style={{ gap: theme.spacing(2) }}>
      {byDay
        .filter((d) => d.slots.length > 0)
        .map(({ day, slots }) => (
          <View key={day} style={{ flexDirection: 'row', paddingVertical: theme.spacing(1.5) }}>
            <Text style={{ color: theme.colors.text, fontWeight: '700', width: 48 }}>{DAY_LABELS[day]}</Text>
            <View style={{ flex: 1, flexDirection: 'row', flexWrap: 'wrap', gap: 6 }}>
              {slots.map((slot) => (
                <View
                  key={slot.id}
                  style={{
                    flexDirection: 'row',
                    alignItems: 'center',
                    backgroundColor: theme.colors.primaryMuted,
                    borderRadius: theme.radius.pill,
                    paddingHorizontal: theme.spacing(3),
                    paddingVertical: theme.spacing(1),
                    gap: 6,
                  }}
                >
                  <Text style={{ color: theme.colors.primary, fontWeight: '600', fontSize: 13 }}>
                    {formatTime(slot.startTime)} – {formatTime(slot.endTime)}
                  </Text>
                  {onRemove ? (
                    <Text onPress={() => onRemove(slot.id)} style={{ color: theme.colors.danger, fontWeight: '800' }}>
                      ×
                    </Text>
                  ) : null}
                </View>
              ))}
            </View>
          </View>
        ))}
    </View>
  );
}
