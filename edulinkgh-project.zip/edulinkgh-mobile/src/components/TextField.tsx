import React, { useState } from 'react';
import { StyleSheet, Text, TextInput, TextInputProps, View } from 'react-native';
import { useAppTheme } from '../theme/ThemeContext';

interface TextFieldProps extends TextInputProps {
  label?: string;
  error?: string;
}

export function TextField({ label, error, style, ...rest }: TextFieldProps) {
  const { theme } = useAppTheme();
  const [focused, setFocused] = useState(false);

  return (
    <View style={{ marginBottom: theme.spacing(4) }}>
      {label ? (
        <Text style={[styles.label, { color: theme.colors.textMuted, marginBottom: theme.spacing(1.5) }]}>
          {label}
        </Text>
      ) : null}
      <TextInput
        placeholderTextColor={theme.colors.textMuted}
        onFocus={(e) => {
          setFocused(true);
          rest.onFocus?.(e);
        }}
        onBlur={(e) => {
          setFocused(false);
          rest.onBlur?.(e);
        }}
        style={[
          styles.input,
          {
            backgroundColor: theme.colors.inputBackground,
            color: theme.colors.text,
            borderRadius: theme.radius.md,
            borderColor: error ? theme.colors.danger : focused ? theme.colors.primary : 'transparent',
            paddingHorizontal: theme.spacing(4),
            paddingVertical: theme.spacing(3.25),
            fontSize: theme.fontSize.md,
          },
          style,
        ]}
        {...rest}
      />
      {error ? (
        <Text style={[styles.error, { color: theme.colors.danger, marginTop: theme.spacing(1) }]}>
          {error}
        </Text>
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  label: {
    fontSize: 13,
    fontWeight: '600',
  },
  input: {
    borderWidth: 1.5,
  },
  error: {
    fontSize: 12,
  },
});
