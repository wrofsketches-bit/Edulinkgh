import React from 'react';
import { Text, View } from 'react-native';
import { LineChart } from 'react-native-gifted-charts';
import { useAppTheme } from '../theme/ThemeContext';
import { AnalyticsDataPoint } from '../api/types';

interface Props {
  data: AnalyticsDataPoint[];
  color?: string;
  height?: number;
  suffix?: string; // e.g. " GHC" appended to point labels
}

function formatShortDate(iso: string): string {
  const d = new Date(iso);
  return d.toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
}

export function AnalyticsLineChart({ data, color, height = 180, suffix = '' }: Props) {
  const { theme } = useAppTheme();
  const lineColor = color || theme.colors.primary;

  if (data.length === 0) {
    return (
      <View style={{ height, alignItems: 'center', justifyContent: 'center' }}>
        <Text style={{ color: theme.colors.textMuted }}>No data yet for this period.</Text>
      </View>
    );
  }

  // Thin out x-axis labels for readability — showing every single day's
  // label on a 30-day chart would overlap illegibly, so only label roughly
  // every 5th point and leave the rest blank (the line/points still render
  // for every day, just unlabeled).
  const labelInterval = Math.max(1, Math.ceil(data.length / 6));

  const chartData = data.map((point, index) => ({
    value: point.value,
    label: index % labelInterval === 0 ? formatShortDate(point.date) : '',
    dataPointText: suffix ? `${point.value}${suffix}` : undefined,
  }));

  return (
    <LineChart
      data={chartData}
      height={height}
      color={lineColor}
      thickness={2.5}
      startFillColor={lineColor}
      startOpacity={0.25}
      endOpacity={0.02}
      areaChart
      curved
      hideRules
      xAxisColor={theme.colors.border}
      yAxisColor={theme.colors.border}
      xAxisLabelTextStyle={{ color: theme.colors.textMuted, fontSize: 10 }}
      yAxisTextStyle={{ color: theme.colors.textMuted, fontSize: 10 }}
      dataPointsColor={lineColor}
      dataPointsRadius={3}
      noOfSections={3}
      initialSpacing={12}
      spacing={Math.max(28, 280 / data.length)}
    />
  );
}
