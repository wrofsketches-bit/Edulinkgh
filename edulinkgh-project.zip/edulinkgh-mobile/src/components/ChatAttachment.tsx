import React from 'react';
import { Image, Linking, Pressable, Text, View } from 'react-native';
import { API_BASE_URL } from '../api/client';
import { useAppTheme } from '../theme/ThemeContext';

interface Props {
  url: string;
  fileName?: string | null;
  mimeType?: string | null;
  isMine: boolean;
}

export function ChatAttachment({ url, fileName, mimeType, isMine }: Props) {
  const { theme } = useAppTheme();
  const fullUrl = url.startsWith('http') ? url : `${API_BASE_URL}${url}`;
  const isImage = (mimeType || '').startsWith('image/');

  if (isImage) {
    return (
      <Pressable onPress={() => Linking.openURL(fullUrl)}>
        <Image
          source={{ uri: fullUrl }}
          style={{ width: 200, height: 150, borderRadius: theme.radius.md, marginBottom: 4 }}
          resizeMode="cover"
        />
      </Pressable>
    );
  }

  return (
    <Pressable
      onPress={() => Linking.openURL(fullUrl)}
      style={{
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: isMine ? 'rgba(255,255,255,0.15)' : theme.colors.surface,
        borderRadius: theme.radius.md,
        padding: theme.spacing(3),
        marginBottom: 4,
        gap: 8,
      }}
    >
      <Text style={{ fontSize: 20 }}>📎</Text>
      <Text
        numberOfLines={1}
        style={{ color: isMine ? theme.colors.textInverse : theme.colors.text, flexShrink: 1, fontWeight: '600' }}
      >
        {fileName || 'Attachment'}
      </Text>
    </Pressable>
  );
}
