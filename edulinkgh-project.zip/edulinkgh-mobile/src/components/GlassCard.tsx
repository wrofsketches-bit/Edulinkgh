import React from 'react';
import { StyleSheet, View, ViewProps } from 'react-native';
import { useAppTheme } from '../theme/ThemeContext';

interface GlassCardProps extends ViewProps {
  padded?: boolean;
}

/**
 * A soft, translucent "glass" card. On native this is approximated with
 * semi-transparent surface color + subtle border + shadow, since true
 * backdrop-blur isn't reliably available across RN/Expo without extra
 * native deps (expo-blur could be layered in later for a stronger effect).
 */
export function GlassCard({ style, padded = true, children, ...rest }: GlassCardProps) {
  const { theme } = useAppTheme();
  return (
    <View
      style={[
        styles.base,
        {
          backgroundColor: theme.colors.glass,
          borderColor: theme.colors.glassBorder,
          borderRadius: theme.radius.lg,
          padding: padded ? theme.spacing(5) : 0,
          shadowColor: theme.mode === 'dark' ? '#000' : theme.colors.primary,
        },
        style,
      ]}
      {...rest}
    >
      {children}
    </View>
  );
}

const styles = StyleSheet.create({
  base: {
    borderWidth: 1,
    shadowOpacity: 0.12,
    shadowRadius: 20,
    shadowOffset: { width: 0, height: 8 },
    elevation: 3,
  },
});
