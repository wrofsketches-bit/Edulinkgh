import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { useAppTheme } from '../theme/ThemeContext';

type Tone = 'success' | 'warning' | 'danger' | 'neutral' | 'primary';

export function Badge({ label, tone = 'neutral' }: { label: string; tone?: Tone }) {
  const { theme } = useAppTheme();

  const toneColors: Record<Tone, { bg: string; fg: string }> = {
    success: { bg: theme.mode === 'dark' ? 'rgba(52,211,153,0.16)' : '#DCFCE7', fg: theme.colors.success },
    warning: { bg: theme.mode === 'dark' ? 'rgba(251,191,36,0.16)' : '#FEF3C7', fg: theme.colors.warning },
    danger: { bg: theme.mode === 'dark' ? 'rgba(248,113,113,0.16)' : '#FEE2E2', fg: theme.colors.danger },
    primary: { bg: theme.colors.primaryMuted, fg: theme.colors.primary },
    neutral: { bg: theme.colors.inputBackground, fg: theme.colors.textMuted },
  };

  const c = toneColors[tone];

  return (
    <View
      style={[
        styles.badge,
        { backgroundColor: c.bg, borderRadius: theme.radius.pill, paddingHorizontal: theme.spacing(2.5) },
      ]}
    >
      <Text style={[styles.text, { color: c.fg }]}>{label}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  badge: {
    paddingVertical: 4,
    alignSelf: 'flex-start',
  },
  text: {
    fontSize: 12,
    fontWeight: '700',
  },
});
