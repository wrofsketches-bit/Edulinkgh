// EduLinkGH design system.
// Palette inspired by premium ed-tech products (Coursera/Udemy-style
// indigo + fresh green accent), tuned for a Ghanaian ed-tech brand.

export const palette = {
  indigo50: '#EEF0FF',
  indigo100: '#D9DDFF',
  indigo400: '#6C6FF0',
  indigo500: '#4F46E5',
  indigo600: '#4338CA',
  indigo700: '#3730A3',

  emerald400: '#34D399',
  emerald500: '#10B981',
  emerald600: '#059669',

  amber400: '#FBBF24',
  amber500: '#F59E0B',

  red400: '#F87171',
  red500: '#EF4444',

  slate50: '#F8FAFC',
  slate100: '#F1F5F9',
  slate200: '#E2E8F0',
  slate300: '#CBD5E1',
  slate400: '#94A3B8',
  slate500: '#64748B',
  slate600: '#475569',
  slate700: '#334155',
  slate800: '#1E293B',
  slate900: '#0F172A',
  slate950: '#080D1A',

  white: '#FFFFFF',
  black: '#000000',
};

export type ThemeMode = 'light' | 'dark';

export interface Theme {
  mode: ThemeMode;
  colors: {
    background: string;
    surface: string;
    surfaceElevated: string;
    // glass card background (semi-transparent) + border for glassmorphism
    glass: string;
    glassBorder: string;
    primary: string;
    primaryMuted: string;
    accent: string;
    text: string;
    textMuted: string;
    textInverse: string;
    border: string;
    success: string;
    warning: string;
    danger: string;
    tabBar: string;
    inputBackground: string;
  };
  spacing: (n: number) => number;
  radius: { sm: number; md: number; lg: number; xl: number; pill: number };
  fontSize: { xs: number; sm: number; md: number; lg: number; xl: number; xxl: number; display: number };
}

const spacing = (n: number) => n * 4;

const radius = { sm: 8, md: 14, lg: 20, xl: 28, pill: 999 };

const fontSize = { xs: 12, sm: 14, md: 16, lg: 18, xl: 22, xxl: 28, display: 34 };

export const lightTheme: Theme = {
  mode: 'light',
  colors: {
    background: palette.slate50,
    surface: palette.white,
    surfaceElevated: palette.white,
    glass: 'rgba(255,255,255,0.65)',
    glassBorder: 'rgba(255,255,255,0.9)',
    primary: palette.indigo500,
    primaryMuted: palette.indigo50,
    accent: palette.emerald500,
    text: palette.slate900,
    textMuted: palette.slate500,
    textInverse: palette.white,
    border: palette.slate200,
    success: palette.emerald500,
    warning: palette.amber500,
    danger: palette.red500,
    tabBar: 'rgba(255,255,255,0.92)',
    inputBackground: palette.slate100,
  },
  spacing,
  radius,
  fontSize,
};

export const darkTheme: Theme = {
  mode: 'dark',
  colors: {
    background: palette.slate950,
    surface: palette.slate900,
    surfaceElevated: palette.slate800,
    glass: 'rgba(30,41,59,0.55)',
    glassBorder: 'rgba(148,163,184,0.18)',
    primary: palette.indigo400,
    primaryMuted: 'rgba(76,81,191,0.18)',
    accent: palette.emerald400,
    text: palette.slate50,
    textMuted: palette.slate400,
    textInverse: palette.slate900,
    border: palette.slate700,
    success: palette.emerald400,
    warning: palette.amber400,
    danger: palette.red400,
    tabBar: 'rgba(15,23,42,0.92)',
    inputBackground: palette.slate800,
  },
  spacing,
  radius,
  fontSize,
};
