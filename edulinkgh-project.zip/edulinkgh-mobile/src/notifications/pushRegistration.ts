import { Platform } from 'react-native';
import * as Notifications from 'expo-notifications';
import * as Device from 'expo-device';
import { registerPushToken, unregisterPushToken } from '../api/notifications';

Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: true,
    shouldSetBadge: true,
    shouldShowBanner: true,
    shouldShowList: true,
  }),
});

let cachedToken: string | null = null;

/**
 * Requests notification permission and registers the device's FCM token
 * with the backend. Call this once after login.
 *
 * IMPORTANT: this requires a custom development/production build (EAS Build
 * or `expo run:android`/`expo run:ios`) with google-services.json in place —
 * plain Expo Go can no longer receive real FCM pushes on Android. In Expo Go
 * this will simply fail to get a token and log a warning; that's expected
 * during development until you create a dev build.
 */
export async function registerForPushNotifications(): Promise<void> {
  if (!Device.isDevice) {
    console.warn('Push notifications require a physical device.');
    return;
  }

  const { status: existingStatus } = await Notifications.getPermissionsAsync();
  let finalStatus = existingStatus;
  if (existingStatus !== 'granted') {
    const { status } = await Notifications.requestPermissionsAsync();
    finalStatus = status;
  }
  if (finalStatus !== 'granted') {
    console.warn('Push notification permission was not granted.');
    return;
  }

  if (Platform.OS === 'android') {
    await Notifications.setNotificationChannelAsync('default', {
      name: 'default',
      importance: Notifications.AndroidImportance.MAX,
    });
  }

  try {
    const tokenResponse = await Notifications.getDevicePushTokenAsync();
    const token = tokenResponse.data;
    if (!token) {
      console.warn('Device push token was empty.');
      return;
    }
    cachedToken = token;
    await registerPushToken(token, Platform.OS === 'ios' ? 'ios' : 'android');
  } catch (err) {
    console.warn('Could not obtain push token (expected in Expo Go without a dev build):', err);
  }
}

/** Call on logout so the backend stops sending pushes to this device for the old session. */
export async function unregisterPushNotifications(): Promise<void> {
  if (!cachedToken) return;
  try {
    await unregisterPushToken(cachedToken);
  } catch {
    // best-effort cleanup; not worth surfacing an error for
  } finally {
    cachedToken = null;
  }
}
