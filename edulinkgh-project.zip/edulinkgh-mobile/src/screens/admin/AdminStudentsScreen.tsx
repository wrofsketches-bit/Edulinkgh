import React, { useCallback, useState } from 'react';
import { FlatList, RefreshControl, Text, View } from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { getAllStudents, reactivateUser, suspendUser } from '../../api/admin';
import { ApiError } from '../../api/client';
import { AdminUserSummary } from '../../api/adminTypes';
import { useAppTheme } from '../../theme/ThemeContext';
import { GlassCard } from '../../components/GlassCard';
import { Badge } from '../../components/Badge';
import { Button } from '../../components/Button';
import { Skeleton } from '../../components/Skeleton';

const statusTone: Record<string, 'success' | 'warning' | 'danger' | 'neutral'> = {
  ACTIVE: 'success',
  PENDING_VERIFICATION: 'warning',
  SUSPENDED: 'danger',
};

export function AdminStudentsScreen() {
  const { theme } = useAppTheme();
  const [students, setStudents] = useState<AdminUserSummary[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [busyId, setBusyId] = useState<number | null>(null);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    try {
      const result = await getAllStudents();
      setStudents(result);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Could not load students');
    }
  }, []);

  useFocusEffect(
    useCallback(() => {
      load().finally(() => setLoading(false));
      // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [])
  );

  const onRefresh = async () => {
    setRefreshing(true);
    await load();
    setRefreshing(false);
  };

  const runAction = async (id: number, action: () => Promise<unknown>) => {
    setBusyId(id);
    setError(null);
    try {
      await action();
      await load();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Action failed');
    } finally {
      setBusyId(null);
    }
  };

  return (
    <View style={{ flex: 1, backgroundColor: theme.colors.background, padding: theme.spacing(6) }}>
      <Text style={{ color: theme.colors.text, fontSize: theme.fontSize.xxl, fontWeight: '800', marginTop: theme.spacing(10), marginBottom: theme.spacing(5) }}>
        Students
      </Text>

      {error ? <Text style={{ color: theme.colors.danger, marginBottom: 12 }}>{error}</Text> : null}

      {loading ? (
        <Skeleton height={100} />
      ) : (
        <FlatList
          data={students}
          keyExtractor={(item) => String(item.id)}
          refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={theme.colors.primary} />}
          ListEmptyComponent={
            <Text style={{ color: theme.colors.textMuted, textAlign: 'center', marginTop: 40 }}>No students yet.</Text>
          }
          renderItem={({ item }) => (
            <GlassCard style={{ marginBottom: theme.spacing(3) }}>
              <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                <View style={{ flex: 1 }}>
                  <Text style={{ color: theme.colors.text, fontWeight: '700' }}>{item.fullName}</Text>
                  <Text style={{ color: theme.colors.textMuted, marginTop: 2 }}>{item.email}</Text>
                  {item.schoolName ? (
                    <Text style={{ color: theme.colors.textMuted, marginTop: 2 }}>{item.schoolName}</Text>
                  ) : null}
                </View>
                <Badge label={item.status.replace('_', ' ')} tone={statusTone[item.status] || 'neutral'} />
              </View>

              <View style={{ marginTop: theme.spacing(3) }}>
                {item.status !== 'SUSPENDED' ? (
                  <Button
                    title="Suspend"
                    variant="danger"
                    onPress={() => runAction(item.id, () => suspendUser(item.id))}
                    loading={busyId === item.id}
                  />
                ) : (
                  <Button
                    title="Reactivate"
                    variant="outline"
                    onPress={() => runAction(item.id, () => reactivateUser(item.id))}
                    loading={busyId === item.id}
                  />
                )}
              </View>
            </GlassCard>
          )}
        />
      )}
    </View>
  );
}
