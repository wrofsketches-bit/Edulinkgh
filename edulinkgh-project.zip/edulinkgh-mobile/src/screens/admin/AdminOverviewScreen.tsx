import React, { useCallback, useState } from 'react';
import { RefreshControl, ScrollView, Text, View } from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import type { NativeStackScreenProps } from '@react-navigation/native-stack';
import type { CompositeScreenProps } from '@react-navigation/native';
import type { BottomTabScreenProps } from '@react-navigation/bottom-tabs';
import { getPlatformSettings, getPlatformStats, reconcileStalePayments, setGlobalCommissionRate } from '../../api/admin';
import { ApiError } from '../../api/client';
import { PlatformStats } from '../../api/adminTypes';
import { PlatformSettings } from '../../api/types';
import { useAppTheme } from '../../theme/ThemeContext';
import { useAuth } from '../../context/AuthContext';
import { GlassCard } from '../../components/GlassCard';
import { Button } from '../../components/Button';
import { TextField } from '../../components/TextField';
import { Skeleton } from '../../components/Skeleton';
import type { AdminStackParamList, AdminTabParamList } from '../../navigation/types';

type Props = CompositeScreenProps<
  BottomTabScreenProps<AdminTabParamList, 'Overview'>,
  NativeStackScreenProps<AdminStackParamList>
>;

function StatCard({ label, value, tone }: { label: string; value: string | number; tone?: string }) {
  const { theme } = useAppTheme();
  return (
    <GlassCard style={{ flexBasis: '48%', marginBottom: theme.spacing(3) }}>
      <Text style={{ color: theme.colors.textMuted, fontSize: 12, fontWeight: '700', marginBottom: 6 }}>
        {label.toUpperCase()}
      </Text>
      <Text style={{ color: tone || theme.colors.text, fontSize: theme.fontSize.xxl, fontWeight: '800' }}>
        {value}
      </Text>
    </GlassCard>
  );
}

export function AdminOverviewScreen({ navigation }: Props) {
  const { theme } = useAppTheme();
  const { user } = useAuth();
  const [stats, setStats] = useState<PlatformStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [reconciling, setReconciling] = useState(false);
  const [reconcileMessage, setReconcileMessage] = useState<string | null>(null);
  const [settings, setSettings] = useState<PlatformSettings | null>(null);
  const [commissionInput, setCommissionInput] = useState('');
  const [savingCommission, setSavingCommission] = useState(false);
  const [commissionMessage, setCommissionMessage] = useState<string | null>(null);

  const load = useCallback(async () => {
    try {
      const [statsResult, settingsResult] = await Promise.all([getPlatformStats(), getPlatformSettings()]);
      setStats(statsResult);
      setSettings(settingsResult);
      setCommissionInput(String(settingsResult.globalCommissionRatePercent));
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Could not load platform stats');
    }
  }, []);

  useFocusEffect(
    useCallback(() => {
      load().finally(() => setLoading(false));
      // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [])
  );

  const onRefresh = async () => {
    setRefreshing(true);
    await load();
    setRefreshing(false);
  };

  const handleReconcile = async () => {
    setReconciling(true);
    setReconcileMessage(null);
    try {
      const result = await reconcileStalePayments();
      setReconcileMessage(
        result.resolved > 0 ? `Resolved ${result.resolved} stuck payment(s).` : 'No stuck payments found.'
      );
      await load();
    } catch (err) {
      setReconcileMessage(err instanceof ApiError ? err.message : 'Reconciliation failed');
    } finally {
      setReconciling(false);
    }
  };

  const handleSaveCommission = async () => {
    const percent = Number(commissionInput);
    if (isNaN(percent) || percent < 0 || percent > 100) {
      setCommissionMessage('Enter a rate between 0 and 100.');
      return;
    }
    setSavingCommission(true);
    setCommissionMessage(null);
    try {
      const result = await setGlobalCommissionRate(percent);
      setSettings(result);
      setCommissionMessage('Saved.');
    } catch (err) {
      setCommissionMessage(err instanceof ApiError ? err.message : 'Could not save');
    } finally {
      setSavingCommission(false);
    }
  };

  return (
    <ScrollView
      style={{ flex: 1, backgroundColor: theme.colors.background }}
      contentContainerStyle={{ padding: theme.spacing(6) }}
      refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={theme.colors.primary} />}
    >
      <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', marginTop: theme.spacing(10) }}>
        <View>
          <Text style={{ color: theme.colors.textMuted }}>Welcome back,</Text>
          <Text style={{ color: theme.colors.text, fontSize: theme.fontSize.xxl, fontWeight: '800' }}>
            {user?.fullName}
          </Text>
        </View>
        <Text onPress={() => navigation.navigate('Settings')} style={{ color: theme.colors.primary, fontWeight: '600', marginTop: 6 }}>
          Settings
        </Text>
      </View>

      <View style={{ marginTop: theme.spacing(5) }} />

      {error ? <Text style={{ color: theme.colors.danger, marginBottom: 12 }}>{error}</Text> : null}

      {loading || !stats ? (
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between' }}>
          <Skeleton height={90} width="48%" style={{ marginBottom: 12 }} />
          <Skeleton height={90} width="48%" style={{ marginBottom: 12 }} />
          <Skeleton height={90} width="48%" />
          <Skeleton height={90} width="48%" />
        </View>
      ) : (
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between' }}>
          <StatCard label="Students" value={stats.totalStudents} />
          <StatCard label="Teachers" value={stats.totalTeachers} />
          <StatCard label="Sessions" value={stats.totalSessions} />
          <StatCard label="Live now" value={stats.liveSessions} tone={stats.liveSessions > 0 ? theme.colors.success : undefined} />
          <StatCard label="Total Revenue" value={`GHC ${stats.totalRevenue.toFixed(2)}`} />
          <StatCard
            label="Pending Verification"
            value={stats.pendingVerifications}
            tone={stats.pendingVerifications > 0 ? theme.colors.warning : undefined}
          />
        </View>
      )}

      <GlassCard style={{ marginTop: theme.spacing(3) }}>
        <Text style={{ color: theme.colors.textMuted, fontSize: 13, fontWeight: '700', marginBottom: theme.spacing(2) }}>
          PAYMENT RECONCILIATION
        </Text>
        <Text style={{ color: theme.colors.textMuted, marginBottom: theme.spacing(3) }}>
          Stuck pending payments are swept automatically every 5 minutes. Trigger a check now if a student reports a payment that hasn't gone through.
        </Text>
        {reconcileMessage ? (
          <Text style={{ color: theme.colors.text, marginBottom: theme.spacing(2) }}>{reconcileMessage}</Text>
        ) : null}
        <Button title="Check Now" variant="outline" onPress={handleReconcile} loading={reconciling} />
      </GlassCard>

      <GlassCard style={{ marginTop: theme.spacing(3) }}>
        <Text style={{ color: theme.colors.textMuted, fontSize: 13, fontWeight: '700', marginBottom: theme.spacing(2) }}>
          PLATFORM COMMISSION
        </Text>
        <Text style={{ color: theme.colors.textMuted, marginBottom: theme.spacing(3) }}>
          Default rate applied to new session payments. Individual teachers can have their own override — see Teachers.
        </Text>
        <TextField
          label="Global rate (%)"
          keyboardType="decimal-pad"
          value={commissionInput}
          onChangeText={setCommissionInput}
        />
        {commissionMessage ? (
          <Text style={{ color: theme.colors.text, marginBottom: theme.spacing(2) }}>{commissionMessage}</Text>
        ) : null}
        <Button title="Save" variant="outline" onPress={handleSaveCommission} loading={savingCommission} />
      </GlassCard>
    </ScrollView>
  );
}
