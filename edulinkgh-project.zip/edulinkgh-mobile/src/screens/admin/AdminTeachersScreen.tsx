import React, { useCallback, useState } from 'react';
import { FlatList, RefreshControl, Text, View } from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { getAllTeachers, payTeacher, reactivateUser, setTeacherCommissionOverride, suspendUser, verifyTeacher } from '../../api/admin';
import { ApiError } from '../../api/client';
import { AdminUserSummary } from '../../api/adminTypes';
import { useAppTheme } from '../../theme/ThemeContext';
import { GlassCard } from '../../components/GlassCard';
import { Badge } from '../../components/Badge';
import { Button } from '../../components/Button';
import { TextField } from '../../components/TextField';
import { Skeleton } from '../../components/Skeleton';

const statusTone: Record<string, 'success' | 'warning' | 'danger' | 'neutral'> = {
  ACTIVE: 'success',
  PENDING_VERIFICATION: 'warning',
  SUSPENDED: 'danger',
};

export function AdminTeachersScreen() {
  const { theme } = useAppTheme();
  const [teachers, setTeachers] = useState<AdminUserSummary[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [busyId, setBusyId] = useState<number | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [payingId, setPayingId] = useState<number | null>(null);
  const [payAmount, setPayAmount] = useState('');
  const [editingCommissionId, setEditingCommissionId] = useState<number | null>(null);
  const [commissionInput, setCommissionInput] = useState('');

  const load = useCallback(async () => {
    try {
      const result = await getAllTeachers();
      setTeachers(result);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Could not load teachers');
    }
  }, []);

  useFocusEffect(
    useCallback(() => {
      load().finally(() => setLoading(false));
      // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [])
  );

  const onRefresh = async () => {
    setRefreshing(true);
    await load();
    setRefreshing(false);
  };

  const runAction = async (id: number, action: () => Promise<unknown>) => {
    setBusyId(id);
    setError(null);
    try {
      await action();
      await load();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Action failed');
    } finally {
      setBusyId(null);
    }
  };

  const handlePay = async (id: number) => {
    if (!payAmount.trim() || isNaN(Number(payAmount)) || Number(payAmount) <= 0) {
      setError('Enter a valid payout amount.');
      return;
    }
    await runAction(id, () => payTeacher(id, Number(payAmount)));
    setPayingId(null);
    setPayAmount('');
  };

  const handleSetCommission = async (id: number) => {
    const trimmed = commissionInput.trim();
    const percent = trimmed === '' ? null : Number(trimmed);
    if (percent !== null && (isNaN(percent) || percent < 0 || percent > 100)) {
      setError('Enter a rate between 0 and 100, or leave blank to use the platform default.');
      return;
    }
    await runAction(id, () => setTeacherCommissionOverride(id, percent));
    setEditingCommissionId(null);
    setCommissionInput('');
  };

  return (
    <View style={{ flex: 1, backgroundColor: theme.colors.background, padding: theme.spacing(6) }}>
      <Text style={{ color: theme.colors.text, fontSize: theme.fontSize.xxl, fontWeight: '800', marginTop: theme.spacing(10), marginBottom: theme.spacing(5) }}>
        Teachers
      </Text>

      {error ? <Text style={{ color: theme.colors.danger, marginBottom: 12 }}>{error}</Text> : null}

      {loading ? (
        <Skeleton height={110} />
      ) : (
        <FlatList
          data={teachers}
          keyExtractor={(item) => String(item.id)}
          refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={theme.colors.primary} />}
          ListEmptyComponent={
            <Text style={{ color: theme.colors.textMuted, textAlign: 'center', marginTop: 40 }}>No teachers yet.</Text>
          }
          renderItem={({ item }) => (
            <GlassCard style={{ marginBottom: theme.spacing(3) }}>
              <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                <View style={{ flex: 1 }}>
                  <Text style={{ color: theme.colors.text, fontWeight: '700' }}>{item.fullName}</Text>
                  <Text style={{ color: theme.colors.textMuted, marginTop: 2 }}>{item.email}</Text>
                  <Text style={{ color: theme.colors.textMuted, marginTop: 2 }}>
                    {item.subject || 'No subject set'} · {item.teachingLevel || 'No level set'}
                  </Text>
                </View>
                <Badge label={item.status.replace('_', ' ')} tone={statusTone[item.status] || 'neutral'} />
              </View>

              <View style={{ flexDirection: 'row', gap: 8, marginTop: theme.spacing(3) }}>
                {!item.qualificationVerified ? (
                  <View style={{ flex: 1 }}>
                    <Button
                      title="Verify"
                      onPress={() => runAction(item.id, () => verifyTeacher(item.id))}
                      loading={busyId === item.id}
                    />
                  </View>
                ) : null}
                {item.status !== 'SUSPENDED' ? (
                  <View style={{ flex: 1 }}>
                    <Button
                      title="Suspend"
                      variant="danger"
                      onPress={() => runAction(item.id, () => suspendUser(item.id))}
                      loading={busyId === item.id}
                    />
                  </View>
                ) : (
                  <View style={{ flex: 1 }}>
                    <Button
                      title="Reactivate"
                      variant="outline"
                      onPress={() => runAction(item.id, () => reactivateUser(item.id))}
                      loading={busyId === item.id}
                    />
                  </View>
                )}
              </View>

              {payingId === item.id ? (
                <View style={{ marginTop: theme.spacing(3) }}>
                  <TextField
                    label="Payout amount (GHC)"
                    keyboardType="decimal-pad"
                    value={payAmount}
                    onChangeText={setPayAmount}
                  />
                  <Button title="Confirm Payout" onPress={() => handlePay(item.id)} loading={busyId === item.id} />
                </View>
              ) : (
                <View style={{ marginTop: theme.spacing(2) }}>
                  <Button title="Pay Teacher" variant="outline" onPress={() => setPayingId(item.id)} />
                </View>
              )}

              {editingCommissionId === item.id ? (
                <View style={{ marginTop: theme.spacing(3) }}>
                  <TextField
                    label="Commission override % (blank = use platform default)"
                    keyboardType="decimal-pad"
                    value={commissionInput}
                    onChangeText={setCommissionInput}
                  />
                  <Button title="Save" onPress={() => handleSetCommission(item.id)} loading={busyId === item.id} />
                </View>
              ) : (
                <View style={{ marginTop: theme.spacing(2) }}>
                  <Button title="Set Commission Rate" variant="outline" onPress={() => setEditingCommissionId(item.id)} />
                </View>
              )}
            </GlassCard>
          )}
        />
      )}
    </View>
  );
}
