import React, { useCallback, useState } from 'react';
import { Pressable, RefreshControl, ScrollView, Text, View } from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { getRevenueAnalytics, getSessionVolumeAnalytics } from '../../api/admin';
import { ApiError } from '../../api/client';
import { RevenueAnalytics, SessionVolumeAnalytics } from '../../api/types';
import { useAppTheme } from '../../theme/ThemeContext';
import { GlassCard } from '../../components/GlassCard';
import { AnalyticsLineChart } from '../../components/AnalyticsLineChart';
import { Skeleton } from '../../components/Skeleton';

const WINDOWS = [7, 30, 90];

export function AdminAnalyticsScreen() {
  const { theme } = useAppTheme();
  const [days, setDays] = useState(30);
  const [revenue, setRevenue] = useState<RevenueAnalytics | null>(null);
  const [sessions, setSessions] = useState<SessionVolumeAnalytics | null>(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    try {
      const [revenueResult, sessionsResult] = await Promise.all([
        getRevenueAnalytics(days),
        getSessionVolumeAnalytics(days),
      ]);
      setRevenue(revenueResult);
      setSessions(sessionsResult);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Could not load analytics');
    }
  }, [days]);

  useFocusEffect(
    useCallback(() => {
      setLoading(true);
      load().finally(() => setLoading(false));
      // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [days])
  );

  const onRefresh = async () => {
    setRefreshing(true);
    await load();
    setRefreshing(false);
  };

  return (
    <ScrollView
      style={{ flex: 1, backgroundColor: theme.colors.background }}
      contentContainerStyle={{ padding: theme.spacing(6) }}
      refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={theme.colors.primary} />}
    >
      <Text style={{ color: theme.colors.text, fontSize: theme.fontSize.xxl, fontWeight: '800', marginTop: theme.spacing(10), marginBottom: theme.spacing(4) }}>
        Analytics
      </Text>

      <View style={{ flexDirection: 'row', gap: 8, marginBottom: theme.spacing(5) }}>
        {WINDOWS.map((w) => (
          <Pressable
            key={w}
            onPress={() => setDays(w)}
            style={{
              paddingVertical: 8,
              paddingHorizontal: 16,
              borderRadius: theme.radius.pill,
              backgroundColor: days === w ? theme.colors.primary : theme.colors.inputBackground,
            }}
          >
            <Text style={{ color: days === w ? theme.colors.textInverse : theme.colors.text, fontWeight: '600' }}>
              {w}d
            </Text>
          </Pressable>
        ))}
      </View>

      {error ? <Text style={{ color: theme.colors.danger, marginBottom: 12 }}>{error}</Text> : null}

      {loading ? (
        <View>
          <Skeleton height={220} style={{ marginBottom: 16 }} />
          <Skeleton height={220} />
        </View>
      ) : (
        <>
          <GlassCard style={{ marginBottom: theme.spacing(5) }}>
            <Text style={{ color: theme.colors.textMuted, fontSize: 13, fontWeight: '700', marginBottom: 4 }}>
              REVENUE ({days}d)
            </Text>
            <Text style={{ color: theme.colors.text, fontSize: theme.fontSize.xxl, fontWeight: '800', marginBottom: theme.spacing(3) }}>
              GHC {revenue?.totalRevenueGhc.toFixed(2) ?? '0.00'}
            </Text>
            {revenue ? <AnalyticsLineChart data={revenue.series} color={theme.colors.success} /> : null}
          </GlassCard>

          <GlassCard>
            <Text style={{ color: theme.colors.textMuted, fontSize: 13, fontWeight: '700', marginBottom: 4 }}>
              SESSIONS ({days}d)
            </Text>
            <Text style={{ color: theme.colors.text, fontSize: theme.fontSize.xxl, fontWeight: '800', marginBottom: theme.spacing(3) }}>
              {sessions?.totalSessions ?? 0} scheduled
            </Text>
            {sessions ? <AnalyticsLineChart data={sessions.completedSeries} color={theme.colors.primary} /> : null}
            <Text style={{ color: theme.colors.textMuted, fontSize: 12, marginTop: 8 }}>
              Completed sessions per day
            </Text>
          </GlassCard>
        </>
      )}
    </ScrollView>
  );
}
