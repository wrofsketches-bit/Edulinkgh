import React, { useCallback, useState } from 'react';
import { FlatList, RefreshControl, Text, View } from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { cancelSessionAsAdmin, getAllSessions } from '../../api/admin';
import { ApiError } from '../../api/client';
import { AdminSessionSummary } from '../../api/adminTypes';
import { useAppTheme } from '../../theme/ThemeContext';
import { GlassCard } from '../../components/GlassCard';
import { Badge } from '../../components/Badge';
import { Button } from '../../components/Button';
import { Skeleton } from '../../components/Skeleton';

const statusTone: Record<string, 'primary' | 'success' | 'neutral' | 'danger'> = {
  UPCOMING: 'primary',
  LIVE: 'success',
  COMPLETED: 'neutral',
  CANCELLED: 'danger',
};

export function AdminSessionsScreen() {
  const { theme } = useAppTheme();
  const [sessions, setSessions] = useState<AdminSessionSummary[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [busyId, setBusyId] = useState<number | null>(null);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    try {
      const result = await getAllSessions();
      setSessions(result);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Could not load sessions');
    }
  }, []);

  useFocusEffect(
    useCallback(() => {
      load().finally(() => setLoading(false));
      // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [])
  );

  const onRefresh = async () => {
    setRefreshing(true);
    await load();
    setRefreshing(false);
  };

  const handleCancel = async (id: number) => {
    setBusyId(id);
    setError(null);
    try {
      await cancelSessionAsAdmin(id);
      await load();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Could not cancel session');
    } finally {
      setBusyId(null);
    }
  };

  return (
    <View style={{ flex: 1, backgroundColor: theme.colors.background, padding: theme.spacing(6) }}>
      <Text style={{ color: theme.colors.text, fontSize: theme.fontSize.xxl, fontWeight: '800', marginTop: theme.spacing(10), marginBottom: theme.spacing(5) }}>
        All Sessions
      </Text>

      {error ? <Text style={{ color: theme.colors.danger, marginBottom: 12 }}>{error}</Text> : null}

      {loading ? (
        <Skeleton height={100} />
      ) : (
        <FlatList
          data={sessions}
          keyExtractor={(item) => String(item.id)}
          refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={theme.colors.primary} />}
          ListEmptyComponent={
            <Text style={{ color: theme.colors.textMuted, textAlign: 'center', marginTop: 40 }}>No sessions yet.</Text>
          }
          renderItem={({ item }) => (
            <GlassCard style={{ marginBottom: theme.spacing(3) }}>
              <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                <View style={{ flex: 1 }}>
                  <Text style={{ color: theme.colors.text, fontWeight: '700' }}>{item.subject}</Text>
                  <Text style={{ color: theme.colors.textMuted, marginTop: 2 }}>with {item.teacher}</Text>
                  <Text style={{ color: theme.colors.textMuted, marginTop: 2 }}>
                    {new Date(item.scheduledAt).toLocaleString()} · {item.enrolledCount} enrolled
                  </Text>
                  <Text style={{ color: theme.colors.primary, marginTop: 4, fontWeight: '700' }}>
                    GHC {item.feeGhc.toFixed(2)}
                  </Text>
                </View>
                <Badge label={item.status} tone={statusTone[item.status] || 'neutral'} />
              </View>

              {item.status === 'UPCOMING' || item.status === 'LIVE' ? (
                <View style={{ marginTop: theme.spacing(3) }}>
                  <Button
                    title="Cancel Session"
                    variant="danger"
                    onPress={() => handleCancel(item.id)}
                    loading={busyId === item.id}
                  />
                </View>
              ) : null}
            </GlassCard>
          )}
        />
      )}
    </View>
  );
}
