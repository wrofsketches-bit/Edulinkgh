import React from 'react';
import { ActivityIndicator, Text, View } from 'react-native';
import { useAppTheme } from '../theme/ThemeContext';

export function SplashScreen() {
  const { theme } = useAppTheme();
  return (
    <View
      style={{
        flex: 1,
        backgroundColor: theme.colors.background,
        alignItems: 'center',
        justifyContent: 'center',
      }}
    >
      <Text style={{ color: theme.colors.primary, fontSize: 28, fontWeight: '800', marginBottom: 16 }}>
        EduLinkGH
      </Text>
      <ActivityIndicator color={theme.colors.primary} />
    </View>
  );
}
