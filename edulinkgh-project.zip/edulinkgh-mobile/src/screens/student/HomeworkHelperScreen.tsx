import React, { useEffect, useRef, useState } from 'react';
import { KeyboardAvoidingView, Platform, ScrollView, Text, View } from 'react-native';
import { askHomeworkQuestionStreaming, getHomeworkHistory } from '../../api/ai';
import { HomeworkHistoryItem } from '../../api/types';
import { useAppTheme } from '../../theme/ThemeContext';
import { GlassCard } from '../../components/GlassCard';
import { Button } from '../../components/Button';
import { TextField } from '../../components/TextField';
import { Skeleton } from '../../components/Skeleton';

export function HomeworkHelperScreen() {
  const { theme } = useAppTheme();
  const [subject, setSubject] = useState('');
  const [question, setQuestion] = useState('');
  const [answer, setAnswer] = useState('');
  const [asking, setAsking] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const abortRef = useRef<(() => void) | null>(null);

  const [history, setHistory] = useState<HomeworkHistoryItem[]>([]);
  const [loadingHistory, setLoadingHistory] = useState(true);

  const loadHistory = async () => {
    try {
      const result = await getHomeworkHistory();
      setHistory(result);
    } catch {
      // non-critical — history just won't show if this fails
    } finally {
      setLoadingHistory(false);
    }
  };

  useEffect(() => {
    loadHistory();
    // Cancel any in-flight stream if the screen unmounts mid-answer, so
    // stray onToken calls don't fire against unmounted state.
    return () => abortRef.current?.();
  }, []);

  const handleAsk = async () => {
    if (!question.trim()) {
      setError('Type a question first.');
      return;
    }
    setAsking(true);
    setError(null);
    setAnswer('');

    const askedQuestion = question.trim();
    const askedSubject = subject.trim() || undefined;
    setQuestion('');

    abortRef.current = await askHomeworkQuestionStreaming(askedQuestion, askedSubject, {
      onToken: (token) => setAnswer((prev) => prev + token),
      onDone: () => {
        setAsking(false);
        abortRef.current = null;
        loadHistory();
      },
      onError: (message) => {
        setError(message);
        setAsking(false);
        abortRef.current = null;
      },
    });
  };

  return (
    <KeyboardAvoidingView style={{ flex: 1, backgroundColor: theme.colors.background }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <ScrollView contentContainerStyle={{ padding: theme.spacing(6) }} keyboardShouldPersistTaps="handled">
        <Text style={{ color: theme.colors.text, fontSize: theme.fontSize.xxl, fontWeight: '800', marginTop: theme.spacing(10), marginBottom: theme.spacing(2) }}>
          Homework Helper
        </Text>
        <Text style={{ color: theme.colors.textMuted, marginBottom: theme.spacing(5) }}>
          Ask a question and get help understanding it — not just the answer.
        </Text>

        <TextField label="Subject (optional)" placeholder="e.g. Mathematics, Chemistry" value={subject} onChangeText={setSubject} />
        <TextField
          label="Your question"
          placeholder="What are you stuck on?"
          value={question}
          onChangeText={setQuestion}
          multiline
        />

        {error ? <Text style={{ color: theme.colors.danger, marginBottom: 12 }}>{error}</Text> : null}

        <Button title="Ask" onPress={handleAsk} loading={asking && answer.length === 0} />

        {answer || asking ? (
          <GlassCard style={{ marginTop: theme.spacing(5) }}>
            <Text style={{ color: theme.colors.textMuted, fontSize: 13, fontWeight: '700', marginBottom: 8 }}>ANSWER</Text>
            <Text style={{ color: theme.colors.text, lineHeight: 22 }}>
              {answer}
              {asking ? '▋' : ''}
            </Text>
          </GlassCard>
        ) : null}

        <Text style={{ color: theme.colors.text, fontSize: theme.fontSize.lg, fontWeight: '700', marginTop: theme.spacing(7), marginBottom: theme.spacing(3) }}>
          Past Questions
        </Text>

        {loadingHistory ? (
          <Skeleton height={80} />
        ) : history.length === 0 ? (
          <Text style={{ color: theme.colors.textMuted }}>No questions asked yet.</Text>
        ) : (
          history.map((item) => (
            <GlassCard key={item.id} style={{ marginBottom: theme.spacing(3) }}>
              <Text style={{ color: theme.colors.text, fontWeight: '700' }}>{item.question}</Text>
              {item.subjectContext ? (
                <Text style={{ color: theme.colors.textMuted, fontSize: 12, marginTop: 2 }}>{item.subjectContext}</Text>
              ) : null}
              <Text style={{ color: theme.colors.textMuted, marginTop: 8, lineHeight: 20 }} numberOfLines={4}>
                {item.answer}
              </Text>
            </GlassCard>
          ))
        )}
      </ScrollView>
    </KeyboardAvoidingView>
  );
}
