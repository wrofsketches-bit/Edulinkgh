import React, { useEffect, useState } from 'react';
import { FlatList, Text, View } from 'react-native';
import type { NativeStackScreenProps } from '@react-navigation/native-stack';
import * as WebBrowser from 'expo-web-browser';
import { enrollInSession, getUpcomingSessions } from '../../api/sessions';
import { confirmPayment, initiateSessionPayment } from '../../api/payments';
import { previewPromoCode } from '../../api/promoCodes';
import { ApiError } from '../../api/client';
import { PromoPreview, SessionItem } from '../../api/types';
import { useAppTheme } from '../../theme/ThemeContext';
import { GlassCard } from '../../components/GlassCard';
import { Button } from '../../components/Button';
import { TextField } from '../../components/TextField';
import { Skeleton } from '../../components/Skeleton';
import type { StudentStackParamList } from '../../navigation/types';

type Props = NativeStackScreenProps<StudentStackParamList, 'BookSession'>;

export function BookSessionScreen({ route, navigation }: Props) {
  const { teacherId } = route.params;
  const { theme } = useAppTheme();
  const [sessions, setSessions] = useState<SessionItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [processingId, setProcessingId] = useState<number | null>(null);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [promoInputs, setPromoInputs] = useState<Record<number, string>>({});
  const [promoPreviews, setPromoPreviews] = useState<Record<number, PromoPreview | undefined>>({});
  const [checkingPromoId, setCheckingPromoId] = useState<number | null>(null);

  useEffect(() => {
    (async () => {
      try {
        const all = await getUpcomingSessions();
        setSessions(all.filter((s) => s.teacher.id === teacherId && s.status === 'UPCOMING'));
      } catch (err) {
        setError(err instanceof ApiError ? err.message : 'Could not load sessions');
      } finally {
        setLoading(false);
      }
    })();
  }, [teacherId]);

  const handleCheckPromo = async (sessionId: number) => {
    const code = (promoInputs[sessionId] || '').trim();
    if (!code) return;
    setCheckingPromoId(sessionId);
    try {
      const preview = await previewPromoCode(code, sessionId);
      setPromoPreviews((prev) => ({ ...prev, [sessionId]: preview }));
    } catch (err) {
      const message = err instanceof ApiError ? err.message : 'Could not check that code.';
      setPromoPreviews((prev) => ({ ...prev, [sessionId]: { valid: false, originalAmount: 0, discountAmount: 0, finalAmount: 0, error: message } }));
    } finally {
      setCheckingPromoId(null);
    }
  };

  const handleBookAndPay = async (sessionId: number) => {
    setProcessingId(sessionId);
    setError(null);
    setStatusMessage(null);
    try {
      await enrollInSession(sessionId);

      const preview = promoPreviews[sessionId];
      const promoCode = preview?.valid ? promoInputs[sessionId]?.trim() : undefined;

      setStatusMessage('Opening checkout...');
      const { checkoutUrl, providerReference } = await initiateSessionPayment(sessionId, promoCode);

      // openAuthSessionAsync's result only tells us how the browser UI was
      // dismissed (cancel/dismiss on iOS, opened/locked on Android) — it does
      // NOT tell us whether the payment succeeded, since we're not passing a
      // deep-link redirect URL for it to match against. So regardless of how
      // the browser closed, always ask the provider directly via confirmPayment
      // — that's the only trustworthy source of truth here.
      await WebBrowser.openAuthSessionAsync(checkoutUrl);

      setStatusMessage('Confirming payment...');
      const confirmation = await confirmPayment(providerReference);
      if (confirmation.status === 'SUCCESS') {
        navigation.navigate('SessionDetail', { sessionId });
        return;
      }
      setError(confirmation.message || 'Payment was not completed.');
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Could not complete booking');
    } finally {
      setProcessingId(null);
      setStatusMessage(null);
    }
  };

  return (
    <View style={{ flex: 1, backgroundColor: theme.colors.background, padding: theme.spacing(6) }}>
      <Text style={{ color: theme.colors.text, fontSize: theme.fontSize.xxl, fontWeight: '800', marginTop: theme.spacing(10), marginBottom: theme.spacing(5) }}>
        Available Sessions
      </Text>

      {error ? <Text style={{ color: theme.colors.danger, marginBottom: 12 }}>{error}</Text> : null}
      {statusMessage ? <Text style={{ color: theme.colors.textMuted, marginBottom: 12 }}>{statusMessage}</Text> : null}

      {loading ? (
        <View>
          <Skeleton height={90} style={{ marginBottom: 12 }} />
          <Skeleton height={90} />
        </View>
      ) : (
        <FlatList
          data={sessions}
          keyExtractor={(item) => String(item.id)}
          ListEmptyComponent={
            <Text style={{ color: theme.colors.textMuted, textAlign: 'center', marginTop: 40 }}>
              This teacher has no open sessions right now.
            </Text>
          }
          renderItem={({ item }) => {
            const preview = promoPreviews[item.id];
            return (
              <GlassCard style={{ marginBottom: theme.spacing(3) }}>
                <Text style={{ color: theme.colors.text, fontSize: theme.fontSize.lg, fontWeight: '700' }}>
                  {item.subject}
                </Text>
                <Text style={{ color: theme.colors.textMuted, marginTop: 4 }}>
                  {new Date(item.scheduledAt).toLocaleString()} · {item.durationMinutes} min
                </Text>

                {preview?.valid ? (
                  <View style={{ marginTop: 6 }}>
                    <Text style={{ color: theme.colors.textMuted, textDecorationLine: 'line-through' }}>
                      GHC {item.feeGhc.toFixed(2)}
                    </Text>
                    <Text style={{ color: theme.colors.success, fontWeight: '700' }}>
                      GHC {preview.finalAmount.toFixed(2)} (promo applied)
                    </Text>
                  </View>
                ) : (
                  <Text style={{ color: theme.colors.primary, marginTop: 6, fontWeight: '700' }}>
                    GHC {item.feeGhc.toFixed(2)}
                  </Text>
                )}

                <View style={{ flexDirection: 'row', gap: 8, marginTop: theme.spacing(3), alignItems: 'flex-start' }}>
                  <View style={{ flex: 1 }}>
                    <TextField
                      placeholder="Promo code (optional)"
                      autoCapitalize="characters"
                      value={promoInputs[item.id] || ''}
                      onChangeText={(text) => {
                        setPromoInputs((prev) => ({ ...prev, [item.id]: text }));
                        setPromoPreviews((prev) => ({ ...prev, [item.id]: undefined }));
                      }}
                    />
                  </View>
                  <Button
                    title="Apply"
                    variant="outline"
                    fullWidth={false}
                    onPress={() => handleCheckPromo(item.id)}
                    loading={checkingPromoId === item.id}
                  />
                </View>
                {preview && !preview.valid ? (
                  <Text style={{ color: theme.colors.danger, fontSize: 12, marginTop: -8, marginBottom: 8 }}>
                    {preview.error}
                  </Text>
                ) : null}

                <View style={{ marginTop: theme.spacing(2) }}>
                  <Button
                    title="Book & Pay"
                    onPress={() => handleBookAndPay(item.id)}
                    loading={processingId === item.id}
                  />
                </View>
              </GlassCard>
            );
          }}
        />
      )}
    </View>
  );
}
