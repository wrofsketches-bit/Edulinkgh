import React, { useCallback, useState } from 'react';
import { ScrollView, Text, View } from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import * as WebBrowser from 'expo-web-browser';
import { confirmSubscription, getMySubscription, getPlans, subscribeToPlan } from '../../api/subscriptions';
import { ApiError } from '../../api/client';
import { MySubscription, PlanDetails, SubscriptionPlan } from '../../api/types';
import { useAppTheme } from '../../theme/ThemeContext';
import { GlassCard } from '../../components/GlassCard';
import { Badge } from '../../components/Badge';
import { Button } from '../../components/Button';
import { Skeleton } from '../../components/Skeleton';

const PLAN_ORDER: SubscriptionPlan[] = ['FREE', 'PLUS', 'PRO'];

export function SubscriptionScreen() {
  const { theme } = useAppTheme();
  const [plans, setPlans] = useState<Record<SubscriptionPlan, PlanDetails> | null>(null);
  const [mySubscription, setMySubscription] = useState<MySubscription | null>(null);
  const [loading, setLoading] = useState(true);
  const [processingPlan, setProcessingPlan] = useState<SubscriptionPlan | null>(null);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    try {
      const [plansResult, subResult] = await Promise.all([getPlans(), getMySubscription()]);
      setPlans(plansResult);
      setMySubscription(subResult);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Could not load plans');
    }
  }, []);

  useFocusEffect(
    useCallback(() => {
      setLoading(true);
      load().finally(() => setLoading(false));
      // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [])
  );

  const handleSubscribe = async (plan: SubscriptionPlan) => {
    setProcessingPlan(plan);
    setError(null);
    setStatusMessage(null);
    try {
      const { checkoutUrl, providerReference } = await subscribeToPlan(plan);

      setStatusMessage('Opening checkout...');
      await WebBrowser.openAuthSessionAsync(checkoutUrl);

      setStatusMessage('Confirming subscription...');
      const confirmation = await confirmSubscription(providerReference);
      if (confirmation.status === 'SUCCESS') {
        await load();
        setStatusMessage(null);
      } else {
        setError(confirmation.message || 'Subscription was not completed.');
        setStatusMessage(null);
      }
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Could not complete the subscription');
      setStatusMessage(null);
    } finally {
      setProcessingPlan(null);
    }
  };

  return (
    <ScrollView style={{ flex: 1, backgroundColor: theme.colors.background }} contentContainerStyle={{ padding: theme.spacing(6) }}>
      <Text style={{ color: theme.colors.text, fontSize: theme.fontSize.xxl, fontWeight: '800', marginTop: theme.spacing(10), marginBottom: theme.spacing(2) }}>
        Plans
      </Text>
      <Text style={{ color: theme.colors.textMuted, marginBottom: theme.spacing(5) }}>
        Higher AI limits and priority booking on newly-posted sessions.
      </Text>

      {mySubscription ? (
        <GlassCard style={{ marginBottom: theme.spacing(5) }}>
          <Text style={{ color: theme.colors.textMuted, fontSize: 13, fontWeight: '700', marginBottom: 4 }}>CURRENT PLAN</Text>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
            <Text style={{ color: theme.colors.text, fontSize: theme.fontSize.lg, fontWeight: '800' }}>
              {mySubscription.planDetails.displayName}
            </Text>
            {mySubscription.plan !== 'FREE' ? <Badge label="Active" tone="success" /> : null}
          </View>
          {mySubscription.expiresAt ? (
            <Text style={{ color: theme.colors.textMuted, marginTop: 4 }}>
              Renews/expires {new Date(mySubscription.expiresAt).toLocaleDateString()}
            </Text>
          ) : null}
        </GlassCard>
      ) : null}

      {error ? <Text style={{ color: theme.colors.danger, marginBottom: 12 }}>{error}</Text> : null}
      {statusMessage ? <Text style={{ color: theme.colors.textMuted, marginBottom: 12 }}>{statusMessage}</Text> : null}

      {loading || !plans ? (
        <View>
          <Skeleton height={160} style={{ marginBottom: 16 }} />
          <Skeleton height={160} style={{ marginBottom: 16 }} />
          <Skeleton height={160} />
        </View>
      ) : (
        PLAN_ORDER.map((planKey) => {
          const plan = plans[planKey];
          const isCurrent = mySubscription?.plan === planKey;
          return (
            <GlassCard key={planKey} style={{ marginBottom: theme.spacing(4) }}>
              <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: theme.spacing(3) }}>
                <View>
                  <Text style={{ color: theme.colors.text, fontSize: theme.fontSize.lg, fontWeight: '800' }}>
                    {plan.displayName}
                  </Text>
                  <Text style={{ color: theme.colors.primary, fontWeight: '700', marginTop: 2 }}>
                    {plan.priceGhcPerMonth === 0 ? 'Free' : `GHC ${plan.priceGhcPerMonth.toFixed(2)}/month`}
                  </Text>
                </View>
                {isCurrent ? <Badge label="Current" tone="primary" /> : null}
              </View>

              <Text style={{ color: theme.colors.textMuted, marginBottom: 2 }}>
                {plan.aiHomeworkDailyLimit} homework questions/day
              </Text>
              <Text style={{ color: theme.colors.textMuted, marginBottom: 2 }}>
                {plan.aiQuizDailyLimit} quizzes/day
              </Text>
              <Text style={{ color: theme.colors.textMuted, marginBottom: 2 }}>
                {plan.aiMatchDailyLimit} teacher matches/day
              </Text>
              <Text style={{ color: theme.colors.textMuted, marginBottom: theme.spacing(3) }}>
                {plan.priorityBookingMinutes > 0
                  ? `${plan.priorityBookingMinutes} min priority booking on new sessions`
                  : 'No priority booking'}
              </Text>

              {planKey !== 'FREE' && !isCurrent ? (
                <Button
                  title={`Upgrade to ${plan.displayName}`}
                  onPress={() => handleSubscribe(planKey)}
                  loading={processingPlan === planKey}
                />
              ) : null}
            </GlassCard>
          );
        })
      )}
    </ScrollView>
  );
}
