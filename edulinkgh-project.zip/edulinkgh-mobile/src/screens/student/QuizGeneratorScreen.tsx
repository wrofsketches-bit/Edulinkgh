import React, { useState } from 'react';
import { KeyboardAvoidingView, Platform, Pressable, ScrollView, Text, View } from 'react-native';
import type { NativeStackScreenProps } from '@react-navigation/native-stack';
import { generateQuiz } from '../../api/quiz';
import { ApiError } from '../../api/client';
import { useAppTheme } from '../../theme/ThemeContext';
import { TextField } from '../../components/TextField';
import { Button } from '../../components/Button';
import type { StudentStackParamList } from '../../navigation/types';

type Props = NativeStackScreenProps<StudentStackParamList, 'QuizGenerator'>;

const DIFFICULTIES = ['easy', 'medium', 'hard'];
const COUNTS = [3, 5, 10];

export function QuizGeneratorScreen({ navigation }: Props) {
  const { theme } = useAppTheme();
  const [topic, setTopic] = useState('');
  const [difficulty, setDifficulty] = useState('medium');
  const [count, setCount] = useState(5);
  const [generating, setGenerating] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleGenerate = async () => {
    if (!topic.trim()) {
      setError('Enter a topic first.');
      return;
    }
    setGenerating(true);
    setError(null);
    try {
      const quiz = await generateQuiz(topic.trim(), difficulty, count);
      navigation.navigate('QuizTake', { quiz });
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Could not generate a quiz right now.');
    } finally {
      setGenerating(false);
    }
  };

  return (
    <KeyboardAvoidingView style={{ flex: 1, backgroundColor: theme.colors.background }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <ScrollView contentContainerStyle={{ padding: theme.spacing(6) }}>
        <Text style={{ color: theme.colors.text, fontSize: theme.fontSize.xxl, fontWeight: '800', marginTop: theme.spacing(10), marginBottom: theme.spacing(2) }}>
          Quiz Generator
        </Text>
        <Text style={{ color: theme.colors.textMuted, marginBottom: theme.spacing(5) }}>
          Practice questions on any topic, generated instantly.
        </Text>

        <TextField label="Topic" placeholder="e.g. Photosynthesis, WWII causes, Quadratic equations" value={topic} onChangeText={setTopic} />

        <Text style={{ color: theme.colors.textMuted, fontSize: 13, fontWeight: '600', marginBottom: 8 }}>Difficulty</Text>
        <View style={{ flexDirection: 'row', gap: 8, marginBottom: theme.spacing(4) }}>
          {DIFFICULTIES.map((d) => (
            <Pressable
              key={d}
              onPress={() => setDifficulty(d)}
              style={{
                flex: 1,
                paddingVertical: 10,
                borderRadius: theme.radius.md,
                alignItems: 'center',
                backgroundColor: difficulty === d ? theme.colors.primary : theme.colors.inputBackground,
              }}
            >
              <Text style={{ color: difficulty === d ? theme.colors.textInverse : theme.colors.text, fontWeight: '600', textTransform: 'capitalize' }}>
                {d}
              </Text>
            </Pressable>
          ))}
        </View>

        <Text style={{ color: theme.colors.textMuted, fontSize: 13, fontWeight: '600', marginBottom: 8 }}>Number of questions</Text>
        <View style={{ flexDirection: 'row', gap: 8, marginBottom: theme.spacing(5) }}>
          {COUNTS.map((c) => (
            <Pressable
              key={c}
              onPress={() => setCount(c)}
              style={{
                flex: 1,
                paddingVertical: 10,
                borderRadius: theme.radius.md,
                alignItems: 'center',
                backgroundColor: count === c ? theme.colors.primary : theme.colors.inputBackground,
              }}
            >
              <Text style={{ color: count === c ? theme.colors.textInverse : theme.colors.text, fontWeight: '600' }}>{c}</Text>
            </Pressable>
          ))}
        </View>

        {error ? <Text style={{ color: theme.colors.danger, marginBottom: 12 }}>{error}</Text> : null}

        <Button title="Generate Quiz" onPress={handleGenerate} loading={generating} />
      </ScrollView>
    </KeyboardAvoidingView>
  );
}
