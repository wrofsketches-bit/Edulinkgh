import React, { useCallback, useState } from 'react';
import { ScrollView, Text, View } from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import type { NativeStackScreenProps } from '@react-navigation/native-stack';
import { getStudentProgress } from '../../api/gamification';
import { ApiError } from '../../api/client';
import { Achievement, StudentProgress } from '../../api/types';
import { useAppTheme } from '../../theme/ThemeContext';
import { GlassCard } from '../../components/GlassCard';
import { Skeleton } from '../../components/Skeleton';
import type { StudentStackParamList } from '../../navigation/types';

type Props = NativeStackScreenProps<StudentStackParamList, 'Progress'>;

function AchievementCard({ achievement }: { achievement: Achievement }) {
  const { theme } = useAppTheme();
  return (
    <GlassCard
      style={{
        flexBasis: '48%',
        marginBottom: theme.spacing(3),
        opacity: achievement.unlocked ? 1 : 0.45,
      }}
    >
      <Text style={{ fontSize: 28, marginBottom: 6 }}>{achievement.icon}</Text>
      <Text style={{ color: theme.colors.text, fontWeight: '700', fontSize: 13 }}>{achievement.title}</Text>
      <Text style={{ color: theme.colors.textMuted, fontSize: 12, marginTop: 2 }}>{achievement.description}</Text>
    </GlassCard>
  );
}

export function ProgressScreen({ navigation }: Props) {
  const { theme } = useAppTheme();
  const [progress, setProgress] = useState<StudentProgress | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [celebration, setCelebration] = useState<Achievement | null>(null);

  useFocusEffect(
    useCallback(() => {
      (async () => {
        try {
          const result = await getStudentProgress();
          setProgress(result);
          if (result.newlyUnlocked.length > 0) {
            setCelebration(result.newlyUnlocked[0]);
          }
        } catch (err) {
          setError(err instanceof ApiError ? err.message : 'Could not load your progress');
        } finally {
          setLoading(false);
        }
      })();
    }, [])
  );

  if (loading) {
    return (
      <View style={{ flex: 1, backgroundColor: theme.colors.background, padding: theme.spacing(6) }}>
        <Skeleton height={100} style={{ marginTop: 60, marginBottom: 20 }} />
        <Skeleton height={200} />
      </View>
    );
  }

  return (
    <ScrollView style={{ flex: 1, backgroundColor: theme.colors.background }} contentContainerStyle={{ padding: theme.spacing(6) }}>
      <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', marginTop: theme.spacing(10), marginBottom: theme.spacing(5) }}>
        <Text style={{ color: theme.colors.text, fontSize: theme.fontSize.xxl, fontWeight: '800' }}>
          My Progress
        </Text>
        <Text onPress={() => navigation.navigate('Insights')} style={{ color: theme.colors.primary, fontWeight: '600', marginTop: 6 }}>
          Insights →
        </Text>
      </View>

      {error ? <Text style={{ color: theme.colors.danger, marginBottom: 12 }}>{error}</Text> : null}

      {celebration ? (
        <GlassCard style={{ marginBottom: theme.spacing(5), alignItems: 'center' }}>
          <Text style={{ fontSize: 40 }}>{celebration.icon}</Text>
          <Text style={{ color: theme.colors.text, fontWeight: '800', fontSize: theme.fontSize.lg, marginTop: 8 }}>
            Achievement Unlocked!
          </Text>
          <Text style={{ color: theme.colors.primary, fontWeight: '700', marginTop: 4 }}>{celebration.title}</Text>
          <Text style={{ color: theme.colors.textMuted, marginTop: 4, textAlign: 'center' }}>{celebration.description}</Text>
        </GlassCard>
      ) : null}

      {progress ? (
        <>
          <View style={{ flexDirection: 'row', gap: theme.spacing(3), marginBottom: theme.spacing(5) }}>
            <GlassCard style={{ flex: 1, alignItems: 'center' }}>
              <Text style={{ fontSize: 28 }}>🔥</Text>
              <Text style={{ color: theme.colors.text, fontSize: theme.fontSize.xl, fontWeight: '800', marginTop: 4 }}>
                {progress.currentStreakDays}
              </Text>
              <Text style={{ color: theme.colors.textMuted, fontSize: 12 }}>day streak</Text>
            </GlassCard>
            <GlassCard style={{ flex: 1, alignItems: 'center' }}>
              <Text style={{ fontSize: 28 }}>📈</Text>
              <Text style={{ color: theme.colors.text, fontSize: theme.fontSize.xl, fontWeight: '800', marginTop: 4 }}>
                {progress.longestStreakDays}
              </Text>
              <Text style={{ color: theme.colors.textMuted, fontSize: 12 }}>best streak</Text>
            </GlassCard>
            <GlassCard style={{ flex: 1, alignItems: 'center' }}>
              <Text style={{ fontSize: 28 }}>✅</Text>
              <Text style={{ color: theme.colors.text, fontSize: theme.fontSize.xl, fontWeight: '800', marginTop: 4 }}>
                {progress.completedSessionCount}
              </Text>
              <Text style={{ color: theme.colors.textMuted, fontSize: 12 }}>sessions</Text>
            </GlassCard>
          </View>

          <Text style={{ color: theme.colors.textMuted, fontSize: 12, marginBottom: theme.spacing(5) }}>
            Your streak counts consecutive days with a completed session — it resets if a day passes with none, even between regularly scheduled sessions.
          </Text>

          <Text style={{ color: theme.colors.text, fontSize: theme.fontSize.lg, fontWeight: '700', marginBottom: theme.spacing(3) }}>
            Achievements
          </Text>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between' }}>
            {progress.achievements.map((a) => (
              <AchievementCard key={a.id} achievement={a} />
            ))}
          </View>
        </>
      ) : null}
    </ScrollView>
  );
}
