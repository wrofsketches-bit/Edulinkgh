import React, { useState } from 'react';
import { FlatList, KeyboardAvoidingView, Platform, ScrollView, Text, View } from 'react-native';
import type { NativeStackScreenProps } from '@react-navigation/native-stack';
import { matchTeachers } from '../../api/matching';
import { ApiError } from '../../api/client';
import { TeacherMatch } from '../../api/types';
import { useAppTheme } from '../../theme/ThemeContext';
import { GlassCard } from '../../components/GlassCard';
import { Badge } from '../../components/Badge';
import { Button } from '../../components/Button';
import { TextField } from '../../components/TextField';
import type { StudentStackParamList } from '../../navigation/types';

type Props = NativeStackScreenProps<StudentStackParamList, 'TeacherMatching'>;

export function TeacherMatchingScreen({ navigation }: Props) {
  const { theme } = useAppTheme();
  const [request, setRequest] = useState('');
  const [results, setResults] = useState<TeacherMatch[] | null>(null);
  const [searching, setSearching] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSearch = async () => {
    if (!request.trim()) {
      setError('Describe what you need first.');
      return;
    }
    setSearching(true);
    setError(null);
    setResults(null);
    try {
      const matches = await matchTeachers(request.trim());
      setResults(matches);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Could not find matches right now.');
    } finally {
      setSearching(false);
    }
  };

  return (
    <KeyboardAvoidingView style={{ flex: 1, backgroundColor: theme.colors.background }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <ScrollView contentContainerStyle={{ padding: theme.spacing(6) }} keyboardShouldPersistTaps="handled">
        <Text style={{ color: theme.colors.text, fontSize: theme.fontSize.xxl, fontWeight: '800', marginTop: theme.spacing(10), marginBottom: theme.spacing(2) }}>
          Find My Match
        </Text>
        <Text style={{ color: theme.colors.textMuted, marginBottom: theme.spacing(5) }}>
          Describe what you're looking for in your own words.
        </Text>

        <TextField
          placeholder="e.g. I need a patient WASSCE Core Maths tutor who can help with algebra, evenings preferred"
          value={request}
          onChangeText={setRequest}
          multiline
        />

        {error ? <Text style={{ color: theme.colors.danger, marginBottom: 12 }}>{error}</Text> : null}

        <Button title="Find Teachers" onPress={handleSearch} loading={searching} />

        {results !== null ? (
          <View style={{ marginTop: theme.spacing(6) }}>
            {results.length === 0 ? (
              <Text style={{ color: theme.colors.textMuted, textAlign: 'center', marginTop: 20 }}>
                No strong matches found — try describing it a bit differently.
              </Text>
            ) : (
              results.map((teacher) => (
                <GlassCard
                  key={teacher.id}
                  style={{ marginBottom: theme.spacing(3) }}
                  onTouchEnd={() => navigation.navigate('TeacherProfile', { teacherId: teacher.id })}
                >
                  <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
                    <Text style={{ color: theme.colors.text, fontSize: theme.fontSize.lg, fontWeight: '700' }}>
                      {teacher.fullName}
                    </Text>
                    {teacher.qualificationVerified ? <Badge label="Verified" tone="success" /> : null}
                  </View>
                  <Text style={{ color: theme.colors.textMuted, marginTop: 4 }}>
                    {teacher.subject || 'Subject not specified'} · {teacher.teachingLevel || 'All levels'}
                  </Text>
                  <Text style={{ color: theme.colors.primary, marginTop: 8, fontStyle: 'italic' }}>
                    {teacher.matchReason}
                  </Text>
                </GlassCard>
              ))
            )}
          </View>
        ) : null}
      </ScrollView>
    </KeyboardAvoidingView>
  );
}
