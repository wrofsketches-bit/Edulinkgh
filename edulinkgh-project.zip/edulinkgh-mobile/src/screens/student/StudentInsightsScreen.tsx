import React, { useCallback, useState } from 'react';
import { RefreshControl, ScrollView, Text, View } from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { getStudentInsights } from '../../api/studentInsights';
import { ApiError } from '../../api/client';
import { StudentInsights } from '../../api/types';
import { useAppTheme } from '../../theme/ThemeContext';
import { GlassCard } from '../../components/GlassCard';
import { AnalyticsLineChart } from '../../components/AnalyticsLineChart';
import { Skeleton } from '../../components/Skeleton';

function formatMinutes(minutes: number): string {
  const hours = Math.floor(minutes / 60);
  const mins = minutes % 60;
  if (hours === 0) return `${mins}m`;
  return `${hours}h ${mins}m`;
}

export function StudentInsightsScreen() {
  const { theme } = useAppTheme();
  const [insights, setInsights] = useState<StudentInsights | null>(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    try {
      const result = await getStudentInsights(30);
      setInsights(result);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Could not load your insights');
    }
  }, []);

  useFocusEffect(
    useCallback(() => {
      setLoading(true);
      load().finally(() => setLoading(false));
      // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [])
  );

  const onRefresh = async () => {
    setRefreshing(true);
    await load();
    setRefreshing(false);
  };

  const maxSubjectCount = insights?.subjectBreakdown[0]?.sessionCount ?? 1;

  return (
    <ScrollView
      style={{ flex: 1, backgroundColor: theme.colors.background }}
      contentContainerStyle={{ padding: theme.spacing(6) }}
      refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={theme.colors.primary} />}
    >
      <Text style={{ color: theme.colors.text, fontSize: theme.fontSize.xxl, fontWeight: '800', marginTop: theme.spacing(10), marginBottom: theme.spacing(5) }}>
        Learning Insights
      </Text>

      {error ? <Text style={{ color: theme.colors.danger, marginBottom: 12 }}>{error}</Text> : null}

      {loading ? (
        <View>
          <Skeleton height={100} style={{ marginBottom: 16 }} />
          <Skeleton height={220} />
        </View>
      ) : insights ? (
        <>
          <View style={{ flexDirection: 'row', gap: theme.spacing(3), marginBottom: theme.spacing(5) }}>
            <GlassCard style={{ flex: 1, alignItems: 'center' }}>
              <Text style={{ color: theme.colors.text, fontSize: theme.fontSize.xl, fontWeight: '800' }}>
                {insights.totalSessionsCompleted}
              </Text>
              <Text style={{ color: theme.colors.textMuted, fontSize: 12, marginTop: 2 }}>sessions</Text>
            </GlassCard>
            <GlassCard style={{ flex: 1, alignItems: 'center' }}>
              <Text style={{ color: theme.colors.text, fontSize: theme.fontSize.xl, fontWeight: '800' }}>
                {formatMinutes(insights.totalMinutesLearned)}
              </Text>
              <Text style={{ color: theme.colors.textMuted, fontSize: 12, marginTop: 2 }}>learning time</Text>
            </GlassCard>
            <GlassCard style={{ flex: 1, alignItems: 'center' }}>
              <Text style={{ color: theme.colors.text, fontSize: theme.fontSize.xl, fontWeight: '800' }}>
                {insights.distinctTeachersStudiedWith}
              </Text>
              <Text style={{ color: theme.colors.textMuted, fontSize: 12, marginTop: 2 }}>teachers</Text>
            </GlassCard>
          </View>

          <GlassCard style={{ marginBottom: theme.spacing(5) }}>
            <Text style={{ color: theme.colors.textMuted, fontSize: 13, fontWeight: '700', marginBottom: theme.spacing(3) }}>
              SESSIONS OVER TIME (LAST {insights.windowDays} DAYS)
            </Text>
            <AnalyticsLineChart data={insights.sessionsSeries} />
          </GlassCard>

          <Text style={{ color: theme.colors.text, fontSize: theme.fontSize.lg, fontWeight: '700', marginBottom: theme.spacing(3) }}>
            By Subject
          </Text>
          {insights.subjectBreakdown.length === 0 ? (
            <Text style={{ color: theme.colors.textMuted }}>No completed sessions yet.</Text>
          ) : (
            insights.subjectBreakdown.map((item) => (
              <GlassCard key={item.subject} style={{ marginBottom: theme.spacing(2.5) }}>
                <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginBottom: 6 }}>
                  <Text style={{ color: theme.colors.text, fontWeight: '600' }}>{item.subject}</Text>
                  <Text style={{ color: theme.colors.textMuted }}>{item.sessionCount} session{item.sessionCount === 1 ? '' : 's'}</Text>
                </View>
                <View style={{ height: 6, backgroundColor: theme.colors.inputBackground, borderRadius: 3 }}>
                  <View
                    style={{
                      height: 6,
                      width: `${Math.max(6, (item.sessionCount / maxSubjectCount) * 100)}%`,
                      backgroundColor: theme.colors.primary,
                      borderRadius: 3,
                    }}
                  />
                </View>
              </GlassCard>
            ))
          )}
        </>
      ) : null}
    </ScrollView>
  );
}
