import React, { useState } from 'react';
import { ScrollView, Text, View } from 'react-native';
import type { NativeStackScreenProps } from '@react-navigation/native-stack';
import { useAppTheme } from '../../theme/ThemeContext';
import { GlassCard } from '../../components/GlassCard';
import { Button } from '../../components/Button';
import type { StudentStackParamList } from '../../navigation/types';

type Props = NativeStackScreenProps<StudentStackParamList, 'QuizTake'>;

export function QuizTakeScreen({ route, navigation }: Props) {
  const { quiz } = route.params;
  const { theme } = useAppTheme();
  const [answers, setAnswers] = useState<Record<number, number>>({});
  const [submitted, setSubmitted] = useState(false);

  const selectAnswer = (questionIndex: number, optionIndex: number) => {
    if (submitted) return;
    setAnswers((prev) => ({ ...prev, [questionIndex]: optionIndex }));
  };

  const score = quiz.questions.reduce(
    (sum, q, i) => sum + (answers[i] === q.correctIndex ? 1 : 0),
    0
  );
  const allAnswered = Object.keys(answers).length === quiz.questions.length;

  return (
    <ScrollView style={{ flex: 1, backgroundColor: theme.colors.background }} contentContainerStyle={{ padding: theme.spacing(6) }}>
      <Text style={{ color: theme.colors.text, fontSize: theme.fontSize.xxl, fontWeight: '800', marginTop: theme.spacing(10), marginBottom: theme.spacing(2) }}>
        {quiz.topic}
      </Text>
      {quiz.difficulty ? (
        <Text style={{ color: theme.colors.textMuted, marginBottom: theme.spacing(5), textTransform: 'capitalize' }}>
          {quiz.difficulty} · {quiz.questions.length} questions
        </Text>
      ) : null}

      {submitted ? (
        <GlassCard style={{ marginBottom: theme.spacing(5) }}>
          <Text style={{ color: theme.colors.text, fontSize: theme.fontSize.lg, fontWeight: '800', textAlign: 'center' }}>
            Score: {score} / {quiz.questions.length}
          </Text>
        </GlassCard>
      ) : null}

      {quiz.questions.map((q, qi) => {
        const selected = answers[qi];
        return (
          <GlassCard key={qi} style={{ marginBottom: theme.spacing(4) }}>
            <Text style={{ color: theme.colors.text, fontWeight: '700', marginBottom: theme.spacing(3) }}>
              {qi + 1}. {q.question}
            </Text>
            {q.options.map((option, oi) => {
              const isSelected = selected === oi;
              const isCorrect = oi === q.correctIndex;
              let bg = theme.colors.inputBackground;
              let fg = theme.colors.text;
              if (submitted) {
                if (isCorrect) {
                  bg = theme.mode === 'dark' ? 'rgba(52,211,153,0.18)' : '#DCFCE7';
                  fg = theme.colors.success;
                } else if (isSelected && !isCorrect) {
                  bg = theme.mode === 'dark' ? 'rgba(248,113,113,0.18)' : '#FEE2E2';
                  fg = theme.colors.danger;
                }
              } else if (isSelected) {
                bg = theme.colors.primaryMuted;
                fg = theme.colors.primary;
              }
              return (
                <Text
                  key={oi}
                  onPress={() => selectAnswer(qi, oi)}
                  style={{
                    backgroundColor: bg,
                    color: fg,
                    padding: theme.spacing(3),
                    borderRadius: theme.radius.md,
                    marginBottom: 8,
                    fontWeight: isSelected || (submitted && isCorrect) ? '700' : '400',
                  }}
                >
                  {option}
                </Text>
              );
            })}
            {submitted ? (
              <Text style={{ color: theme.colors.textMuted, marginTop: 4, fontStyle: 'italic' }}>{q.explanation}</Text>
            ) : null}
          </GlassCard>
        );
      })}

      <View style={{ marginBottom: theme.spacing(10) }}>
        {submitted ? (
          <Button title="Generate Another" onPress={() => navigation.goBack()} variant="outline" />
        ) : (
          <Button title="Submit" onPress={() => setSubmitted(true)} disabled={!allAnswered} />
        )}
      </View>
    </ScrollView>
  );
}
