import React, { useEffect, useState } from 'react';
import { ScrollView, Text, View } from 'react-native';
import type { NativeStackScreenProps } from '@react-navigation/native-stack';
import { getTeacher, getTeacherRatings } from '../../api/teachers';
import { getTeacherAvailability } from '../../api/availability';
import { ApiError } from '../../api/client';
import { AvailabilityWindow, Rating, TeacherSummary } from '../../api/types';
import { useAppTheme } from '../../theme/ThemeContext';
import { GlassCard } from '../../components/GlassCard';
import { Badge } from '../../components/Badge';
import { Button } from '../../components/Button';
import { Skeleton } from '../../components/Skeleton';
import { WeeklyAvailabilityGrid } from '../../components/WeeklyAvailabilityGrid';
import type { StudentStackParamList } from '../../navigation/types';

type Props = NativeStackScreenProps<StudentStackParamList, 'TeacherProfile'>;

export function TeacherProfileScreen({ route, navigation }: Props) {
  const { teacherId } = route.params;
  const { theme } = useAppTheme();
  const [teacher, setTeacher] = useState<TeacherSummary | null>(null);
  const [ratings, setRatings] = useState<Rating[]>([]);
  const [availability, setAvailability] = useState<AvailabilityWindow[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    (async () => {
      try {
        const [t, r, a] = await Promise.all([
          getTeacher(teacherId),
          getTeacherRatings(teacherId),
          getTeacherAvailability(teacherId),
        ]);
        setTeacher(t);
        setRatings(r);
        setAvailability(a);
      } catch (err) {
        setError(err instanceof ApiError ? err.message : 'Could not load teacher profile');
      } finally {
        setLoading(false);
      }
    })();
  }, [teacherId]);

  if (loading) {
    return (
      <View style={{ flex: 1, backgroundColor: theme.colors.background, padding: theme.spacing(6) }}>
        <Skeleton height={28} width="60%" style={{ marginTop: 60, marginBottom: 16 }} />
        <Skeleton height={16} width="40%" style={{ marginBottom: 24 }} />
        <Skeleton height={100} />
      </View>
    );
  }

  if (error || !teacher) {
    return (
      <View style={{ flex: 1, backgroundColor: theme.colors.background, padding: theme.spacing(6), justifyContent: 'center' }}>
        <Text style={{ color: theme.colors.danger, textAlign: 'center' }}>{error || 'Teacher not found'}</Text>
      </View>
    );
  }

  return (
    <ScrollView style={{ flex: 1, backgroundColor: theme.colors.background }} contentContainerStyle={{ padding: theme.spacing(6) }}>
      <View style={{ marginTop: theme.spacing(10), marginBottom: theme.spacing(5) }}>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
          <Text style={{ color: theme.colors.text, fontSize: theme.fontSize.xxl, fontWeight: '800' }}>
            {teacher.fullName}
          </Text>
          {teacher.qualificationVerified ? <Badge label="Verified" tone="success" /> : null}
        </View>
        <Text style={{ color: theme.colors.textMuted, marginTop: 6, fontSize: theme.fontSize.md }}>
          {teacher.subject || 'Subject not specified'} · {teacher.teachingLevel || 'All levels'}
        </Text>
        {teacher.averageRating ? (
          <Text style={{ color: theme.colors.warning, marginTop: 8, fontWeight: '700' }}>
            ★ {teacher.averageRating.toFixed(1)} average ({teacher.ratingCount ?? 0} reviews)
          </Text>
        ) : null}
      </View>

      {teacher.bio ? (
        <GlassCard style={{ marginBottom: theme.spacing(5) }}>
          <Text style={{ color: theme.colors.text, fontSize: theme.fontSize.md, lineHeight: 22 }}>{teacher.bio}</Text>
        </GlassCard>
      ) : null}

      {teacher.qualification ? (
        <GlassCard style={{ marginBottom: theme.spacing(5) }}>
          <Text style={{ color: theme.colors.textMuted, fontSize: 13, fontWeight: '700', marginBottom: 4 }}>
            QUALIFICATION
          </Text>
          <Text style={{ color: theme.colors.text }}>{teacher.qualification}</Text>
        </GlassCard>
      ) : null}

      <Text style={{ color: theme.colors.text, fontSize: theme.fontSize.lg, fontWeight: '700', marginBottom: theme.spacing(3) }}>
        Weekly Availability
      </Text>
      <GlassCard style={{ marginBottom: theme.spacing(6) }}>
        <WeeklyAvailabilityGrid windows={availability} />
      </GlassCard>

      <Text style={{ color: theme.colors.text, fontSize: theme.fontSize.lg, fontWeight: '700', marginBottom: theme.spacing(3) }}>
        Reviews
      </Text>
      {ratings.length === 0 ? (
        <Text style={{ color: theme.colors.textMuted, marginBottom: theme.spacing(6) }}>No reviews yet.</Text>
      ) : (
        ratings.map((r) => (
          <GlassCard key={r.id} style={{ marginBottom: theme.spacing(3) }}>
            <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
              <Text style={{ color: theme.colors.text, fontWeight: '700' }}>{r.studentName}</Text>
              <Text style={{ color: theme.colors.warning, fontWeight: '700' }}>{'★'.repeat(r.stars)}</Text>
            </View>
            {r.comment ? <Text style={{ color: theme.colors.textMuted, marginTop: 6 }}>{r.comment}</Text> : null}
          </GlassCard>
        ))
      )}

      <View style={{ marginTop: theme.spacing(6), marginBottom: theme.spacing(10), gap: theme.spacing(3) }}>
        <Button title="Book a Session" onPress={() => navigation.navigate('BookSession', { teacherId })} />
        <Button
          title="Message Teacher"
          variant="outline"
          onPress={() => navigation.navigate('Conversation', { userId: teacher.id, userName: teacher.fullName })}
        />
      </View>
    </ScrollView>
  );
}
