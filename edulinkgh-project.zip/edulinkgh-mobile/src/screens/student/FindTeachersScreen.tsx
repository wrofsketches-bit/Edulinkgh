import React, { useCallback, useEffect, useState } from 'react';
import { FlatList, Pressable, RefreshControl, StyleSheet, Text, View } from 'react-native';
import type { NativeStackScreenProps } from '@react-navigation/native-stack';
import { CompositeScreenProps } from '@react-navigation/native';
import { searchTeachers } from '../../api/teachers';
import { ApiError } from '../../api/client';
import { TeacherSummary } from '../../api/types';
import { useAppTheme } from '../../theme/ThemeContext';
import { GlassCard } from '../../components/GlassCard';
import { Badge } from '../../components/Badge';
import { TextField } from '../../components/TextField';
import { TeacherCardSkeleton } from '../../components/Skeleton';
import type { StudentStackParamList, StudentTabParamList } from '../../navigation/types';
import type { BottomTabScreenProps } from '@react-navigation/bottom-tabs';

type Props = CompositeScreenProps<
  BottomTabScreenProps<StudentTabParamList, 'FindTeachers'>,
  NativeStackScreenProps<StudentStackParamList>
>;

export function FindTeachersScreen({ navigation }: Props) {
  const { theme } = useAppTheme();
  const [query, setQuery] = useState('');
  const [teachers, setTeachers] = useState<TeacherSummary[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async (search?: string) => {
    setError(null);
    try {
      const results = await searchTeachers(search ? { search } : {});
      setTeachers(results);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Could not load teachers');
    }
  }, []);

  useEffect(() => {
    setLoading(true);
    load().finally(() => setLoading(false));
  }, [load]);

  const onRefresh = async () => {
    setRefreshing(true);
    await load(query);
    setRefreshing(false);
  };

  // Debounce-free simple search-on-submit to keep it predictable for now.
  const onSearchSubmit = () => {
    setLoading(true);
    load(query).finally(() => setLoading(false));
  };

  return (
    <View style={{ flex: 1, backgroundColor: theme.colors.background, paddingHorizontal: theme.spacing(5) }}>
      <View style={{ marginTop: theme.spacing(14), marginBottom: theme.spacing(3) }}>
        <Text style={{ color: theme.colors.text, fontSize: theme.fontSize.xxl, fontWeight: '800' }}>
          Find a teacher
        </Text>
        <Text style={{ color: theme.colors.textMuted, marginTop: 4 }}>
          Search by subject, name, or level
        </Text>
      </View>

      <Pressable onPress={() => navigation.navigate('Progress')} style={{ marginBottom: theme.spacing(3) }}>
        <GlassCard>
          <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
            <View style={{ flex: 1 }}>
              <Text style={{ color: theme.colors.text, fontWeight: '700' }}>🔥 My Progress</Text>
              <Text style={{ color: theme.colors.textMuted, marginTop: 2, fontSize: 13 }}>
                Streaks, achievements, and your learning stats.
              </Text>
            </View>
            <Text style={{ color: theme.colors.primary, fontWeight: '700' }}>→</Text>
          </View>
        </GlassCard>
      </Pressable>

      <Pressable onPress={() => navigation.navigate('HomeworkHelper')} style={{ marginBottom: theme.spacing(3) }}>
        <GlassCard>
          <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
            <View style={{ flex: 1 }}>
              <Text style={{ color: theme.colors.text, fontWeight: '700' }}>🤖 Homework Helper</Text>
              <Text style={{ color: theme.colors.textMuted, marginTop: 2, fontSize: 13 }}>
                Stuck on something? Get help understanding it.
              </Text>
            </View>
            <Text style={{ color: theme.colors.primary, fontWeight: '700' }}>→</Text>
          </View>
        </GlassCard>
      </Pressable>

      <Pressable onPress={() => navigation.navigate('QuizGenerator')} style={{ marginBottom: theme.spacing(3) }}>
        <GlassCard>
          <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
            <View style={{ flex: 1 }}>
              <Text style={{ color: theme.colors.text, fontWeight: '700' }}>📝 Quiz Generator</Text>
              <Text style={{ color: theme.colors.textMuted, marginTop: 2, fontSize: 13 }}>
                Practice questions on any topic.
              </Text>
            </View>
            <Text style={{ color: theme.colors.primary, fontWeight: '700' }}>→</Text>
          </View>
        </GlassCard>
      </Pressable>

      <Pressable onPress={() => navigation.navigate('TeacherMatching')} style={{ marginBottom: theme.spacing(4) }}>
        <GlassCard>
          <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
            <View style={{ flex: 1 }}>
              <Text style={{ color: theme.colors.text, fontWeight: '700' }}>🎯 Find My Match</Text>
              <Text style={{ color: theme.colors.textMuted, marginTop: 2, fontSize: 13 }}>
                Describe what you need, get matched teachers.
              </Text>
            </View>
            <Text style={{ color: theme.colors.primary, fontWeight: '700' }}>→</Text>
          </View>
        </GlassCard>
      </Pressable>

      <TextField
        placeholder="e.g. Mathematics, Mr. Owusu, WASSCE"
        value={query}
        onChangeText={setQuery}
        onSubmitEditing={onSearchSubmit}
        returnKeyType="search"
      />

      {error ? <Text style={{ color: theme.colors.danger, marginBottom: 12 }}>{error}</Text> : null}

      {loading ? (
        <View>
          <TeacherCardSkeleton />
          <TeacherCardSkeleton />
          <TeacherCardSkeleton />
        </View>
      ) : (
        <FlatList
          data={teachers}
          keyExtractor={(item) => String(item.id)}
          refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={theme.colors.primary} />}
          ListEmptyComponent={
            <Text style={{ color: theme.colors.textMuted, textAlign: 'center', marginTop: 40 }}>
              No teachers found. Try a different search.
            </Text>
          }
          contentContainerStyle={{ paddingBottom: theme.spacing(10) }}
          renderItem={({ item }) => (
            <GlassCard
              style={{ marginBottom: theme.spacing(3) }}
              onTouchEnd={() => navigation.navigate('TeacherProfile', { teacherId: item.id })}
            >
              <View style={styles.row}>
                <View style={{ flex: 1 }}>
                  <View style={styles.nameRow}>
                    <Text style={{ color: theme.colors.text, fontSize: theme.fontSize.lg, fontWeight: '700' }}>
                      {item.fullName}
                    </Text>
                    {item.qualificationVerified ? <Badge label="Verified" tone="success" /> : null}
                  </View>
                  <Text style={{ color: theme.colors.textMuted, marginTop: 4 }}>
                    {item.subject || 'Subject not specified'} · {item.teachingLevel || 'All levels'}
                  </Text>
                  {item.averageRating ? (
                    <Text style={{ color: theme.colors.warning, marginTop: 6, fontWeight: '600' }}>
                      ★ {item.averageRating.toFixed(1)} ({item.ratingCount ?? 0})
                    </Text>
                  ) : (
                    <Text style={{ color: theme.colors.textMuted, marginTop: 6 }}>No ratings yet</Text>
                  )}
                </View>
              </View>
            </GlassCard>
          )}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  row: { flexDirection: 'row', alignItems: 'center' },
  nameRow: { flexDirection: 'row', alignItems: 'center', gap: 8 },
});
