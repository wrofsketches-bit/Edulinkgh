import React, { useCallback, useEffect, useState } from 'react';
import { ScrollView, Text, View } from 'react-native';
import { cancelSession, endSession, getSession, startSession } from '../api/sessions';
import { getLessonSummary } from '../api/lessonSummary';
import { ApiError } from '../api/client';
import { LessonSummary, SessionItem } from '../api/types';
import { useAppTheme } from '../theme/ThemeContext';
import { useAuth } from '../context/AuthContext';
import { GlassCard } from '../components/GlassCard';
import { Badge } from '../components/Badge';
import { Button } from '../components/Button';
import { Skeleton } from '../components/Skeleton';

interface Props {
  route: { params: { sessionId: number } };
  navigation: { goBack: () => void; navigate: (screen: 'VideoCall', params: { sessionId: number }) => void };
}

const statusTone: Record<SessionItem['status'], 'primary' | 'success' | 'neutral' | 'danger'> = {
  UPCOMING: 'primary',
  LIVE: 'success',
  COMPLETED: 'neutral',
  CANCELLED: 'danger',
};

export function SessionDetailScreen({ route, navigation }: Props) {
  const { sessionId } = route.params;
  const { theme } = useAppTheme();
  const { user } = useAuth();
  const [session, setSession] = useState<SessionItem | null>(null);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [summary, setSummary] = useState<LessonSummary | null>(null);
  const [summaryLoading, setSummaryLoading] = useState(false);
  const [summaryError, setSummaryError] = useState<string | null>(null);

  const load = useCallback(async () => {
    try {
      const s = await getSession(sessionId);
      setSession(s);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Could not load session');
    } finally {
      setLoading(false);
    }
  }, [sessionId]);

  useEffect(() => {
    load();
  }, [load]);

  const isTeacher = user?.role === 'TEACHER' && session?.teacher.id === user.userId;

  const handleGetSummary = async () => {
    if (!session) return;
    setSummaryLoading(true);
    setSummaryError(null);
    try {
      const result = await getLessonSummary(session.id);
      setSummary(result);
    } catch (err) {
      setSummaryError(err instanceof ApiError ? err.message : 'Could not generate a summary right now.');
    } finally {
      setSummaryLoading(false);
    }
  };

  const runAction = async (action: () => Promise<unknown>) => {
    setBusy(true);
    setError(null);
    try {
      await action();
      await load();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Action failed');
    } finally {
      setBusy(false);
    }
  };

  if (loading) {
    return (
      <View style={{ flex: 1, backgroundColor: theme.colors.background, padding: theme.spacing(6) }}>
        <Skeleton height={30} width="70%" style={{ marginTop: 60, marginBottom: 20 }} />
        <Skeleton height={120} />
      </View>
    );
  }

  if (error || !session) {
    return (
      <View style={{ flex: 1, backgroundColor: theme.colors.background, padding: theme.spacing(6), justifyContent: 'center' }}>
        <Text style={{ color: theme.colors.danger, textAlign: 'center' }}>{error || 'Session not found'}</Text>
      </View>
    );
  }

  return (
    <ScrollView style={{ flex: 1, backgroundColor: theme.colors.background }} contentContainerStyle={{ padding: theme.spacing(6) }}>
      <View style={{ marginTop: theme.spacing(10), marginBottom: theme.spacing(5) }}>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
          <Text style={{ color: theme.colors.text, fontSize: theme.fontSize.xxl, fontWeight: '800' }}>
            {session.subject}
          </Text>
          <Badge label={session.status} tone={statusTone[session.status]} />
        </View>
        <Text style={{ color: theme.colors.textMuted, marginTop: 6 }}>
          with {session.teacher.fullName}
        </Text>
      </View>

      <GlassCard style={{ marginBottom: theme.spacing(5) }}>
        <Text style={{ color: theme.colors.text }}>
          {new Date(session.scheduledAt).toLocaleString()} · {session.durationMinutes} min
        </Text>
        <Text style={{ color: theme.colors.primary, fontWeight: '700', marginTop: 8 }}>
          GHC {session.feeGhc.toFixed(2)}
        </Text>
        {session.description ? (
          <Text style={{ color: theme.colors.textMuted, marginTop: 10 }}>{session.description}</Text>
        ) : null}
      </GlassCard>

      {session.status === 'LIVE' ? (
        <Button
          title="Join Video Call"
          onPress={() => navigation.navigate('VideoCall', { sessionId: session.id })}
        />
      ) : null}

      <View style={{ marginTop: theme.spacing(5) }}>
        {summary ? (
          <GlassCard>
            <Text style={{ color: theme.colors.textMuted, fontSize: 13, fontWeight: '700', marginBottom: 8 }}>
              TOPIC OVERVIEW
            </Text>
            <Text style={{ color: theme.colors.text, lineHeight: 21 }}>{summary.summary}</Text>
            <Text style={{ color: theme.colors.textMuted, fontSize: 12, marginTop: 12, fontStyle: 'italic' }}>
              {summary.disclaimer}
            </Text>
          </GlassCard>
        ) : (
          <Button title="Get Topic Overview" variant="outline" onPress={handleGetSummary} loading={summaryLoading} />
        )}
        {summaryError ? (
          <Text style={{ color: theme.colors.danger, marginTop: 8 }}>{summaryError}</Text>
        ) : null}
      </View>

      {error ? <Text style={{ color: theme.colors.danger, marginTop: 12 }}>{error}</Text> : null}

      <View style={{ marginTop: theme.spacing(6), gap: theme.spacing(3) }}>
        {isTeacher && session.status === 'UPCOMING' ? (
          <Button title="Start Session" onPress={() => runAction(() => startSession(session.id))} loading={busy} />
        ) : null}
        {isTeacher && session.status === 'LIVE' ? (
          <Button title="End Session" onPress={() => runAction(() => endSession(session.id))} loading={busy} />
        ) : null}
        {session.status === 'UPCOMING' ? (
          <Button
            title="Cancel Session"
            variant="danger"
            onPress={() => runAction(async () => {
              await cancelSession(session.id);
              navigation.goBack();
            })}
            loading={busy}
          />
        ) : null}
      </View>
    </ScrollView>
  );
}
