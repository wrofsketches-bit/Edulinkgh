import React, { useState } from 'react';
import {
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import type { NativeStackScreenProps } from '@react-navigation/native-stack';
import { useAuth } from '../../context/AuthContext';
import { useAppTheme } from '../../theme/ThemeContext';
import { Button } from '../../components/Button';
import { TextField } from '../../components/TextField';
import type { AuthStackParamList } from '../../navigation/types';

type Props = NativeStackScreenProps<AuthStackParamList, 'Login'>;

export function LoginScreen({ navigation }: Props) {
  const { theme } = useAppTheme();
  const { login, isSubmitting, error, clearError } = useAuth();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [fieldErrors, setFieldErrors] = useState<{ email?: string; password?: string }>({});

  const handleSubmit = async () => {
    const errs: typeof fieldErrors = {};
    if (!email.trim()) errs.email = 'Email is required';
    if (!password) errs.password = 'Password is required';
    setFieldErrors(errs);
    if (Object.keys(errs).length > 0) return;

    try {
      await login(email.trim(), password);
    } catch {
      // error surfaced via context
    }
  };

  return (
    <KeyboardAvoidingView
      style={{ flex: 1, backgroundColor: theme.colors.background }}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
    >
      <ScrollView contentContainerStyle={{ flexGrow: 1, padding: theme.spacing(6) }} keyboardShouldPersistTaps="handled">
        <View style={{ marginTop: theme.spacing(16), marginBottom: theme.spacing(10) }}>
          <Text style={[styles.brand, { color: theme.colors.primary }]}>EduLinkGH</Text>
          <Text style={[styles.title, { color: theme.colors.text, fontSize: theme.fontSize.xxl }]}>
            Welcome back
          </Text>
          <Text style={[styles.subtitle, { color: theme.colors.textMuted, fontSize: theme.fontSize.md }]}>
            Log in to continue learning or teaching.
          </Text>
        </View>

        <TextField
          label="Email"
          placeholder="you@example.com"
          autoCapitalize="none"
          keyboardType="email-address"
          value={email}
          onChangeText={(v) => {
            setEmail(v);
            clearError();
          }}
          error={fieldErrors.email}
        />
        <TextField
          label="Password"
          placeholder="••••••••"
          secureTextEntry
          value={password}
          onChangeText={(v) => {
            setPassword(v);
            clearError();
          }}
          error={fieldErrors.password}
        />

        {error ? (
          <Text style={{ color: theme.colors.danger, marginBottom: theme.spacing(3) }}>{error}</Text>
        ) : null}

        <Button title="Log In" onPress={handleSubmit} loading={isSubmitting} />

        <Text
          onPress={() => navigation.navigate('ForgotPassword')}
          style={[styles.link, { color: theme.colors.primary, marginTop: theme.spacing(5) }]}
        >
          Forgot password?
        </Text>

        <View style={{ flex: 1 }} />

        <Text style={{ textAlign: 'center', color: theme.colors.textMuted, marginBottom: theme.spacing(4) }}>
          Don&apos;t have an account?{' '}
          <Text style={{ color: theme.colors.primary, fontWeight: '700' }} onPress={() => navigation.navigate('Register')}>
            Sign up
          </Text>
        </Text>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  brand: { fontWeight: '800', fontSize: 16, marginBottom: 8, letterSpacing: 0.5 },
  title: { fontWeight: '800', marginBottom: 6 },
  subtitle: {},
  link: { fontWeight: '600', textAlign: 'center' },
});
