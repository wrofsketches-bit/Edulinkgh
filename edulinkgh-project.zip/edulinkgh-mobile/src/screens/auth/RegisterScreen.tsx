import React, { useState } from 'react';
import {
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import type { NativeStackScreenProps } from '@react-navigation/native-stack';
import { useAuth } from '../../context/AuthContext';
import { useAppTheme } from '../../theme/ThemeContext';
import { Button } from '../../components/Button';
import { TextField } from '../../components/TextField';
import type { AuthStackParamList } from '../../navigation/types';
import type { Role } from '../../api/types';

type Props = NativeStackScreenProps<AuthStackParamList, 'Register'>;

export function RegisterScreen({ navigation }: Props) {
  const { theme } = useAppTheme();
  const { register, isSubmitting, error, clearError } = useAuth();

  const [role, setRole] = useState<Role>('STUDENT');
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [subject, setSubject] = useState('');
  const [qualification, setQualification] = useState('');
  const [schoolName, setSchoolName] = useState('');
  const [referralCode, setReferralCode] = useState('');
  const [errors, setErrors] = useState<Record<string, string>>({});

  const handleSubmit = async () => {
    const errs: Record<string, string> = {};
    if (!fullName.trim()) errs.fullName = 'Required';
    if (!email.trim()) errs.email = 'Required';
    if (!phone.trim()) errs.phone = 'Required';
    if (!password || password.length < 6) errs.password = 'At least 6 characters';
    setErrors(errs);
    if (Object.keys(errs).length > 0) return;

    try {
      await register({
        fullName: fullName.trim(),
        email: email.trim(),
        phone: phone.trim(),
        password,
        role,
        ...(role === 'STUDENT' ? { schoolName } : { subject, qualification }),
        ...(referralCode.trim() ? { referralCode: referralCode.trim() } : {}),
      });
    } catch {
      // surfaced via context
    }
  };

  return (
    <KeyboardAvoidingView
      style={{ flex: 1, backgroundColor: theme.colors.background }}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
    >
      <ScrollView contentContainerStyle={{ padding: theme.spacing(6) }} keyboardShouldPersistTaps="handled">
        <View style={{ marginTop: theme.spacing(10), marginBottom: theme.spacing(6) }}>
          <Text style={[styles.title, { color: theme.colors.text, fontSize: theme.fontSize.xxl }]}>
            Create your account
          </Text>
          <Text style={{ color: theme.colors.textMuted, fontSize: theme.fontSize.md, marginTop: 6 }}>
            Join as a student or a teacher.
          </Text>
        </View>

        <View style={[styles.roleToggle, { backgroundColor: theme.colors.inputBackground, borderRadius: theme.radius.md }]}>
          {(['STUDENT', 'TEACHER'] as Role[]).map((r) => (
            <Pressable
              key={r}
              onPress={() => setRole(r)}
              style={[
                styles.roleOption,
                {
                  backgroundColor: role === r ? theme.colors.primary : 'transparent',
                  borderRadius: theme.radius.md,
                },
              ]}
            >
              <Text
                style={{
                  color: role === r ? theme.colors.textInverse : theme.colors.textMuted,
                  fontWeight: '700',
                }}
              >
                {r === 'STUDENT' ? 'I\u2019m a Student' : 'I\u2019m a Teacher'}
              </Text>
            </Pressable>
          ))}
        </View>

        <TextField label="Full name" value={fullName} onChangeText={setFullName} error={errors.fullName} />
        <TextField
          label="Email"
          autoCapitalize="none"
          keyboardType="email-address"
          value={email}
          onChangeText={setEmail}
          error={errors.email}
        />
        <TextField label="Phone" keyboardType="phone-pad" value={phone} onChangeText={setPhone} error={errors.phone} />
        <TextField label="Password" secureTextEntry value={password} onChangeText={setPassword} error={errors.password} />

        {role === 'STUDENT' ? (
          <TextField label="School name (optional)" value={schoolName} onChangeText={setSchoolName} />
        ) : (
          <>
            <TextField label="Subject you teach" value={subject} onChangeText={setSubject} />
            <TextField label="Qualification" value={qualification} onChangeText={setQualification} />
          </>
        )}

        <TextField
          label="Referral code (optional)"
          placeholder="Got a code from a friend?"
          autoCapitalize="characters"
          value={referralCode}
          onChangeText={setReferralCode}
        />

        {error ? (
          <Text style={{ color: theme.colors.danger, marginBottom: theme.spacing(3) }}>{error}</Text>
        ) : null}

        <Button title="Create Account" onPress={handleSubmit} loading={isSubmitting} />

        <Text
          onPress={() => navigation.goBack()}
          style={{ textAlign: 'center', color: theme.colors.textMuted, marginTop: theme.spacing(5), marginBottom: theme.spacing(4) }}
        >
          Already have an account?{' '}
          <Text style={{ color: theme.colors.primary, fontWeight: '700' }}>Log in</Text>
        </Text>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  title: { fontWeight: '800' },
  roleToggle: { flexDirection: 'row', padding: 4, marginBottom: 20 },
  roleOption: { flex: 1, paddingVertical: 12, alignItems: 'center' },
});
