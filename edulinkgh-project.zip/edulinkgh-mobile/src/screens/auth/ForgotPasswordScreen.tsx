import React, { useState } from 'react';
import { KeyboardAvoidingView, Platform, ScrollView, Text, View } from 'react-native';
import type { NativeStackScreenProps } from '@react-navigation/native-stack';
import { forgotPassword, resetPassword } from '../../api/auth';
import { ApiError } from '../../api/client';
import { useAppTheme } from '../../theme/ThemeContext';
import { Button } from '../../components/Button';
import { TextField } from '../../components/TextField';
import type { AuthStackParamList } from '../../navigation/types';

type Props = NativeStackScreenProps<AuthStackParamList, 'ForgotPassword'>;

export function ForgotPasswordScreen({ navigation }: Props) {
  const { theme } = useAppTheme();
  const [step, setStep] = useState<'request' | 'reset'>('request');
  const [email, setEmail] = useState('');
  const [otp, setOtp] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleRequestCode = async () => {
    if (!email.trim()) {
      setError('Enter your email address');
      return;
    }
    setLoading(true);
    setError(null);
    setMessage(null);
    try {
      const res = await forgotPassword(email.trim());
      setMessage(res.otp ? `${res.message} (dev code: ${res.otp})` : res.message);
      setStep('reset');
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Something went wrong');
    } finally {
      setLoading(false);
    }
  };

  const handleReset = async () => {
    if (!otp.trim() || !newPassword || newPassword.length < 6) {
      setError('Enter the code you received and a new password (at least 6 characters).');
      return;
    }
    setLoading(true);
    setError(null);
    setMessage(null);
    try {
      const res = await resetPassword(email.trim(), otp.trim(), newPassword);
      setMessage(res.message);
      setTimeout(() => navigation.goBack(), 1200);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Something went wrong');
    } finally {
      setLoading(false);
    }
  };

  return (
    <KeyboardAvoidingView
      style={{ flex: 1, backgroundColor: theme.colors.background }}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
    >
      <ScrollView contentContainerStyle={{ padding: theme.spacing(6), flexGrow: 1 }}>
        <View style={{ marginTop: theme.spacing(16), marginBottom: theme.spacing(8) }}>
          <Text style={{ color: theme.colors.text, fontSize: theme.fontSize.xxl, fontWeight: '800' }}>
            Reset your password
          </Text>
          <Text style={{ color: theme.colors.textMuted, fontSize: theme.fontSize.md, marginTop: 8 }}>
            {step === 'request'
              ? "Enter the email linked to your account. We'll send you a reset code."
              : 'Enter the code you received and choose a new password.'}
          </Text>
        </View>

        <TextField
          label="Email"
          autoCapitalize="none"
          keyboardType="email-address"
          value={email}
          onChangeText={setEmail}
          editable={step === 'request'}
        />

        {step === 'reset' ? (
          <>
            <TextField
              label="Reset code"
              keyboardType="number-pad"
              value={otp}
              onChangeText={setOtp}
              maxLength={6}
            />
            <TextField
              label="New password"
              secureTextEntry
              value={newPassword}
              onChangeText={setNewPassword}
            />
          </>
        ) : null}

        {message ? <Text style={{ color: theme.colors.success, marginBottom: 12 }}>{message}</Text> : null}
        {error ? <Text style={{ color: theme.colors.danger, marginBottom: 12 }}>{error}</Text> : null}

        {step === 'request' ? (
          <Button title="Send Reset Code" onPress={handleRequestCode} loading={loading} />
        ) : (
          <Button title="Reset Password" onPress={handleReset} loading={loading} />
        )}

        <Text
          onPress={() => (step === 'reset' ? setStep('request') : navigation.goBack())}
          style={{ textAlign: 'center', color: theme.colors.primary, marginTop: theme.spacing(6), fontWeight: '600' }}
        >
          {step === 'reset' ? 'Use a different email' : 'Back to login'}
        </Text>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}
