import React, { useEffect, useRef, useState } from 'react';
import {
  ActivityIndicator,
  FlatList,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  Text,
  TextInput,
  View,
} from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import * as DocumentPicker from 'expo-document-picker';
import { getConversation, sendChatAttachment } from '../api/chat';
import { chatSocket } from '../api/chatSocket';
import { useAppTheme } from '../theme/ThemeContext';
import { useAuth } from '../context/AuthContext';
import { useChat } from '../context/ChatContext';
import { ChatMessage } from '../api/types';
import { Skeleton } from '../components/Skeleton';
import { ChatAttachment } from '../components/ChatAttachment';

interface Props {
  route: { params: { userId: number; userName: string } };
}

export function ConversationScreen({ route }: Props) {
  const { userId, userName } = route.params;
  const { theme } = useAppTheme();
  const { user } = useAuth();
  const { subscribeToMessages } = useChat();

  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [loading, setLoading] = useState(true);
  const [draft, setDraft] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [uploading, setUploading] = useState(false);
  const [showAttachMenu, setShowAttachMenu] = useState(false);
  const [otherUserTyping, setOtherUserTyping] = useState(false);
  const [readMessageIds, setReadMessageIds] = useState<Set<number>>(new Set());
  const listRef = useRef<FlatList<ChatMessage>>(null);
  const typingStopTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const wasTypingRef = useRef(false);

  useEffect(() => {
    (async () => {
      try {
        const history = await getConversation(userId);
        setMessages(history);
        // Seed read state from history so checkmarks are correct on open,
        // not just for messages read live during this screen session.
        setReadMessageIds(new Set(history.filter((m) => m.read).map((m) => m.id)));
      } catch {
        setError('Could not load message history');
      } finally {
        setLoading(false);
      }
    })();

    const unsubscribeMessages = subscribeToMessages((incoming) => {
      const belongsHere =
        (incoming.senderId === userId && incoming.recipientId === user?.userId) ||
        (incoming.senderId === user?.userId && incoming.recipientId === userId);
      if (!belongsHere) return;
      setMessages((prev) => [...prev, incoming]);
    });

    const unsubscribeTyping = chatSocket.onTyping((event) => {
      if (event.fromUserId !== userId) return;
      setOtherUserTyping(event.isTyping);
    });

    const unsubscribeReadReceipts = chatSocket.onReadReceipt((event) => {
      if (event.readByUserId !== userId) return;
      setReadMessageIds((prev) => {
        const next = new Set(prev);
        event.messageIds.forEach((id) => next.add(id));
        return next;
      });
    });

    return () => {
      unsubscribeMessages();
      unsubscribeTyping();
      unsubscribeReadReceipts();
      if (typingStopTimer.current) clearTimeout(typingStopTimer.current);
      // Let the other side know we've left, in case a "stop typing" event
      // never made it through (e.g. we navigated away mid-keystroke).
      if (wasTypingRef.current) {
        chatSocket.sendTyping(userId, false);
      }
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [userId]);

  const handleDraftChange = (text: string) => {
    setDraft(text);

    const isNowTyping = text.length > 0;
    if (isNowTyping !== wasTypingRef.current) {
      chatSocket.sendTyping(userId, isNowTyping);
      wasTypingRef.current = isNowTyping;
    }

    // Debounce an automatic "stopped typing" in case the user just leaves
    // text sitting in the box without sending or clearing it.
    if (typingStopTimer.current) clearTimeout(typingStopTimer.current);
    if (isNowTyping) {
      typingStopTimer.current = setTimeout(() => {
        chatSocket.sendTyping(userId, false);
        wasTypingRef.current = false;
      }, 3000);
    }
  };

  const handleSend = () => {
    const content = draft.trim();
    if (!content) return;
    try {
      chatSocket.send(userId, content);
      setDraft('');
      setError(null);
      if (wasTypingRef.current) {
        chatSocket.sendTyping(userId, false);
        wasTypingRef.current = false;
      }
      if (typingStopTimer.current) clearTimeout(typingStopTimer.current);
    } catch {
      setError('Not connected — check your connection and try again.');
    }
  };

  const uploadAndSend = async (uri: string, name: string, mimeType: string) => {
    setUploading(true);
    setError(null);
    try {
      await sendChatAttachment(userId, uri, name, mimeType);
      // The sent message arrives back over the WebSocket (server broadcasts
      // to both participants), so no need to optimistically insert it here.
    } catch {
      setError('Could not send the attachment. Please try again.');
    } finally {
      setUploading(false);
    }
  };

  const pickImage = async () => {
    setShowAttachMenu(false);
    const permission = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (!permission.granted) {
      setError('Photo library permission was not granted.');
      return;
    }
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      quality: 0.7,
    });
    if (result.canceled || !result.assets?.[0]) return;
    const asset = result.assets[0];
    await uploadAndSend(asset.uri, asset.fileName || 'photo.jpg', asset.mimeType || 'image/jpeg');
  };

  const pickDocument = async () => {
    setShowAttachMenu(false);
    const result = await DocumentPicker.getDocumentAsync({ type: '*/*', copyToCacheDirectory: true });
    if (result.canceled || !result.assets?.[0]) return;
    const asset = result.assets[0];
    await uploadAndSend(asset.uri, asset.name, asset.mimeType || 'application/octet-stream');
  };

  return (
    <KeyboardAvoidingView
      style={{ flex: 1, backgroundColor: theme.colors.background }}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      keyboardVerticalOffset={90}
    >
      <View style={{ paddingHorizontal: theme.spacing(5), paddingTop: theme.spacing(3), paddingBottom: theme.spacing(2) }}>
        <Text style={{ color: theme.colors.text, fontSize: theme.fontSize.lg, fontWeight: '800' }}>{userName}</Text>
      </View>

      {loading ? (
        <View style={{ padding: theme.spacing(5) }}>
          <Skeleton height={40} width="60%" style={{ marginBottom: 10, alignSelf: 'flex-start' }} />
          <Skeleton height={40} width="50%" style={{ marginBottom: 10, alignSelf: 'flex-end' }} />
        </View>
      ) : (
        <FlatList
          ref={listRef}
          data={messages}
          keyExtractor={(item) => String(item.id)}
          contentContainerStyle={{ padding: theme.spacing(5) }}
          onContentSizeChange={() => listRef.current?.scrollToEnd({ animated: true })}
          renderItem={({ item }) => {
            const isMine = item.senderId === user?.userId;
            const isRead = readMessageIds.has(item.id);
            return (
              <View
                style={{
                  alignSelf: isMine ? 'flex-end' : 'flex-start',
                  backgroundColor: isMine ? theme.colors.primary : theme.colors.inputBackground,
                  borderRadius: theme.radius.lg,
                  paddingVertical: theme.spacing(2.5),
                  paddingHorizontal: theme.spacing(4),
                  marginBottom: theme.spacing(2),
                  maxWidth: '80%',
                }}
              >
                {item.attachmentUrl ? (
                  <ChatAttachment
                    url={item.attachmentUrl}
                    fileName={item.attachmentFileName}
                    mimeType={item.attachmentMimeType}
                    isMine={isMine}
                  />
                ) : null}
                {item.content ? (
                  <Text style={{ color: isMine ? theme.colors.textInverse : theme.colors.text }}>{item.content}</Text>
                ) : null}
                {isMine ? (
                  <Text style={{ color: theme.colors.textInverse, opacity: 0.7, fontSize: 11, marginTop: 4, textAlign: 'right' }}>
                    {isRead ? '✓✓ Read' : '✓ Sent'}
                  </Text>
                ) : null}
              </View>
            );
          }}
        />
      )}

      {otherUserTyping ? (
        <View style={{ paddingHorizontal: theme.spacing(5), paddingBottom: theme.spacing(1) }}>
          <Text style={{ color: theme.colors.textMuted, fontStyle: 'italic', fontSize: 13 }}>
            {userName} is typing...
          </Text>
        </View>
      ) : null}

      {error ? (
        <Text style={{ color: theme.colors.danger, textAlign: 'center', marginBottom: 4 }}>{error}</Text>
      ) : null}

      {showAttachMenu ? (
        <View
          style={{
            flexDirection: 'row',
            justifyContent: 'center',
            gap: 12,
            paddingBottom: theme.spacing(3),
          }}
        >
          <Pressable
            onPress={pickImage}
            style={{ backgroundColor: theme.colors.inputBackground, borderRadius: theme.radius.md, paddingVertical: 10, paddingHorizontal: 16 }}
          >
            <Text style={{ color: theme.colors.text, fontWeight: '600' }}>🖼️ Photo</Text>
          </Pressable>
          <Pressable
            onPress={pickDocument}
            style={{ backgroundColor: theme.colors.inputBackground, borderRadius: theme.radius.md, paddingVertical: 10, paddingHorizontal: 16 }}
          >
            <Text style={{ color: theme.colors.text, fontWeight: '600' }}>📄 Document</Text>
          </Pressable>
        </View>
      ) : null}

      <View
        style={{
          flexDirection: 'row',
          alignItems: 'center',
          padding: theme.spacing(3),
          borderTopWidth: 1,
          borderTopColor: theme.colors.border,
          gap: 8,
        }}
      >
        <Pressable
          onPress={() => setShowAttachMenu((v) => !v)}
          disabled={uploading}
          style={{
            width: 44,
            height: 44,
            borderRadius: 22,
            backgroundColor: theme.colors.inputBackground,
            alignItems: 'center',
            justifyContent: 'center',
          }}
        >
          {uploading ? <ActivityIndicator size="small" color={theme.colors.primary} /> : <Text style={{ fontSize: 20 }}>+</Text>}
        </Pressable>
        <TextInput
          value={draft}
          onChangeText={handleDraftChange}
          placeholder="Type a message..."
          placeholderTextColor={theme.colors.textMuted}
          style={{
            flex: 1,
            backgroundColor: theme.colors.inputBackground,
            color: theme.colors.text,
            borderRadius: theme.radius.pill,
            paddingHorizontal: theme.spacing(4),
            paddingVertical: theme.spacing(3),
          }}
          multiline
        />
        <Pressable
          onPress={handleSend}
          style={{
            backgroundColor: theme.colors.primary,
            borderRadius: theme.radius.pill,
            paddingHorizontal: theme.spacing(4),
            paddingVertical: theme.spacing(3),
          }}
        >
          <Text style={{ color: theme.colors.textInverse, fontWeight: '700' }}>Send</Text>
        </Pressable>
      </View>
    </KeyboardAvoidingView>
  );
}
