import React, { useEffect, useState } from 'react';
import { Text, View } from 'react-native';
import { getVideoCallJoinInfo } from '../api/videoCalls';
import { ApiError } from '../api/client';
import { VideoCallJoinInfo } from '../api/types';
import { useAppTheme } from '../theme/ThemeContext';
import { GlassCard } from '../components/GlassCard';
import { Button } from '../components/Button';
import { Skeleton } from '../components/Skeleton';

interface Props {
  route: { params: { sessionId: number } };
  navigation: { goBack: () => void };
}

/**
 * Real join flow (fetches a real room + token from the backend, which
 * enforces the same session-access rules as everything else) — but the
 * actual video surface is a labeled placeholder until the real 100ms SDK
 * (@100mslive/react-native-hms) is installed and configured with real
 * credentials. See VIDEO_INTEGRATION.md for exactly what's needed.
 */
export function VideoCallScreen({ route, navigation }: Props) {
  const { sessionId } = route.params;
  const { theme } = useAppTheme();
  const [joinInfo, setJoinInfo] = useState<VideoCallJoinInfo | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    (async () => {
      try {
        const info = await getVideoCallJoinInfo(sessionId);
        setJoinInfo(info);
      } catch (err) {
        setError(err instanceof ApiError ? err.message : 'Could not join the call');
      } finally {
        setLoading(false);
      }
    })();
  }, [sessionId]);

  if (loading) {
    return (
      <View style={{ flex: 1, backgroundColor: theme.colors.background, padding: theme.spacing(6), justifyContent: 'center' }}>
        <Skeleton height={300} />
      </View>
    );
  }

  if (error || !joinInfo) {
    return (
      <View style={{ flex: 1, backgroundColor: theme.colors.background, padding: theme.spacing(6), justifyContent: 'center' }}>
        <Text style={{ color: theme.colors.danger, textAlign: 'center', marginBottom: theme.spacing(4) }}>
          {error || 'Could not join the call'}
        </Text>
        <Button title="Go Back" variant="outline" onPress={() => navigation.goBack()} />
      </View>
    );
  }

  return (
    <View style={{ flex: 1, backgroundColor: '#000' }}>
      <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center', padding: theme.spacing(6) }}>
        <GlassCard style={{ alignItems: 'center', maxWidth: 320 }}>
          <Text style={{ fontSize: 36, marginBottom: 12 }}>🎥</Text>
          <Text style={{ color: theme.colors.text, fontWeight: '700', fontSize: theme.fontSize.lg, marginBottom: 6, textAlign: 'center' }}>
            Video call ready to connect
          </Text>
          <Text style={{ color: theme.colors.textMuted, textAlign: 'center', marginBottom: 12 }}>
            Room joined as {joinInfo.role === 'HOST' ? 'host' : 'participant'}. Live video rendering needs the
            100ms SDK wired in with real credentials — see VIDEO_INTEGRATION.md.
          </Text>
          <Text style={{ color: theme.colors.textMuted, fontSize: 11 }}>Room: {joinInfo.roomCode}</Text>
        </GlassCard>
      </View>

      <View style={{ padding: theme.spacing(6) }}>
        <Button title="Leave Call" variant="danger" onPress={() => navigation.goBack()} />
      </View>
    </View>
  );
}
