import React, { useEffect, useState } from 'react';
import { KeyboardAvoidingView, Platform, Pressable, ScrollView, Text, View } from 'react-native';
import type { NativeStackScreenProps } from '@react-navigation/native-stack';
import DateTimePicker from '@react-native-community/datetimepicker';
import { createSession } from '../../api/sessions';
import { getTeacherAvailability } from '../../api/availability';
import { ApiError } from '../../api/client';
import { useAppTheme } from '../../theme/ThemeContext';
import { useAuth } from '../../context/AuthContext';
import { TextField } from '../../components/TextField';
import { Button } from '../../components/Button';
import { GlassCard } from '../../components/GlassCard';
import type { TeacherStackParamList } from '../../navigation/types';
import { AvailabilityWindow } from '../../api/types';

type Props = NativeStackScreenProps<TeacherStackParamList, 'CreateSession'>;

const JS_DAY_TO_BACKEND: AvailabilityWindow['dayOfWeek'][] = [
  'SUNDAY', 'MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY', 'SATURDAY',
];

function timeToMinutes(time: string): number {
  const [h, m] = time.split(':').map(Number);
  return h * 60 + m;
}

export function CreateSessionScreen({ navigation }: Props) {
  const { theme } = useAppTheme();
  const { user } = useAuth();
  const [subject, setSubject] = useState('');
  const [description, setDescription] = useState('');
  const [scheduledAt, setScheduledAt] = useState<Date | null>(null);
  const [pickerMode, setPickerMode] = useState<'date' | 'time' | null>(null);
  const [duration, setDuration] = useState('60');
  const [fee, setFee] = useState('');
  const [meetingLink, setMeetingLink] = useState('');
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [availability, setAvailability] = useState<AvailabilityWindow[]>([]);

  useEffect(() => {
    if (!user) return;
    getTeacherAvailability(user.userId).then(setAvailability).catch(() => {
      // non-critical — the client-side hint just won't show if this fails
    });
  }, [user]);

  // Mirrors the backend's validation so the teacher gets feedback before
  // submitting, rather than only finding out after a failed request. The
  // backend remains the source of truth and re-checks this on submit.
  const availabilityWarning = (() => {
    if (!scheduledAt || availability.length === 0) return null;
    const day = JS_DAY_TO_BACKEND[scheduledAt.getDay()];
    const startMinutes = scheduledAt.getHours() * 60 + scheduledAt.getMinutes();
    const endMinutes = startMinutes + (Number(duration) || 60);

    const fits = availability
      .filter((w) => w.dayOfWeek === day)
      .some((w) => startMinutes >= timeToMinutes(w.startTime) && endMinutes <= timeToMinutes(w.endTime));

    return fits ? null : `This falls outside your stated availability for ${day.charAt(0)}${day.slice(1).toLowerCase()}.`;
  })();

  const handleSubmit = async () => {
    const errs: Record<string, string> = {};
    if (!subject.trim()) errs.subject = 'Required';
    if (!scheduledAt) errs.dateTime = 'Pick a date and time';
    else if (scheduledAt.getTime() < Date.now()) errs.dateTime = 'Must be in the future';
    if (!fee.trim() || isNaN(Number(fee))) errs.fee = 'Enter a valid amount';
    setErrors(errs);
    if (Object.keys(errs).length > 0 || !scheduledAt) return;

    setSubmitting(true);
    setError(null);
    try {
      await createSession({
        subject: subject.trim(),
        description: description.trim() || undefined,
        scheduledAt: scheduledAt.toISOString(),
        durationMinutes: Number(duration) || 60,
        feeGhc: Number(fee),
        meetingLink: meetingLink.trim() || undefined,
      });
      navigation.goBack();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Could not create session');
    } finally {
      setSubmitting(false);
    }
  };

  const onPickerChange = (event: { type: string }, selected?: Date) => {
    if (Platform.OS === 'android') setPickerMode(null);
    if (event.type === 'dismissed' || !selected) return;

    if (pickerMode === 'date') {
      setScheduledAt((prev) => {
        const base = prev ?? new Date();
        const next = new Date(selected);
        next.setHours(base.getHours(), base.getMinutes());
        return next;
      });
      if (Platform.OS === 'android') setTimeout(() => setPickerMode('time'), 250);
    } else if (pickerMode === 'time') {
      setScheduledAt((prev) => {
        const base = prev ?? new Date();
        const next = new Date(base);
        next.setHours(selected.getHours(), selected.getMinutes());
        return next;
      });
    }
  };

  return (
    <KeyboardAvoidingView style={{ flex: 1, backgroundColor: theme.colors.background }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <ScrollView contentContainerStyle={{ padding: theme.spacing(6) }}>
        <Text style={{ color: theme.colors.text, fontSize: theme.fontSize.xxl, fontWeight: '800', marginTop: theme.spacing(10), marginBottom: theme.spacing(6) }}>
          New Session
        </Text>

        <TextField label="Subject" value={subject} onChangeText={setSubject} error={errors.subject} />
        <TextField label="Description (optional)" value={description} onChangeText={setDescription} multiline />

        <Text style={{ color: theme.colors.textMuted, fontSize: 13, fontWeight: '600', marginBottom: 8 }}>
          Date & time
        </Text>
        <Pressable onPress={() => setPickerMode('date')} style={{ marginBottom: theme.spacing(4) }}>
          <GlassCard>
            <Text style={{ color: scheduledAt ? theme.colors.text : theme.colors.textMuted, fontWeight: '600' }}>
              {scheduledAt
                ? scheduledAt.toLocaleString(undefined, { dateStyle: 'medium', timeStyle: 'short' })
                : 'Tap to choose a date and time'}
            </Text>
          </GlassCard>
        </Pressable>
        {errors.dateTime ? (
          <Text style={{ color: theme.colors.danger, marginTop: -10, marginBottom: 12 }}>{errors.dateTime}</Text>
        ) : null}
        {availabilityWarning ? (
          <Text style={{ color: theme.colors.warning, marginTop: -10, marginBottom: 12 }}>
            ⚠ {availabilityWarning}
          </Text>
        ) : null}

        {pickerMode ? (
          <DateTimePicker
            value={scheduledAt ?? new Date()}
            mode={pickerMode}
            is24Hour={false}
            onChange={onPickerChange}
            minimumDate={pickerMode === 'date' ? new Date() : undefined}
          />
        ) : null}
        {Platform.OS === 'ios' && pickerMode ? (
          <View style={{ marginBottom: theme.spacing(4) }}>
            <Button
              title={pickerMode === 'date' ? 'Next: choose time' : 'Done'}
              onPress={() => setPickerMode(pickerMode === 'date' ? 'time' : null)}
            />
          </View>
        ) : null}

        <TextField label="Duration (minutes)" keyboardType="number-pad" value={duration} onChangeText={setDuration} />
        <TextField label="Fee (GHC)" keyboardType="decimal-pad" value={fee} onChangeText={setFee} error={errors.fee} />
        <TextField label="Meeting link (optional)" value={meetingLink} onChangeText={setMeetingLink} autoCapitalize="none" />

        {error ? <Text style={{ color: theme.colors.danger, marginBottom: 12 }}>{error}</Text> : null}

        <Button title="Create Session" onPress={handleSubmit} loading={submitting} />
      </ScrollView>
    </KeyboardAvoidingView>
  );
}
