import React, { useCallback, useState } from 'react';
import { Pressable, RefreshControl, ScrollView, Text, View } from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { getTeacherTrends } from '../../api/teacherStats';
import { ApiError } from '../../api/client';
import { TeacherTrends } from '../../api/types';
import { useAppTheme } from '../../theme/ThemeContext';
import { GlassCard } from '../../components/GlassCard';
import { AnalyticsLineChart } from '../../components/AnalyticsLineChart';
import { Skeleton } from '../../components/Skeleton';

const WINDOWS = [7, 30, 90];

export function TeacherTrendsScreen() {
  const { theme } = useAppTheme();
  const [days, setDays] = useState(30);
  const [trends, setTrends] = useState<TeacherTrends | null>(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    try {
      const result = await getTeacherTrends(days);
      setTrends(result);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Could not load trends');
    }
  }, [days]);

  useFocusEffect(
    useCallback(() => {
      setLoading(true);
      load().finally(() => setLoading(false));
      // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [days])
  );

  const onRefresh = async () => {
    setRefreshing(true);
    await load();
    setRefreshing(false);
  };

  const totalEarnings = trends?.earningsSeries.reduce((sum, p) => sum + p.value, 0) ?? 0;
  const totalSessions = trends?.sessionsSeries.reduce((sum, p) => sum + p.value, 0) ?? 0;

  return (
    <ScrollView
      style={{ flex: 1, backgroundColor: theme.colors.background }}
      contentContainerStyle={{ padding: theme.spacing(6) }}
      refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={theme.colors.primary} />}
    >
      <Text style={{ color: theme.colors.text, fontSize: theme.fontSize.xxl, fontWeight: '800', marginTop: theme.spacing(10), marginBottom: theme.spacing(4) }}>
        Performance Trends
      </Text>

      <View style={{ flexDirection: 'row', gap: 8, marginBottom: theme.spacing(5) }}>
        {WINDOWS.map((w) => (
          <Pressable
            key={w}
            onPress={() => setDays(w)}
            style={{
              paddingVertical: 8,
              paddingHorizontal: 16,
              borderRadius: theme.radius.pill,
              backgroundColor: days === w ? theme.colors.primary : theme.colors.inputBackground,
            }}
          >
            <Text style={{ color: days === w ? theme.colors.textInverse : theme.colors.text, fontWeight: '600' }}>
              {w}d
            </Text>
          </Pressable>
        ))}
      </View>

      {error ? <Text style={{ color: theme.colors.danger, marginBottom: 12 }}>{error}</Text> : null}

      {loading ? (
        <View>
          <Skeleton height={220} style={{ marginBottom: 16 }} />
          <Skeleton height={220} />
        </View>
      ) : (
        <>
          <GlassCard style={{ marginBottom: theme.spacing(5) }}>
            <Text style={{ color: theme.colors.textMuted, fontSize: 13, fontWeight: '700', marginBottom: 4 }}>
              EARNINGS ({days}d)
            </Text>
            <Text style={{ color: theme.colors.text, fontSize: theme.fontSize.xxl, fontWeight: '800', marginBottom: theme.spacing(3) }}>
              GHC {totalEarnings.toFixed(2)}
            </Text>
            {trends ? <AnalyticsLineChart data={trends.earningsSeries} color={theme.colors.success} /> : null}
          </GlassCard>

          <GlassCard>
            <Text style={{ color: theme.colors.textMuted, fontSize: 13, fontWeight: '700', marginBottom: 4 }}>
              SESSIONS TAUGHT ({days}d)
            </Text>
            <Text style={{ color: theme.colors.text, fontSize: theme.fontSize.xxl, fontWeight: '800', marginBottom: theme.spacing(3) }}>
              {totalSessions}
            </Text>
            {trends ? <AnalyticsLineChart data={trends.sessionsSeries} color={theme.colors.primary} /> : null}
          </GlassCard>
        </>
      )}
    </ScrollView>
  );
}
