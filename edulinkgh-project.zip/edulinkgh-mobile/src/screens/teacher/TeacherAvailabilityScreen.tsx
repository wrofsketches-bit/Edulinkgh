import React, { useCallback, useState } from 'react';
import { Platform, Pressable, ScrollView, Text, View } from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import DateTimePicker from '@react-native-community/datetimepicker';
import { addAvailabilityWindow, getTeacherAvailability, removeAvailabilityWindow } from '../../api/availability';
import { ApiError } from '../../api/client';
import { AvailabilityWindow, DayOfWeek } from '../../api/types';
import { useAppTheme } from '../../theme/ThemeContext';
import { useAuth } from '../../context/AuthContext';
import { GlassCard } from '../../components/GlassCard';
import { Button } from '../../components/Button';
import { Skeleton } from '../../components/Skeleton';
import { WeeklyAvailabilityGrid } from '../../components/WeeklyAvailabilityGrid';

const DAYS: { label: string; value: DayOfWeek }[] = [
  { label: 'Mon', value: 'MONDAY' },
  { label: 'Tue', value: 'TUESDAY' },
  { label: 'Wed', value: 'WEDNESDAY' },
  { label: 'Thu', value: 'THURSDAY' },
  { label: 'Fri', value: 'FRIDAY' },
  { label: 'Sat', value: 'SATURDAY' },
  { label: 'Sun', value: 'SUNDAY' },
];

function toTimeString(date: Date): string {
  return `${String(date.getHours()).padStart(2, '0')}:${String(date.getMinutes()).padStart(2, '0')}:00`;
}

export function TeacherAvailabilityScreen() {
  const { theme } = useAppTheme();
  const { user } = useAuth();
  const [windows, setWindows] = useState<AvailabilityWindow[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const [selectedDay, setSelectedDay] = useState<DayOfWeek>('MONDAY');
  const [startTime, setStartTime] = useState(new Date(2000, 0, 1, 9, 0));
  const [endTime, setEndTime] = useState(new Date(2000, 0, 1, 12, 0));
  const [activePicker, setActivePicker] = useState<'start' | 'end' | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const load = useCallback(async () => {
    if (!user) return;
    try {
      const result = await getTeacherAvailability(user.userId);
      setWindows(result);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Could not load availability');
    }
  }, [user]);

  useFocusEffect(
    useCallback(() => {
      load().finally(() => setLoading(false));
      // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [])
  );

  const handleAdd = async () => {
    setSubmitting(true);
    setError(null);
    try {
      await addAvailabilityWindow(selectedDay, toTimeString(startTime), toTimeString(endTime));
      await load();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Could not add availability window');
    } finally {
      setSubmitting(false);
    }
  };

  const handleRemove = async (id: number) => {
    setError(null);
    try {
      await removeAvailabilityWindow(id);
      await load();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Could not remove window');
    }
  };

  return (
    <ScrollView style={{ flex: 1, backgroundColor: theme.colors.background }} contentContainerStyle={{ padding: theme.spacing(6) }}>
      <Text style={{ color: theme.colors.text, fontSize: theme.fontSize.xxl, fontWeight: '800', marginTop: theme.spacing(10), marginBottom: theme.spacing(5) }}>
        My Availability
      </Text>

      {error ? <Text style={{ color: theme.colors.danger, marginBottom: 12 }}>{error}</Text> : null}

      <GlassCard style={{ marginBottom: theme.spacing(6) }}>
        <Text style={{ color: theme.colors.textMuted, fontSize: 13, fontWeight: '700', marginBottom: theme.spacing(3) }}>
          ADD A WEEKLY WINDOW
        </Text>

        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 6, marginBottom: theme.spacing(4) }}>
          {DAYS.map((d) => (
            <Pressable
              key={d.value}
              onPress={() => setSelectedDay(d.value)}
              style={{
                paddingVertical: 8,
                paddingHorizontal: 14,
                borderRadius: theme.radius.pill,
                backgroundColor: selectedDay === d.value ? theme.colors.primary : theme.colors.inputBackground,
              }}
            >
              <Text style={{ color: selectedDay === d.value ? theme.colors.textInverse : theme.colors.text, fontWeight: '600' }}>
                {d.label}
              </Text>
            </Pressable>
          ))}
        </View>

        <View style={{ flexDirection: 'row', gap: 10, marginBottom: theme.spacing(4) }}>
          <Pressable onPress={() => setActivePicker('start')} style={{ flex: 1 }}>
            <View style={{ backgroundColor: theme.colors.inputBackground, borderRadius: theme.radius.md, padding: theme.spacing(3) }}>
              <Text style={{ color: theme.colors.textMuted, fontSize: 12 }}>Start</Text>
              <Text style={{ color: theme.colors.text, fontWeight: '700' }}>
                {startTime.toLocaleTimeString(undefined, { hour: 'numeric', minute: '2-digit' })}
              </Text>
            </View>
          </Pressable>
          <Pressable onPress={() => setActivePicker('end')} style={{ flex: 1 }}>
            <View style={{ backgroundColor: theme.colors.inputBackground, borderRadius: theme.radius.md, padding: theme.spacing(3) }}>
              <Text style={{ color: theme.colors.textMuted, fontSize: 12 }}>End</Text>
              <Text style={{ color: theme.colors.text, fontWeight: '700' }}>
                {endTime.toLocaleTimeString(undefined, { hour: 'numeric', minute: '2-digit' })}
              </Text>
            </View>
          </Pressable>
        </View>

        {activePicker ? (
          <DateTimePicker
            value={activePicker === 'start' ? startTime : endTime}
            mode="time"
            is24Hour={false}
            onChange={(event, selected) => {
              if (Platform.OS === 'android') setActivePicker(null);
              if (event.type === 'dismissed' || !selected) return;
              if (activePicker === 'start') setStartTime(selected);
              else setEndTime(selected);
            }}
          />
        ) : null}
        {Platform.OS === 'ios' && activePicker ? (
          <View style={{ marginBottom: theme.spacing(3) }}>
            <Button title="Done" variant="outline" onPress={() => setActivePicker(null)} />
          </View>
        ) : null}

        <Button title="Add Window" onPress={handleAdd} loading={submitting} />
      </GlassCard>

      <Text style={{ color: theme.colors.text, fontSize: theme.fontSize.lg, fontWeight: '700', marginBottom: theme.spacing(3) }}>
        Current Schedule
      </Text>

      {loading ? <Skeleton height={80} /> : <WeeklyAvailabilityGrid windows={windows} onRemove={handleRemove} />}
    </ScrollView>
  );
}
