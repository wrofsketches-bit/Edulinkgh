import React, { useCallback, useEffect, useState } from 'react';
import { FlatList, RefreshControl, Text, View } from 'react-native';
import type { CompositeScreenProps } from '@react-navigation/native';
import type { NativeStackScreenProps } from '@react-navigation/native-stack';
import type { BottomTabScreenProps } from '@react-navigation/bottom-tabs';
import { getMyTeacherSessions } from '../../api/sessions';
import { getTeacherStats } from '../../api/teacherStats';
import { ApiError } from '../../api/client';
import { SessionItem, TeacherStats } from '../../api/types';
import { useAppTheme } from '../../theme/ThemeContext';
import { useAuth } from '../../context/AuthContext';
import { GlassCard } from '../../components/GlassCard';
import { Badge } from '../../components/Badge';
import { Button } from '../../components/Button';
import { Skeleton } from '../../components/Skeleton';
import type { TeacherStackParamList, TeacherTabParamList } from '../../navigation/types';

type Props = CompositeScreenProps<
  BottomTabScreenProps<TeacherTabParamList, 'Dashboard'>,
  NativeStackScreenProps<TeacherStackParamList>
>;

function StatChip({ label, value }: { label: string; value: string }) {
  const { theme } = useAppTheme();
  return (
    <GlassCard style={{ flexBasis: '48%', marginBottom: theme.spacing(2.5) }}>
      <Text style={{ color: theme.colors.textMuted, fontSize: 11, fontWeight: '700' }}>{label.toUpperCase()}</Text>
      <Text style={{ color: theme.colors.text, fontSize: theme.fontSize.lg, fontWeight: '800', marginTop: 2 }}>{value}</Text>
    </GlassCard>
  );
}

export function TeacherDashboardScreen({ navigation }: Props) {
  const { theme } = useAppTheme();
  const { user } = useAuth();
  const [sessions, setSessions] = useState<SessionItem[]>([]);
  const [stats, setStats] = useState<TeacherStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    try {
      const [sessionResult, statsResult] = await Promise.all([getMyTeacherSessions(), getTeacherStats()]);
      setSessions(sessionResult.filter((s) => s.status === 'UPCOMING' || s.status === 'LIVE'));
      setStats(statsResult);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Could not load your sessions');
    }
  }, []);

  useEffect(() => {
    setLoading(true);
    load().finally(() => setLoading(false));
  }, [load]);

  const onRefresh = async () => {
    setRefreshing(true);
    await load();
    setRefreshing(false);
  };

  return (
    <View style={{ flex: 1, backgroundColor: theme.colors.background, padding: theme.spacing(6) }}>
      <Text style={{ color: theme.colors.textMuted, marginTop: theme.spacing(10) }}>Welcome back,</Text>
      <Text style={{ color: theme.colors.text, fontSize: theme.fontSize.xxl, fontWeight: '800', marginBottom: theme.spacing(5) }}>
        {user?.fullName}
      </Text>

      <View style={{ marginBottom: theme.spacing(5), gap: theme.spacing(2) }}>
        <Button title="+ Create New Session" onPress={() => navigation.navigate('CreateSession')} />
        <Button title="Manage Availability" variant="outline" onPress={() => navigation.navigate('Availability')} />
        <Button title="Performance Trends" variant="outline" onPress={() => navigation.navigate('Trends')} />
      </View>

      {error ? <Text style={{ color: theme.colors.danger, marginBottom: 12 }}>{error}</Text> : null}

      {loading ? (
        <Skeleton height={90} />
      ) : (
        <FlatList
          data={sessions}
          keyExtractor={(item) => String(item.id)}
          refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={theme.colors.primary} />}
          ListHeaderComponent={
            stats ? (
              <View style={{ marginBottom: theme.spacing(3) }}>
                <Text style={{ color: theme.colors.text, fontSize: theme.fontSize.lg, fontWeight: '700', marginBottom: theme.spacing(3) }}>
                  Your Success Stats
                </Text>
                <View style={{ flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between' }}>
                  <StatChip label="Sessions Taught" value={String(stats.totalSessionsCompleted)} />
                  <StatChip label="Students Taught" value={String(stats.totalStudentsTaught)} />
                  <StatChip label="Completion Rate" value={`${stats.completionRate}%`} />
                  <StatChip
                    label="Rating"
                    value={stats.averageRating !== null ? `★ ${stats.averageRating} (${stats.ratingCount})` : 'No ratings yet'}
                  />
                </View>
                <Text style={{ color: theme.colors.text, fontSize: theme.fontSize.lg, fontWeight: '700', marginTop: theme.spacing(2), marginBottom: theme.spacing(3) }}>
                  Upcoming & Live
                </Text>
              </View>
            ) : null
          }
          ListEmptyComponent={
            <Text style={{ color: theme.colors.textMuted, textAlign: 'center', marginTop: 40 }}>
              Nothing scheduled yet. Create your first session above.
            </Text>
          }
          renderItem={({ item }) => (
            <GlassCard
              style={{ marginBottom: theme.spacing(3) }}
              onTouchEnd={() => navigation.navigate('SessionDetail', { sessionId: item.id })}
            >
              <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
                <View style={{ flex: 1 }}>
                  <Text style={{ color: theme.colors.text, fontWeight: '700' }}>{item.subject}</Text>
                  <Text style={{ color: theme.colors.textMuted, marginTop: 4 }}>
                    {new Date(item.scheduledAt).toLocaleString()} · {item.enrolledStudents.length} enrolled
                  </Text>
                </View>
                <Badge label={item.status} tone={item.status === 'LIVE' ? 'success' : 'primary'} />
              </View>
            </GlassCard>
          )}
        />
      )}
    </View>
  );
}
