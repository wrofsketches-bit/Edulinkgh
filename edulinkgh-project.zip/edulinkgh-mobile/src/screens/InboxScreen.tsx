import React, { useCallback, useState } from 'react';
import { FlatList, RefreshControl, Text, View } from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { useAppTheme } from '../theme/ThemeContext';
import { useChat } from '../context/ChatContext';
import { GlassCard } from '../components/GlassCard';
import { Badge } from '../components/Badge';

interface Props {
  navigation: { navigate: (screen: 'Conversation', params: { userId: number; userName: string }) => void };
}

export function InboxScreen({ navigation }: Props) {
  const { theme } = useAppTheme();
  const { inbox, refreshInbox } = useChat();
  const [refreshing, setRefreshing] = useState(false);

  useFocusEffect(
    useCallback(() => {
      refreshInbox();
      // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [])
  );

  const onRefresh = async () => {
    setRefreshing(true);
    await refreshInbox();
    setRefreshing(false);
  };

  return (
    <View style={{ flex: 1, backgroundColor: theme.colors.background, padding: theme.spacing(6) }}>
      <Text style={{ color: theme.colors.text, fontSize: theme.fontSize.xxl, fontWeight: '800', marginTop: theme.spacing(10), marginBottom: theme.spacing(5) }}>
        Messages
      </Text>

      <FlatList
        data={inbox}
        keyExtractor={(item) => String(item.otherUserId)}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={theme.colors.primary} />}
        ListEmptyComponent={
          <Text style={{ color: theme.colors.textMuted, textAlign: 'center', marginTop: 40 }}>
            No conversations yet. Start one from a teacher&apos;s profile or session page.
          </Text>
        }
        renderItem={({ item }) => (
          <GlassCard
            style={{ marginBottom: theme.spacing(3) }}
            onTouchEnd={() => navigation.navigate('Conversation', { userId: item.otherUserId, userName: item.otherUserName })}
          >
            <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
              <View style={{ flex: 1 }}>
                <Text style={{ color: theme.colors.text, fontWeight: '700' }}>{item.otherUserName}</Text>
                <Text numberOfLines={1} style={{ color: theme.colors.textMuted, marginTop: 4 }}>
                  {item.lastMessage}
                </Text>
              </View>
              {item.unreadCount > 0 ? <Badge label={String(item.unreadCount)} tone="primary" /> : null}
            </View>
          </GlassCard>
        )}
      />
    </View>
  );
}
