import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { FlatList, Pressable, RefreshControl, Text, View } from 'react-native';
import { Calendar, DateData } from 'react-native-calendars';
import { getMyStudentSessions, getMyTeacherSessions } from '../api/sessions';
import { ApiError } from '../api/client';
import { SessionItem } from '../api/types';
import { useAppTheme } from '../theme/ThemeContext';
import { useAuth } from '../context/AuthContext';
import { GlassCard } from '../components/GlassCard';
import { Badge } from '../components/Badge';
import { Skeleton } from '../components/Skeleton';

interface Props {
  navigation: { navigate: (screen: 'SessionDetail', params: { sessionId: number }) => void };
}

const statusTone: Record<SessionItem['status'], 'primary' | 'success' | 'neutral' | 'danger'> = {
  UPCOMING: 'primary',
  LIVE: 'success',
  COMPLETED: 'neutral',
  CANCELLED: 'danger',
};

function toDateString(iso: string): string {
  return iso.slice(0, 10);
}

export function MySessionsScreen({ navigation }: Props) {
  const { theme } = useAppTheme();
  const { user } = useAuth();
  const [sessions, setSessions] = useState<SessionItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [view, setView] = useState<'list' | 'calendar'>('list');
  const [selectedDate, setSelectedDate] = useState(() => new Date().toISOString().slice(0, 10));

  const load = useCallback(async () => {
    try {
      const result = user?.role === 'TEACHER' ? await getMyTeacherSessions() : await getMyStudentSessions();
      setSessions(result);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Could not load sessions');
    }
  }, [user?.role]);

  useEffect(() => {
    setLoading(true);
    load().finally(() => setLoading(false));
  }, [load]);

  const onRefresh = async () => {
    setRefreshing(true);
    await load();
    setRefreshing(false);
  };

  const markedDates = useMemo(() => {
    const marks: Record<string, { marked: boolean; dotColor: string; selected?: boolean; selectedColor?: string }> = {};
    sessions.forEach((s) => {
      const dateKey = toDateString(s.scheduledAt);
      marks[dateKey] = { marked: true, dotColor: s.status === 'LIVE' ? theme.colors.success : theme.colors.primary };
    });
    marks[selectedDate] = { ...(marks[selectedDate] || { marked: false, dotColor: theme.colors.primary }), selected: true, selectedColor: theme.colors.primary };
    return marks;
  }, [sessions, selectedDate, theme]);

  const calendarTheme = {
    backgroundColor: theme.colors.background,
    calendarBackground: theme.colors.background,
    textSectionTitleColor: theme.colors.textMuted,
    selectedDayBackgroundColor: theme.colors.primary,
    selectedDayTextColor: theme.colors.textInverse,
    todayTextColor: theme.colors.primary,
    dayTextColor: theme.colors.text,
    textDisabledColor: theme.colors.border,
    monthTextColor: theme.colors.text,
    arrowColor: theme.colors.primary,
    dotColor: theme.colors.primary,
  };

  const displayedSessions = view === 'calendar'
    ? sessions.filter((s) => toDateString(s.scheduledAt) === selectedDate).sort((a, b) => a.scheduledAt.localeCompare(b.scheduledAt))
    : sessions;

  return (
    <View style={{ flex: 1, backgroundColor: theme.colors.background, padding: theme.spacing(6) }}>
      <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: theme.spacing(10), marginBottom: theme.spacing(5) }}>
        <Text style={{ color: theme.colors.text, fontSize: theme.fontSize.xxl, fontWeight: '800' }}>
          My Sessions
        </Text>
        <View style={{ flexDirection: 'row', backgroundColor: theme.colors.inputBackground, borderRadius: theme.radius.pill, padding: 3 }}>
          {(['list', 'calendar'] as const).map((v) => (
            <Pressable
              key={v}
              onPress={() => setView(v)}
              style={{
                paddingVertical: 6,
                paddingHorizontal: 14,
                borderRadius: theme.radius.pill,
                backgroundColor: view === v ? theme.colors.primary : 'transparent',
              }}
            >
              <Text style={{ color: view === v ? theme.colors.textInverse : theme.colors.textMuted, fontWeight: '600', fontSize: 13, textTransform: 'capitalize' }}>
                {v}
              </Text>
            </Pressable>
          ))}
        </View>
      </View>

      {error ? <Text style={{ color: theme.colors.danger, marginBottom: 12 }}>{error}</Text> : null}

      {loading ? (
        <View>
          <Skeleton height={90} style={{ marginBottom: 12 }} />
          <Skeleton height={90} />
        </View>
      ) : (
        <>
          {view === 'calendar' ? (
            <Calendar
              current={selectedDate}
              markedDates={markedDates}
              onDayPress={(day: DateData) => setSelectedDate(day.dateString)}
              theme={calendarTheme}
              style={{ marginBottom: theme.spacing(3) }}
            />
          ) : null}

          <FlatList
            data={displayedSessions}
            keyExtractor={(item) => String(item.id)}
            refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={theme.colors.primary} />}
            ListEmptyComponent={
              <Text style={{ color: theme.colors.textMuted, textAlign: 'center', marginTop: 40 }}>
                {view === 'calendar' ? 'Nothing scheduled on this day.' : 'No sessions yet.'}
              </Text>
            }
            renderItem={({ item }) => (
              <GlassCard
                style={{ marginBottom: theme.spacing(3) }}
                onTouchEnd={() => navigation.navigate('SessionDetail', { sessionId: item.id })}
              >
                <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                  <View style={{ flex: 1 }}>
                    <Text style={{ color: theme.colors.text, fontSize: theme.fontSize.md, fontWeight: '700' }}>
                      {item.subject}
                    </Text>
                    <Text style={{ color: theme.colors.textMuted, marginTop: 4 }}>
                      {user?.role === 'TEACHER' ? `${item.enrolledStudents.length} student(s)` : `with ${item.teacher.fullName}`}
                    </Text>
                    <Text style={{ color: theme.colors.textMuted, marginTop: 4 }}>
                      {view === 'calendar'
                        ? new Date(item.scheduledAt).toLocaleTimeString(undefined, { hour: 'numeric', minute: '2-digit' })
                        : new Date(item.scheduledAt).toLocaleString()}
                    </Text>
                  </View>
                  <Badge label={item.status} tone={statusTone[item.status]} />
                </View>
              </GlassCard>
            )}
          />
        </>
      )}
    </View>
  );
}
