import React, { useEffect, useState } from 'react';
import { FlatList, Text, View } from 'react-native';
import { getPaymentHistory, requestWithdrawal } from '../api/payments';
import { ApiError } from '../api/client';
import { Payment } from '../api/types';
import { useAppTheme } from '../theme/ThemeContext';
import { useAuth } from '../context/AuthContext';
import { GlassCard } from '../components/GlassCard';
import { Badge } from '../components/Badge';
import { Button } from '../components/Button';
import { TextField } from '../components/TextField';
import { Skeleton } from '../components/Skeleton';

export function PaymentsScreen() {
  const { theme } = useAppTheme();
  const { user } = useAuth();
  const isTeacher = user?.role === 'TEACHER';

  const [payments, setPayments] = useState<Payment[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const [amount, setAmount] = useState('');
  const [momoNumber, setMomoNumber] = useState('');
  const [withdrawing, setWithdrawing] = useState(false);
  const [withdrawMessage, setWithdrawMessage] = useState<string | null>(null);

  const load = async () => {
    try {
      const history = await getPaymentHistory();
      setPayments(history);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Could not load payment history');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
  }, []);

  const handleWithdraw = async () => {
    if (!amount.trim() || isNaN(Number(amount)) || !momoNumber.trim()) {
      setWithdrawMessage('Enter a valid amount and Mobile Money number.');
      return;
    }
    setWithdrawing(true);
    setWithdrawMessage(null);
    try {
      const res = await requestWithdrawal(Number(amount), momoNumber.trim());
      setWithdrawMessage(res.message || 'Withdrawal requested.');
      setAmount('');
      setMomoNumber('');
      load();
    } catch (err) {
      setWithdrawMessage(err instanceof ApiError ? err.message : 'Withdrawal failed');
    } finally {
      setWithdrawing(false);
    }
  };

  return (
    <View style={{ flex: 1, backgroundColor: theme.colors.background, padding: theme.spacing(6) }}>
      <Text style={{ color: theme.colors.text, fontSize: theme.fontSize.xxl, fontWeight: '800', marginTop: theme.spacing(10), marginBottom: theme.spacing(5) }}>
        {isTeacher ? 'Earnings' : 'Payments'}
      </Text>

      {isTeacher ? (
        <GlassCard style={{ marginBottom: theme.spacing(6) }}>
          <Text style={{ color: theme.colors.textMuted, fontSize: 13, fontWeight: '700', marginBottom: theme.spacing(3) }}>
            REQUEST WITHDRAWAL
          </Text>
          <TextField label="Amount (GHC)" keyboardType="decimal-pad" value={amount} onChangeText={setAmount} />
          <TextField label="Mobile Money number" keyboardType="phone-pad" value={momoNumber} onChangeText={setMomoNumber} />
          {withdrawMessage ? (
            <Text style={{ color: theme.colors.textMuted, marginBottom: 10 }}>{withdrawMessage}</Text>
          ) : null}
          <Button title="Request Withdrawal" onPress={handleWithdraw} loading={withdrawing} />
        </GlassCard>
      ) : null}

      <Text style={{ color: theme.colors.text, fontSize: theme.fontSize.lg, fontWeight: '700', marginBottom: theme.spacing(3) }}>
        History
      </Text>

      {error ? <Text style={{ color: theme.colors.danger, marginBottom: 12 }}>{error}</Text> : null}

      {loading ? (
        <Skeleton height={70} />
      ) : (
        <FlatList
          data={payments}
          keyExtractor={(item) => String(item.id)}
          ListEmptyComponent={
            <Text style={{ color: theme.colors.textMuted, textAlign: 'center', marginTop: 30 }}>
              No transactions yet.
            </Text>
          }
          renderItem={({ item }) => (
            <GlassCard style={{ marginBottom: theme.spacing(3) }}>
              <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
                <View>
                  <Text style={{ color: theme.colors.text, fontWeight: '700' }}>{item.type}</Text>
                  <Text style={{ color: theme.colors.textMuted, marginTop: 4 }}>
                    {new Date(item.createdAt).toLocaleDateString()}
                  </Text>
                </View>
                <View style={{ alignItems: 'flex-end' }}>
                  <Text style={{ color: theme.colors.text, fontWeight: '700' }}>GHC {item.amount.toFixed(2)}</Text>
                  <Badge label={item.status} tone={item.status === 'COMPLETED' ? 'success' : 'neutral'} />
                </View>
              </View>
            </GlassCard>
          )}
        />
      )}
    </View>
  );
}
