import React from 'react';
import { Pressable, ScrollView, Text, View } from 'react-native';
import { useAppTheme } from '../theme/ThemeContext';
import { useAuth } from '../context/AuthContext';
import { useChat } from '../context/ChatContext';
import { GlassCard } from '../components/GlassCard';
import { Badge } from '../components/Badge';
import { Button } from '../components/Button';

interface Props {
  navigation?: { navigate: (screen: 'Inbox' | 'Subscription' | 'Referrals') => void };
}

const THEME_OPTIONS: { label: string; value: 'light' | 'dark' | 'system' }[] = [
  { label: 'Light', value: 'light' },
  { label: 'Dark', value: 'dark' },
  { label: 'System', value: 'system' },
];

export function SettingsScreen({ navigation }: Props) {
  const { theme, preference, setPreference } = useAppTheme();
  const { user, logout } = useAuth();
  const { totalUnread } = useChat();
  const canMessage = user?.role === 'STUDENT' || user?.role === 'TEACHER';

  return (
    <ScrollView style={{ flex: 1, backgroundColor: theme.colors.background }} contentContainerStyle={{ padding: theme.spacing(6) }}>
      <Text style={{ color: theme.colors.text, fontSize: theme.fontSize.xxl, fontWeight: '800', marginTop: theme.spacing(10), marginBottom: theme.spacing(6) }}>
        Settings
      </Text>

      <GlassCard style={{ marginBottom: theme.spacing(5) }}>
        <Text style={{ color: theme.colors.textMuted, fontSize: 13, fontWeight: '700', marginBottom: 6 }}>ACCOUNT</Text>
        <Text style={{ color: theme.colors.text, fontSize: theme.fontSize.md, fontWeight: '700' }}>{user?.fullName}</Text>
        <Text style={{ color: theme.colors.textMuted, marginTop: 2 }}>{user?.email}</Text>
      </GlassCard>

      {navigation && canMessage ? (
        <Pressable onPress={() => navigation.navigate('Inbox')} style={{ marginBottom: theme.spacing(5) }}>
          <GlassCard>
            <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
              <Text style={{ color: theme.colors.text, fontWeight: '700' }}>Messages</Text>
              {totalUnread > 0 ? <Badge label={String(totalUnread)} tone="primary" /> : null}
            </View>
          </GlassCard>
        </Pressable>
      ) : null}

      {navigation && user?.role === 'STUDENT' ? (
        <Pressable onPress={() => navigation.navigate('Subscription')} style={{ marginBottom: theme.spacing(5) }}>
          <GlassCard>
            <Text style={{ color: theme.colors.text, fontWeight: '700' }}>Plans & Billing</Text>
          </GlassCard>
        </Pressable>
      ) : null}

      {navigation && canMessage ? (
        <Pressable onPress={() => navigation.navigate('Referrals')} style={{ marginBottom: theme.spacing(5) }}>
          <GlassCard>
            <Text style={{ color: theme.colors.text, fontWeight: '700' }}>Invite Friends</Text>
          </GlassCard>
        </Pressable>
      ) : null}

      <GlassCard style={{ marginBottom: theme.spacing(6) }}>
        <Text style={{ color: theme.colors.textMuted, fontSize: 13, fontWeight: '700', marginBottom: theme.spacing(3) }}>
          APPEARANCE
        </Text>
        <View style={{ flexDirection: 'row', gap: 8 }}>
          {THEME_OPTIONS.map((opt) => (
            <Pressable
              key={opt.value}
              onPress={() => setPreference(opt.value)}
              style={{
                flex: 1,
                paddingVertical: 10,
                borderRadius: theme.radius.md,
                alignItems: 'center',
                backgroundColor: preference === opt.value ? theme.colors.primary : theme.colors.inputBackground,
              }}
            >
              <Text style={{ color: preference === opt.value ? theme.colors.textInverse : theme.colors.text, fontWeight: '600' }}>
                {opt.label}
              </Text>
            </Pressable>
          ))}
        </View>
      </GlassCard>

      <Button title="Log Out" variant="danger" onPress={logout} />
    </ScrollView>
  );
}
