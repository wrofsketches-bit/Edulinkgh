import React, { useCallback, useState } from 'react';
import { Share, Text, View } from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { getMyReferralStats } from '../api/referrals';
import { ApiError } from '../api/client';
import { ReferralStats } from '../api/types';
import { useAppTheme } from '../theme/ThemeContext';
import { GlassCard } from '../components/GlassCard';
import { Button } from '../components/Button';
import { Skeleton } from '../components/Skeleton';

export function ReferralScreen() {
  const { theme } = useAppTheme();
  const [stats, setStats] = useState<ReferralStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useFocusEffect(
    useCallback(() => {
      (async () => {
        try {
          const result = await getMyReferralStats();
          setStats(result);
        } catch (err) {
          setError(err instanceof ApiError ? err.message : 'Could not load referral info');
        } finally {
          setLoading(false);
        }
      })();
    }, [])
  );

  const handleShare = () => {
    if (!stats) return;
    Share.share({
      message: `Join me on EduLinkGH! Use my referral code ${stats.referralCode} when you sign up.`,
    });
  };

  if (loading) {
    return (
      <View style={{ flex: 1, backgroundColor: theme.colors.background, padding: theme.spacing(6) }}>
        <Skeleton height={100} style={{ marginTop: 60, marginBottom: 20 }} />
        <Skeleton height={100} />
      </View>
    );
  }

  return (
    <View style={{ flex: 1, backgroundColor: theme.colors.background, padding: theme.spacing(6) }}>
      <Text style={{ color: theme.colors.text, fontSize: theme.fontSize.xxl, fontWeight: '800', marginTop: theme.spacing(10), marginBottom: theme.spacing(2) }}>
        Invite Friends
      </Text>
      <Text style={{ color: theme.colors.textMuted, marginBottom: theme.spacing(5) }}>
        Earn a free day of Plus for every {stats?.referralsPerReward ?? 80} people who sign up with your code.
      </Text>

      {error ? <Text style={{ color: theme.colors.danger, marginBottom: 12 }}>{error}</Text> : null}

      {stats ? (
        <>
          <GlassCard style={{ marginBottom: theme.spacing(5), alignItems: 'center' }}>
            <Text style={{ color: theme.colors.textMuted, fontSize: 13, fontWeight: '700', marginBottom: 8 }}>
              YOUR CODE
            </Text>
            <Text style={{ color: theme.colors.primary, fontSize: theme.fontSize.xxl, fontWeight: '800', letterSpacing: 2 }}>
              {stats.referralCode}
            </Text>
          </GlassCard>

          <View style={{ flexDirection: 'row', gap: theme.spacing(3), marginBottom: theme.spacing(5) }}>
            <GlassCard style={{ flex: 1, alignItems: 'center' }}>
              <Text style={{ color: theme.colors.text, fontSize: theme.fontSize.xl, fontWeight: '800' }}>
                {stats.totalReferrals}
              </Text>
              <Text style={{ color: theme.colors.textMuted, fontSize: 12, marginTop: 2 }}>total referrals</Text>
            </GlassCard>
            <GlassCard style={{ flex: 1, alignItems: 'center' }}>
              <Text style={{ color: theme.colors.text, fontSize: theme.fontSize.xl, fontWeight: '800' }}>
                {stats.rewardsEarned}
              </Text>
              <Text style={{ color: theme.colors.textMuted, fontSize: 12, marginTop: 2 }}>free days earned</Text>
            </GlassCard>
          </View>

          <GlassCard style={{ marginBottom: theme.spacing(5) }}>
            <Text style={{ color: theme.colors.textMuted, fontSize: 13, fontWeight: '700', marginBottom: 8 }}>
              PROGRESS TO NEXT REWARD
            </Text>
            <Text style={{ color: theme.colors.text, marginBottom: 8 }}>
              {stats.progressTowardNextReward} / {stats.referralsPerReward}
            </Text>
            <View style={{ height: 8, backgroundColor: theme.colors.inputBackground, borderRadius: 4 }}>
              <View
                style={{
                  height: 8,
                  width: `${Math.min(100, (stats.progressTowardNextReward / stats.referralsPerReward) * 100)}%`,
                  backgroundColor: theme.colors.primary,
                  borderRadius: 4,
                }}
              />
            </View>
          </GlassCard>

          <Button title="Share My Code" onPress={handleShare} />
        </>
      ) : null}
    </View>
  );
}
