import React, { useCallback, useEffect, useState } from 'react';
import { ScrollView, Text, View } from 'react-native';
import { getMyProfile, updateProfile } from '../api/users';
import { ApiError } from '../api/client';
import { UserProfile } from '../api/types';
import { useAppTheme } from '../theme/ThemeContext';
import { GlassCard } from '../components/GlassCard';
import { Badge } from '../components/Badge';
import { Button } from '../components/Button';
import { TextField } from '../components/TextField';
import { Skeleton } from '../components/Skeleton';

interface Props {
  navigation: { navigate: (screen: 'Settings') => void };
}

export function ProfileScreen({ navigation }: Props) {
  const { theme } = useAppTheme();
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [editingBio, setEditingBio] = useState(false);
  const [bioDraft, setBioDraft] = useState('');
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    try {
      const p = await getMyProfile();
      setProfile(p);
      setBioDraft(p.bio || '');
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Could not load profile');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const saveBio = async () => {
    setSaving(true);
    try {
      const updated = await updateProfile({ bio: bioDraft });
      setProfile(updated);
      setEditingBio(false);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Could not save changes');
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <View style={{ flex: 1, backgroundColor: theme.colors.background, padding: theme.spacing(6) }}>
        <Skeleton height={30} width="50%" style={{ marginTop: 60, marginBottom: 20 }} />
        <Skeleton height={100} />
      </View>
    );
  }

  if (error || !profile) {
    return (
      <View style={{ flex: 1, backgroundColor: theme.colors.background, padding: theme.spacing(6), justifyContent: 'center' }}>
        <Text style={{ color: theme.colors.danger, textAlign: 'center' }}>{error || 'Profile unavailable'}</Text>
      </View>
    );
  }

  return (
    <ScrollView style={{ flex: 1, backgroundColor: theme.colors.background }} contentContainerStyle={{ padding: theme.spacing(6) }}>
      <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', marginTop: theme.spacing(10), marginBottom: theme.spacing(6) }}>
        <View>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
            <Text style={{ color: theme.colors.text, fontSize: theme.fontSize.xxl, fontWeight: '800' }}>
              {profile.fullName}
            </Text>
            {profile.role === 'TEACHER' && profile.qualificationVerified ? <Badge label="Verified" tone="success" /> : null}
          </View>
          <Text style={{ color: theme.colors.textMuted, marginTop: 4 }}>{profile.email}</Text>
        </View>
        <Text onPress={() => navigation.navigate('Settings')} style={{ color: theme.colors.primary, fontWeight: '600' }}>
          Settings
        </Text>
      </View>

      <GlassCard style={{ marginBottom: theme.spacing(5) }}>
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginBottom: 8 }}>
          <Text style={{ color: theme.colors.textMuted, fontSize: 13, fontWeight: '700' }}>ABOUT</Text>
          <Text onPress={() => setEditingBio((v) => !v)} style={{ color: theme.colors.primary, fontWeight: '600' }}>
            {editingBio ? 'Cancel' : 'Edit'}
          </Text>
        </View>
        {editingBio ? (
          <>
            <TextField value={bioDraft} onChangeText={setBioDraft} multiline placeholder="Tell students about yourself..." />
            <Button title="Save" onPress={saveBio} loading={saving} />
          </>
        ) : (
          <Text style={{ color: theme.colors.text }}>{profile.bio || 'No bio added yet.'}</Text>
        )}
      </GlassCard>

      {profile.role === 'TEACHER' ? (
        <GlassCard style={{ marginBottom: theme.spacing(5) }}>
          <Text style={{ color: theme.colors.textMuted, fontSize: 13, fontWeight: '700', marginBottom: 6 }}>TEACHING INFO</Text>
          <Text style={{ color: theme.colors.text }}>Subject: {profile.subject || '—'}</Text>
          <Text style={{ color: theme.colors.text, marginTop: 4 }}>Level: {profile.teachingLevel || '—'}</Text>
          <Text style={{ color: theme.colors.text, marginTop: 4 }}>Qualification: {profile.qualification || '—'}</Text>
        </GlassCard>
      ) : (
        <GlassCard style={{ marginBottom: theme.spacing(5) }}>
          <Text style={{ color: theme.colors.textMuted, fontSize: 13, fontWeight: '700', marginBottom: 6 }}>SCHOOL</Text>
          <Text style={{ color: theme.colors.text }}>{profile.schoolName || 'Not specified'}</Text>
        </GlassCard>
      )}
    </ScrollView>
  );
}
