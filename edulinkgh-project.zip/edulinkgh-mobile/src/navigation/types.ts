import type { Quiz } from '../api/types';

export type AuthStackParamList = {
  Login: undefined;
  Register: undefined;
  ForgotPassword: undefined;
};

export type StudentTabParamList = {
  FindTeachers: undefined;
  MySessions: undefined;
  Payments: undefined;
  Profile: undefined;
};

export type TeacherTabParamList = {
  Dashboard: undefined;
  MySessions: undefined;
  Earnings: undefined;
  Profile: undefined;
};

export type StudentStackParamList = {
  StudentTabs: undefined;
  TeacherProfile: { teacherId: number };
  BookSession: { teacherId: number };
  SessionDetail: { sessionId: number };
  VideoCall: { sessionId: number };
  HomeworkHelper: undefined;
  QuizGenerator: undefined;
  QuizTake: { quiz: Quiz };
  TeacherMatching: undefined;
  Progress: undefined;
  Insights: undefined;
  Subscription: undefined;
  Referrals: undefined;
  Inbox: undefined;
  Conversation: { userId: number; userName: string };
  Settings: undefined;
};

export type TeacherStackParamList = {
  TeacherTabs: undefined;
  CreateSession: undefined;
  SessionDetail: { sessionId: number };
  VideoCall: { sessionId: number };
  Availability: undefined;
  Trends: undefined;
  Referrals: undefined;
  Inbox: undefined;
  Conversation: { userId: number; userName: string };
  Settings: undefined;
};

export type AdminTabParamList = {
  Overview: undefined;
  Analytics: undefined;
  Teachers: undefined;
  Students: undefined;
  Sessions: undefined;
};

export type AdminStackParamList = {
  AdminTabs: undefined;
  UserDetail: { userId: number };
  Settings: undefined;
};
