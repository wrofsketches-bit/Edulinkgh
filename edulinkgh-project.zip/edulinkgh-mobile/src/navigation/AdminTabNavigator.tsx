import React from 'react';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Text } from 'react-native';
import { AdminOverviewScreen } from '../screens/admin/AdminOverviewScreen';
import { AdminAnalyticsScreen } from '../screens/admin/AdminAnalyticsScreen';
import { AdminTeachersScreen } from '../screens/admin/AdminTeachersScreen';
import { AdminStudentsScreen } from '../screens/admin/AdminStudentsScreen';
import { AdminSessionsScreen } from '../screens/admin/AdminSessionsScreen';
import { useAppTheme } from '../theme/ThemeContext';
import type { AdminTabParamList } from './types';

const Tab = createBottomTabNavigator<AdminTabParamList>();

const icons: Record<keyof AdminTabParamList, string> = {
  Overview: '📊',
  Analytics: '📈',
  Teachers: '🧑‍🏫',
  Students: '🎓',
  Sessions: '📅',
};

export function AdminTabNavigator() {
  const { theme } = useAppTheme();

  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        headerShown: false,
        tabBarActiveTintColor: theme.colors.primary,
        tabBarInactiveTintColor: theme.colors.textMuted,
        tabBarStyle: { backgroundColor: theme.colors.tabBar, borderTopColor: theme.colors.border },
        tabBarIcon: () => <Text style={{ fontSize: 18 }}>{icons[route.name as keyof AdminTabParamList]}</Text>,
      })}
    >
      <Tab.Screen name="Overview" component={AdminOverviewScreen} />
      <Tab.Screen name="Analytics" component={AdminAnalyticsScreen} />
      <Tab.Screen name="Teachers" component={AdminTeachersScreen} />
      <Tab.Screen name="Students" component={AdminStudentsScreen} />
      <Tab.Screen name="Sessions" component={AdminSessionsScreen} />
    </Tab.Navigator>
  );
}
