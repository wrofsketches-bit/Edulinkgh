import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { StudentTabNavigator } from './StudentTabNavigator';
import { TeacherProfileScreen } from '../screens/student/TeacherProfileScreen';
import { BookSessionScreen } from '../screens/student/BookSessionScreen';
import { HomeworkHelperScreen } from '../screens/student/HomeworkHelperScreen';
import { QuizGeneratorScreen } from '../screens/student/QuizGeneratorScreen';
import { QuizTakeScreen } from '../screens/student/QuizTakeScreen';
import { TeacherMatchingScreen } from '../screens/student/TeacherMatchingScreen';
import { ProgressScreen } from '../screens/student/ProgressScreen';
import { StudentInsightsScreen } from '../screens/student/StudentInsightsScreen';
import { SubscriptionScreen } from '../screens/student/SubscriptionScreen';
import { ReferralScreen } from '../screens/ReferralScreen';
import { SessionDetailScreen } from '../screens/SessionDetailScreen';
import { VideoCallScreen } from '../screens/VideoCallScreen';
import { InboxScreen } from '../screens/InboxScreen';
import { ConversationScreen } from '../screens/ConversationScreen';
import { SettingsScreen } from '../screens/SettingsScreen';
import { useAppTheme } from '../theme/ThemeContext';
import type { StudentStackParamList } from './types';

const Stack = createNativeStackNavigator<StudentStackParamList>();

export function StudentNavigator() {
  const { theme } = useAppTheme();

  return (
    <Stack.Navigator
      screenOptions={{
        headerStyle: { backgroundColor: theme.colors.surface },
        headerTintColor: theme.colors.text,
        headerShadowVisible: false,
      }}
    >
      <Stack.Screen name="StudentTabs" component={StudentTabNavigator} options={{ headerShown: false }} />
      <Stack.Screen name="TeacherProfile" component={TeacherProfileScreen} options={{ title: 'Teacher' }} />
      <Stack.Screen name="BookSession" component={BookSessionScreen} options={{ title: 'Book Session' }} />
      <Stack.Screen name="HomeworkHelper" component={HomeworkHelperScreen} options={{ title: 'Homework Helper' }} />
      <Stack.Screen name="QuizGenerator" component={QuizGeneratorScreen} options={{ title: 'Quiz Generator' }} />
      <Stack.Screen name="QuizTake" component={QuizTakeScreen} options={{ title: 'Quiz' }} />
      <Stack.Screen name="TeacherMatching" component={TeacherMatchingScreen} options={{ title: 'Find My Match' }} />
      <Stack.Screen name="Progress" component={ProgressScreen} options={{ title: 'My Progress' }} />
      <Stack.Screen name="Insights" component={StudentInsightsScreen} options={{ title: 'Learning Insights' }} />
      <Stack.Screen name="Subscription" component={SubscriptionScreen} options={{ title: 'Plans' }} />
      <Stack.Screen name="Referrals" component={ReferralScreen} options={{ title: 'Invite Friends' }} />
      <Stack.Screen name="SessionDetail" component={SessionDetailScreen} options={{ title: 'Session' }} />
      <Stack.Screen name="VideoCall" component={VideoCallScreen} options={{ title: '', headerStyle: { backgroundColor: '#000' }, headerTintColor: '#fff' }} />
      <Stack.Screen name="Inbox" component={InboxScreen as never} options={{ title: 'Messages' }} />
      <Stack.Screen name="Conversation" component={ConversationScreen as never} options={{ title: '' }} />
      <Stack.Screen name="Settings" component={SettingsScreen} />
    </Stack.Navigator>
  );
}
