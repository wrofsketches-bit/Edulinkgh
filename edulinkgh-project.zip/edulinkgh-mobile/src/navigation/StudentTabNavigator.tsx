import React from 'react';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Text } from 'react-native';
import { FindTeachersScreen } from '../screens/student/FindTeachersScreen';
import { MySessionsScreen } from '../screens/MySessionsScreen';
import { PaymentsScreen } from '../screens/PaymentsScreen';
import { ProfileScreen } from '../screens/ProfileScreen';
import { useAppTheme } from '../theme/ThemeContext';
import type { StudentTabParamList } from './types';

const Tab = createBottomTabNavigator<StudentTabParamList>();

const icons: Record<keyof StudentTabParamList, string> = {
  FindTeachers: '🔎',
  MySessions: '📅',
  Payments: '💳',
  Profile: '👤',
};

export function StudentTabNavigator() {
  const { theme } = useAppTheme();

  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        headerShown: false,
        tabBarActiveTintColor: theme.colors.primary,
        tabBarInactiveTintColor: theme.colors.textMuted,
        tabBarStyle: { backgroundColor: theme.colors.tabBar, borderTopColor: theme.colors.border },
        tabBarIcon: () => <Text style={{ fontSize: 18 }}>{icons[route.name as keyof StudentTabParamList]}</Text>,
      })}
    >
      <Tab.Screen name="FindTeachers" component={FindTeachersScreen} options={{ title: 'Find' }} />
      <Tab.Screen name="MySessions" component={MySessionsScreen as never} options={{ title: 'Sessions' }} />
      <Tab.Screen name="Payments" component={PaymentsScreen} options={{ title: 'Payments' }} />
      <Tab.Screen name="Profile" component={ProfileScreen as never} options={{ title: 'Profile' }} />
    </Tab.Navigator>
  );
}
