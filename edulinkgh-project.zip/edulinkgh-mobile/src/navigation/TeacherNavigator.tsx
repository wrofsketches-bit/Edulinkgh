import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { TeacherTabNavigator } from './TeacherTabNavigator';
import { CreateSessionScreen } from '../screens/teacher/CreateSessionScreen';
import { TeacherAvailabilityScreen } from '../screens/teacher/TeacherAvailabilityScreen';
import { TeacherTrendsScreen } from '../screens/teacher/TeacherTrendsScreen';
import { SessionDetailScreen } from '../screens/SessionDetailScreen';
import { VideoCallScreen } from '../screens/VideoCallScreen';
import { ReferralScreen } from '../screens/ReferralScreen';
import { InboxScreen } from '../screens/InboxScreen';
import { ConversationScreen } from '../screens/ConversationScreen';
import { SettingsScreen } from '../screens/SettingsScreen';
import { useAppTheme } from '../theme/ThemeContext';
import type { TeacherStackParamList } from './types';

const Stack = createNativeStackNavigator<TeacherStackParamList>();

export function TeacherNavigator() {
  const { theme } = useAppTheme();

  return (
    <Stack.Navigator
      screenOptions={{
        headerStyle: { backgroundColor: theme.colors.surface },
        headerTintColor: theme.colors.text,
        headerShadowVisible: false,
      }}
    >
      <Stack.Screen name="TeacherTabs" component={TeacherTabNavigator} options={{ headerShown: false }} />
      <Stack.Screen name="CreateSession" component={CreateSessionScreen} options={{ title: 'New Session' }} />
      <Stack.Screen name="Availability" component={TeacherAvailabilityScreen} options={{ title: 'Availability' }} />
      <Stack.Screen name="Trends" component={TeacherTrendsScreen} options={{ title: 'Performance Trends' }} />
      <Stack.Screen name="Referrals" component={ReferralScreen} options={{ title: 'Invite Friends' }} />
      <Stack.Screen name="SessionDetail" component={SessionDetailScreen} options={{ title: 'Session' }} />
      <Stack.Screen name="VideoCall" component={VideoCallScreen} options={{ title: '', headerStyle: { backgroundColor: '#000' }, headerTintColor: '#fff' }} />
      <Stack.Screen name="Inbox" component={InboxScreen as never} options={{ title: 'Messages' }} />
      <Stack.Screen name="Conversation" component={ConversationScreen as never} options={{ title: '' }} />
      <Stack.Screen name="Settings" component={SettingsScreen} />
    </Stack.Navigator>
  );
}
