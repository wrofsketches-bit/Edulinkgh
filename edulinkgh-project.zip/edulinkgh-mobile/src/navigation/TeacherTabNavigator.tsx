import React from 'react';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Text } from 'react-native';
import { TeacherDashboardScreen } from '../screens/teacher/TeacherDashboardScreen';
import { MySessionsScreen } from '../screens/MySessionsScreen';
import { PaymentsScreen } from '../screens/PaymentsScreen';
import { ProfileScreen } from '../screens/ProfileScreen';
import { useAppTheme } from '../theme/ThemeContext';
import type { TeacherTabParamList } from './types';

const Tab = createBottomTabNavigator<TeacherTabParamList>();

const icons: Record<keyof TeacherTabParamList, string> = {
  Dashboard: '🏠',
  MySessions: '📅',
  Earnings: '💰',
  Profile: '👤',
};

export function TeacherTabNavigator() {
  const { theme } = useAppTheme();

  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        headerShown: false,
        tabBarActiveTintColor: theme.colors.primary,
        tabBarInactiveTintColor: theme.colors.textMuted,
        tabBarStyle: { backgroundColor: theme.colors.tabBar, borderTopColor: theme.colors.border },
        tabBarIcon: () => <Text style={{ fontSize: 18 }}>{icons[route.name as keyof TeacherTabParamList]}</Text>,
      })}
    >
      <Tab.Screen name="Dashboard" component={TeacherDashboardScreen as never} />
      <Tab.Screen name="MySessions" component={MySessionsScreen as never} options={{ title: 'Sessions' }} />
      <Tab.Screen name="Earnings" component={PaymentsScreen} />
      <Tab.Screen name="Profile" component={ProfileScreen as never} />
    </Tab.Navigator>
  );
}
