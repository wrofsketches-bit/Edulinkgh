import { apiRequest, apiUpload } from './client';
import { UserProfile } from './types';

export function getMyProfile() {
  return apiRequest<UserProfile>('/api/users/me');
}

export function updateProfile(updates: Partial<Record<string, string>>) {
  return apiRequest<UserProfile>('/api/users/me', { method: 'PUT', body: updates });
}

export function changePassword(currentPassword: string, newPassword: string) {
  return apiRequest<{ message: string }>('/api/users/me/change-password', {
    method: 'POST',
    body: { currentPassword, newPassword },
  });
}

export function uploadCertificate(fileUri: string, fileName: string, mimeType: string) {
  return apiUpload<UserProfile>('/api/users/me/certificate', fileUri, fileName, mimeType);
}

export function uploadProfilePhoto(fileUri: string, fileName: string, mimeType: string) {
  return apiUpload<UserProfile>('/api/users/me/photo', fileUri, fileName, mimeType);
}
