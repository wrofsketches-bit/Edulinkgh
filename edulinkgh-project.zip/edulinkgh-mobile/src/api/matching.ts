import { apiRequest } from './client';
import { TeacherMatch } from './types';

export function matchTeachers(request: string) {
  return apiRequest<TeacherMatch[]>('/api/ai/match', {
    method: 'POST',
    body: { request },
  });
}
