import { apiRequest } from './client';
import { Payment } from './types';

export function getPaymentHistory() {
  return apiRequest<Payment[]>('/api/payments/history');
}

export interface InitiatePaymentResult {
  checkoutUrl: string;
  reference: string;
  providerReference: string;
  amount: number;
  originalAmount: number;
  discountAmount: number;
}

/** Starts a session payment. Open the returned checkoutUrl in a browser, then call confirmPayment. */
export function initiateSessionPayment(sessionId: number, promoCode?: string) {
  return apiRequest<InitiatePaymentResult>(`/api/payments/session/${sessionId}`, {
    method: 'POST',
    body: promoCode ? { promoCode } : {},
  });
}

export interface ConfirmPaymentResult {
  status: 'SUCCESS' | 'FAILED' | 'PENDING' | 'NOT_FOUND';
  message: string;
  reference?: string;
  amount?: number;
}

/** Call after the user returns from checkout, using the providerReference (not the internal reference) from initiate. */
export function confirmPayment(providerReference: string) {
  return apiRequest<ConfirmPaymentResult>(`/api/payments/confirm/${providerReference}`, { method: 'POST' });
}

export function requestWithdrawal(amount: number, momoNumber: string) {
  return apiRequest<{ message: string }>('/api/payments/withdraw', {
    method: 'POST',
    body: { amount, momoNumber },
  });
}
