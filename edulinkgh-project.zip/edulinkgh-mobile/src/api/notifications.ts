import { apiRequest } from './client';

export function registerPushToken(fcmToken: string, platform: 'android' | 'ios') {
  return apiRequest<{ message: string }>('/api/notifications/register-token', {
    method: 'POST',
    body: { fcmToken, platform },
  });
}

export function unregisterPushToken(fcmToken: string) {
  return apiRequest<{ message: string }>('/api/notifications/unregister-token', {
    method: 'POST',
    body: { fcmToken },
  });
}
