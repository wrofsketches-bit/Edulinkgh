import { apiRequest } from './client';
import { StudentInsights } from './types';

export function getStudentInsights(days?: number) {
  const qs = days ? `?days=${days}` : '';
  return apiRequest<StudentInsights>(`/api/students/me/insights${qs}`);
}
