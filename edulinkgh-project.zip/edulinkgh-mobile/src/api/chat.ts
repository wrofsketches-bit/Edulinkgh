import { apiRequest, apiUploadWithFields } from './client';
import { ChatMessage, InboxEntry } from './types';

export function getInbox() {
  return apiRequest<InboxEntry[]>('/api/chat/inbox');
}

export function getConversation(otherUserId: number) {
  return apiRequest<ChatMessage[]>(`/api/chat/conversation/${otherUserId}`);
}

export function sendChatAttachment(
  recipientId: number,
  fileUri: string,
  fileName: string,
  mimeType: string,
  caption?: string
) {
  return apiUploadWithFields<ChatMessage>('/api/chat/attachment', fileUri, fileName, mimeType, {
    recipientId: String(recipientId),
    ...(caption ? { caption } : {}),
  });
}
