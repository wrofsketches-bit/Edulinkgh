import * as SecureStore from 'expo-secure-store';

// TODO: point this at your deployed Spring Boot backend.
// For local dev on a physical device/emulator, use your machine's LAN IP,
// not localhost (the phone can't reach your computer's localhost).
// Example: http://192.168.1.42:8080
export const API_BASE_URL = process.env.EXPO_PUBLIC_API_BASE_URL || 'http://localhost:8080';

const TOKEN_KEY = 'edulinkgh:jwt';

export async function getToken(): Promise<string | null> {
  return SecureStore.getItemAsync(TOKEN_KEY);
}

export async function setToken(token: string): Promise<void> {
  await SecureStore.setItemAsync(TOKEN_KEY, token);
}

export async function clearToken(): Promise<void> {
  await SecureStore.deleteItemAsync(TOKEN_KEY);
}

export class ApiError extends Error {
  status: number;
  constructor(message: string, status: number) {
    super(message);
    this.status = status;
  }
}

interface RequestOptions {
  method?: 'GET' | 'POST' | 'PUT' | 'DELETE';
  body?: unknown;
  auth?: boolean; // attach Authorization header (default true)
}

/**
 * Thin fetch wrapper: JSON in/out, attaches JWT, throws ApiError with the
 * backend's { error: "..." } message on non-2xx responses.
 */
export async function apiRequest<T>(path: string, options: RequestOptions = {}): Promise<T> {
  const { method = 'GET', body, auth = true } = options;

  const headers: Record<string, string> = { 'Content-Type': 'application/json' };

  if (auth) {
    const token = await getToken();
    if (token) headers.Authorization = `Bearer ${token}`;
  }

  let response: Response;
  try {
    response = await fetch(`${API_BASE_URL}${path}`, {
      method,
      headers,
      body: body !== undefined ? JSON.stringify(body) : undefined,
    });
  } catch (err) {
    throw new ApiError('Network error — check your connection and the server address.', 0);
  }

  const isJson = response.headers.get('content-type')?.includes('application/json');
  const data = isJson ? await response.json().catch(() => null) : null;

  if (!response.ok) {
    const message = (data && (data.error || data.message)) || `Request failed (${response.status})`;
    throw new ApiError(message, response.status);
  }

  return data as T;
}

/** Multipart upload helper (profile photo, certificate). */
export async function apiUpload<T>(path: string, fileUri: string, fileName: string, mimeType: string): Promise<T> {
  return apiUploadWithFields<T>(path, fileUri, fileName, mimeType, {});
}

/** Multipart upload with additional form fields alongside the file (e.g. chat attachments). */
export async function apiUploadWithFields<T>(
  path: string,
  fileUri: string,
  fileName: string,
  mimeType: string,
  fields: Record<string, string>
): Promise<T> {
  const token = await getToken();
  const formData = new FormData();
  formData.append('file', { uri: fileUri, name: fileName, type: mimeType } as unknown as Blob);
  Object.entries(fields).forEach(([key, value]) => formData.append(key, value));

  const response = await fetch(`${API_BASE_URL}${path}`, {
    method: 'POST',
    headers: {
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      // Do NOT set Content-Type manually — fetch sets the multipart boundary.
    },
    body: formData,
  });

  const data = await response.json().catch(() => null);
  if (!response.ok) {
    throw new ApiError((data && data.error) || 'Upload failed', response.status);
  }
  return data as T;
}
