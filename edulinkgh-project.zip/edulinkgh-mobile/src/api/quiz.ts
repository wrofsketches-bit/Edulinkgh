import { apiRequest } from './client';
import { Quiz } from './types';

export function generateQuiz(topic: string, difficulty?: string, questionCount?: number) {
  return apiRequest<Quiz>('/api/ai/quiz/generate', {
    method: 'POST',
    body: { topic, difficulty, questionCount },
  });
}

export function getQuizHistory() {
  return apiRequest<Quiz[]>('/api/ai/quiz/history');
}

export function getQuiz(quizId: number) {
  return apiRequest<Quiz>(`/api/ai/quiz/${quizId}`);
}
