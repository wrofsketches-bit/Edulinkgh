import { apiRequest } from './client';
import { Rating, TeacherSummary } from './types';

export interface TeacherSearchParams {
  search?: string;
  subject?: string;
  level?: string;
  minRating?: number;
}

export function searchTeachers(params: TeacherSearchParams = {}) {
  const query = new URLSearchParams();
  if (params.search) query.set('search', params.search);
  if (params.subject) query.set('subject', params.subject);
  if (params.level) query.set('level', params.level);
  if (params.minRating !== undefined) query.set('minRating', String(params.minRating));

  const qs = query.toString();
  return apiRequest<TeacherSummary[]>(`/api/teachers${qs ? `?${qs}` : ''}`);
}

export function getTeacher(id: number) {
  return apiRequest<TeacherSummary>(`/api/teachers/${id}`);
}

export function getTeacherRatings(id: number) {
  return apiRequest<Rating[]>(`/api/teachers/${id}/ratings`);
}

export function rateTeacher(id: number, stars: number, comment: string) {
  return apiRequest<Rating>(`/api/teachers/${id}/rate`, {
    method: 'POST',
    body: { stars, comment },
  });
}

export function getRatingStatus(id: number) {
  return apiRequest<{ canRate: boolean; alreadyRated: boolean }>(`/api/teachers/${id}/rating-status`);
}
