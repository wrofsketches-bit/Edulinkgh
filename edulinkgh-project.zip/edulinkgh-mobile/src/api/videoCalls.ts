import { apiRequest } from './client';
import { VideoCallJoinInfo } from './types';

export function getVideoCallJoinInfo(sessionId: number) {
  return apiRequest<VideoCallJoinInfo>(`/api/video-calls/session/${sessionId}/join`);
}
