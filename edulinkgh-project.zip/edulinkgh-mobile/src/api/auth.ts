import { apiRequest } from './client';
import { AuthResponse, RegisterPayload } from './types';

export function login(email: string, password: string) {
  return apiRequest<AuthResponse>('/api/auth/login', {
    method: 'POST',
    body: { email, password },
    auth: false,
  });
}

export function register(payload: RegisterPayload) {
  return apiRequest<AuthResponse>('/api/auth/register', {
    method: 'POST',
    body: payload,
    auth: false,
  });
}

export function forgotPassword(email: string) {
  // "otp" is a temporary field returned only until real email/SMS delivery
  // is wired up on the backend — see AuthService.forgotPassword.
  return apiRequest<{ message: string; otp?: string }>('/api/auth/forgot-password', {
    method: 'POST',
    body: { email },
    auth: false,
  });
}

export function resetPassword(email: string, otp: string, newPassword: string) {
  return apiRequest<{ message: string }>('/api/auth/reset-password', {
    method: 'POST',
    body: { email, otp, newPassword },
    auth: false,
  });
}
