import { API_BASE_URL, getToken } from './client';

interface StreamHandlers {
  onToken: (token: string) => void;
  onDone: () => void;
  onError: (message: string) => void;
}

/**
 * Streams a Server-Sent Events response from a POST endpoint.
 *
 * Deliberately uses XMLHttpRequest rather than fetch()'s
 * response.body.getReader() (the "standard" web approach) — Hermes, React
 * Native's JS engine, does not reliably implement ReadableStream on fetch
 * responses, which silently breaks incremental reading (tokens either never
 * arrive or all arrive at once when the request finishes, defeating the
 * whole point of streaming). XHR's onprogress event fires incrementally as
 * bytes arrive over the wire regardless of Hermes' ReadableStream support,
 * which is why this is the community-validated fix rather than a stopgap.
 *
 * Returns an abort function the caller can use to cancel the stream early
 * (e.g. the user navigates away mid-answer).
 */
export async function streamSse(
  path: string,
  body: Record<string, unknown>,
  handlers: StreamHandlers
): Promise<() => void> {
  const token = await getToken();
  const xhr = new XMLHttpRequest();
  let processedLength = 0;

  xhr.open('POST', `${API_BASE_URL}${path}`, true);
  xhr.setRequestHeader('Content-Type', 'application/json');
  xhr.setRequestHeader('Accept', 'text/event-stream');
  if (token) {
    xhr.setRequestHeader('Authorization', `Bearer ${token}`);
  }

  const processBuffer = () => {
    // xhr.responseText grows as data arrives. A single onprogress tick can
    // deliver a partial frame (e.g. the bytes for "data: some tok" with no
    // trailing blank line yet) — only advance processedLength past the
    // last COMPLETE frame boundary, so a frame split across two ticks gets
    // picked up whole on the next tick instead of silently losing its tail.
    const buffered = xhr.responseText.slice(processedLength);
    const lastBoundary = buffered.lastIndexOf('\n\n');
    if (lastBoundary === -1) return; // no complete frame yet — wait for more data

    const completeText = buffered.slice(0, lastBoundary);
    processedLength += lastBoundary + 2; // +2 to also consume the "\n\n" itself

    const frames = completeText.split('\n\n').filter((f) => f.trim().length > 0);

    for (const frame of frames) {
      const lines = frame.split('\n');
      let eventName = 'message';
      let data = '';
      for (const line of lines) {
        if (line.startsWith('event:')) eventName = line.slice(6).trim();
        else if (line.startsWith('data:')) data = line.slice(5).trim();
      }

      if (eventName === 'token') {
        handlers.onToken(data);
      } else if (eventName === 'done') {
        handlers.onDone();
      } else if (eventName === 'error') {
        handlers.onError(data || 'Something went wrong.');
      }
    }
  };

  xhr.onprogress = processBuffer;

  xhr.onerror = () => {
    handlers.onError('Connection lost. Please try again.');
  };

  xhr.onload = () => {
    // Catch anything that arrived between the last onprogress tick and the
    // connection closing — onprogress isn't guaranteed to fire one final
    // time exactly at completion.
    processBuffer();
    if (xhr.status !== 200) {
      handlers.onError(`Request failed (${xhr.status}).`);
    }
  };

  xhr.send(JSON.stringify(body));

  return () => xhr.abort();
}
