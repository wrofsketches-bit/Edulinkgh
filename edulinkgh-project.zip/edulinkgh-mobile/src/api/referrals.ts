import { apiRequest } from './client';
import { ReferralStats } from './types';

export function getMyReferralStats() {
  return apiRequest<ReferralStats>('/api/referrals/me');
}
