import { Client, IMessage } from '@stomp/stompjs';
import { API_BASE_URL, getToken } from './client';
import { ChatMessage } from './types';

function toWebSocketUrl(httpUrl: string): string {
  return httpUrl.replace(/^http/, 'ws') + '/ws';
}

type MessageListener = (message: ChatMessage) => void;
type TypingListener = (event: { fromUserId: number; isTyping: boolean }) => void;
type ReadReceiptListener = (event: { readByUserId: number; messageIds: number[] }) => void;

/**
 * Thin wrapper around @stomp/stompjs for the app's single chat connection.
 * One socket is shared app-wide (see ChatContext) rather than one per screen,
 * so messages keep arriving for badge counts even while on other tabs.
 */
class ChatSocketManager {
  private client: Client | null = null;
  private listeners = new Set<MessageListener>();
  private typingListeners = new Set<TypingListener>();
  private readReceiptListeners = new Set<ReadReceiptListener>();
  private connected = false;

  async connect(): Promise<void> {
    if (this.client?.active) return;

    const token = await getToken();
    if (!token) throw new Error('Not authenticated');

    this.client = new Client({
      brokerURL: toWebSocketUrl(API_BASE_URL),
      connectHeaders: { Authorization: `Bearer ${token}` },
      reconnectDelay: 4000,
      heartbeatIncoming: 10000,
      heartbeatOutgoing: 10000,
    });

    this.client.onConnect = () => {
      this.connected = true;
      this.client?.subscribe('/user/queue/messages', (frame: IMessage) => {
        try {
          const message = JSON.parse(frame.body) as ChatMessage;
          this.listeners.forEach((listener) => listener(message));
        } catch {
          // ignore malformed frame
        }
      });
      this.client?.subscribe('/user/queue/typing', (frame: IMessage) => {
        try {
          const event = JSON.parse(frame.body) as { fromUserId: number; isTyping: boolean };
          this.typingListeners.forEach((listener) => listener(event));
        } catch {
          // ignore malformed frame
        }
      });
      this.client?.subscribe('/user/queue/read-receipts', (frame: IMessage) => {
        try {
          const event = JSON.parse(frame.body) as { readByUserId: number; messageIds: number[] };
          this.readReceiptListeners.forEach((listener) => listener(event));
        } catch {
          // ignore malformed frame
        }
      });
    };

    this.client.onDisconnect = () => {
      this.connected = false;
    };
    this.client.onStompError = () => {
      this.connected = false;
    };

    this.client.activate();
  }

  disconnect(): void {
    this.client?.deactivate();
    this.client = null;
    this.connected = false;
  }

  isConnected(): boolean {
    return this.connected;
  }

  onMessage(listener: MessageListener): () => void {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  onTyping(listener: TypingListener): () => void {
    this.typingListeners.add(listener);
    return () => this.typingListeners.delete(listener);
  }

  onReadReceipt(listener: ReadReceiptListener): () => void {
    this.readReceiptListeners.add(listener);
    return () => this.readReceiptListeners.delete(listener);
  }

  send(recipientId: number, content: string): void {
    if (!this.client?.active) {
      throw new Error('Chat is not connected yet');
    }
    this.client.publish({
      destination: '/app/chat.send',
      body: JSON.stringify({ recipientId, content }),
    });
  }

  /** Best-effort — typing indicators are cosmetic, so silently no-op if the socket isn't ready rather than throwing. */
  sendTyping(recipientId: number, isTyping: boolean): void {
    if (!this.client?.active) return;
    this.client.publish({
      destination: '/app/chat.typing',
      body: JSON.stringify({ recipientId, isTyping }),
    });
  }
}

export const chatSocket = new ChatSocketManager();
