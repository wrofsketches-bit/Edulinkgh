import { apiRequest } from './client';
import { TeacherStats, TeacherTrends } from './types';

export function getTeacherStats() {
  return apiRequest<TeacherStats>('/api/teachers/me/stats');
}

export function getTeacherTrends(days?: number) {
  const qs = days ? `?days=${days}` : '';
  return apiRequest<TeacherTrends>(`/api/teachers/me/trends${qs}`);
}
