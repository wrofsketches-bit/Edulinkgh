import { apiRequest } from './client';
import { PromoPreview } from './types';

export function previewPromoCode(code: string, sessionId: number) {
  return apiRequest<PromoPreview>('/api/promo-codes/preview', {
    method: 'POST',
    body: { code, sessionId },
  });
}
