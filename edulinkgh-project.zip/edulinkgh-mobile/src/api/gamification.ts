import { apiRequest } from './client';
import { StudentProgress } from './types';

export function getStudentProgress() {
  return apiRequest<StudentProgress>('/api/students/me/progress');
}
