import { apiRequest } from './client';
import { CreateSessionPayload, SessionItem } from './types';

export function getUpcomingSessions() {
  return apiRequest<SessionItem[]>('/api/sessions');
}

export function getSession(id: number) {
  return apiRequest<SessionItem>(`/api/sessions/${id}`);
}

export function getMyTeacherSessions() {
  return apiRequest<SessionItem[]>('/api/sessions/my/teacher');
}

export function getMyStudentSessions() {
  return apiRequest<SessionItem[]>('/api/sessions/my/student');
}

export function createSession(payload: CreateSessionPayload) {
  return apiRequest<SessionItem>('/api/sessions/create', {
    method: 'POST',
    body: payload,
  });
}

export function enrollInSession(id: number) {
  return apiRequest<SessionItem>(`/api/sessions/enroll/${id}`, { method: 'POST' });
}

export function startSession(id: number) {
  return apiRequest<SessionItem>(`/api/sessions/start/${id}`, { method: 'POST' });
}

export function endSession(id: number) {
  return apiRequest<SessionItem>(`/api/sessions/end/${id}`, { method: 'POST' });
}

export function cancelSession(id: number) {
  return apiRequest<{ message: string }>(`/api/sessions/${id}`, { method: 'DELETE' });
}
