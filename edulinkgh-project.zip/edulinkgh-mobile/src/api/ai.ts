import { apiRequest } from './client';
import { streamSse } from './sseStream';
import { HomeworkAnswer, HomeworkHistoryItem } from './types';

export function askHomeworkQuestion(question: string, subjectContext?: string) {
  return apiRequest<HomeworkAnswer>('/api/ai/homework', {
    method: 'POST',
    body: { question, subjectContext },
  });
}

/**
 * Streams the answer token-by-token. Returns a promise resolving to an
 * abort function the caller can use to cancel the stream early.
 */
export function askHomeworkQuestionStreaming(
  question: string,
  subjectContext: string | undefined,
  handlers: { onToken: (token: string) => void; onDone: () => void; onError: (message: string) => void }
): Promise<() => void> {
  return streamSse('/api/ai/homework/stream', { question, subjectContext }, handlers);
}

export function getHomeworkHistory() {
  return apiRequest<HomeworkHistoryItem[]>('/api/ai/homework/history');
}
