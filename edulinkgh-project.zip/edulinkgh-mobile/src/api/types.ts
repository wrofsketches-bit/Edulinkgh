export type Role = 'STUDENT' | 'TEACHER' | 'ADMIN';
export type AccountStatus = 'ACTIVE' | 'SUSPENDED' | 'PENDING_VERIFICATION';
export type SessionStatus = 'UPCOMING' | 'LIVE' | 'COMPLETED' | 'CANCELLED';

export interface AuthResponse {
  token: string;
  role: Role;
  userId: number;
  fullName: string;
  email: string;
  qualificationVerified: boolean;
}

export interface RegisterPayload {
  fullName: string;
  email: string;
  password: string;
  phone: string;
  role: Role;
  schoolName?: string;
  schoolLevel?: string;
  subject?: string;
  teachingLevel?: string;
  qualification?: string;
  referralCode?: string;
}

export interface UserProfile {
  id: number;
  fullName: string;
  email: string;
  phone: string;
  role: Role;
  schoolName?: string;
  schoolLevel?: string;
  subject?: string;
  teachingLevel?: string;
  qualification?: string;
  certificatePath?: string;
  profilePhotoPath?: string;
  bio?: string;
  status: AccountStatus;
  qualificationVerified: boolean;
  createdAt: string;
}

export interface TeacherSummary extends UserProfile {
  averageRating?: number;
  ratingCount?: number;
}

export interface Rating {
  id: number;
  stars: number;
  comment: string;
  studentName: string;
  createdAt: string;
}

export interface SessionItem {
  id: number;
  subject: string;
  description?: string;
  scheduledAt: string;
  durationMinutes: number;
  status: SessionStatus;
  teacher: UserProfile;
  enrolledStudents: UserProfile[];
  meetingLink?: string;
  feeGhc: number;
  createdAt: string;
}

export interface CreateSessionPayload {
  subject: string;
  description?: string;
  scheduledAt: string; // ISO
  durationMinutes: number;
  feeGhc: number;
  meetingLink?: string;
}

export interface Payment {
  id: number;
  amount: number;
  type: string;
  status: string;
  createdAt: string;
}

export type DayOfWeek = 'MONDAY' | 'TUESDAY' | 'WEDNESDAY' | 'THURSDAY' | 'FRIDAY' | 'SATURDAY' | 'SUNDAY';

export interface AvailabilityWindow {
  id: number;
  dayOfWeek: DayOfWeek;
  startTime: string; // "HH:mm:ss"
  endTime: string;
}

export interface HomeworkAnswer {
  answer: string;
  questionsRemainingToday: number;
}

export interface HomeworkHistoryItem {
  id: number;
  question: string;
  subjectContext?: string;
  answer: string;
  createdAt: string;
}

export interface QuizQuestion {
  question: string;
  options: string[];
  correctIndex: number;
  explanation: string;
}

export interface Quiz {
  id: number;
  topic: string;
  difficulty?: string;
  questions: QuizQuestion[];
  createdAt: string;
}

export interface ChatMessage {
  id: number;
  senderId: number;
  senderName: string;
  recipientId: number;
  content: string;
  attachmentUrl?: string | null;
  attachmentFileName?: string | null;
  attachmentMimeType?: string | null;
  read: boolean;
  createdAt: string;
}

export interface InboxEntry {
  otherUserId: number;
  otherUserName: string;
  lastMessage: string;
  lastMessageAt: string;
  unreadCount: number;
}

export interface TeacherMatch extends TeacherSummary {
  matchReason: string;
}

export interface LessonSummary {
  summary: string;
  disclaimer: string;
}

export interface Achievement {
  id: string;
  title: string;
  description: string;
  icon: string;
  unlocked: boolean;
}

export interface StudentProgress {
  completedSessionCount: number;
  currentStreakDays: number;
  longestStreakDays: number;
  achievements: Achievement[];
  newlyUnlocked: Achievement[];
}

export interface TeacherStats {
  totalSessionsCompleted: number;
  totalStudentsTaught: number;
  completionRate: number;
  averageRating: number | null;
  ratingCount: number;
  totalEarningsGhc: number;
}

export interface AnalyticsDataPoint {
  date: string;
  value: number;
}

export interface RevenueAnalytics {
  windowDays: number;
  totalRevenueGhc: number;
  series: AnalyticsDataPoint[];
}

export interface SessionVolumeAnalytics {
  windowDays: number;
  totalSessions: number;
  scheduledSeries: AnalyticsDataPoint[];
  completedSeries: AnalyticsDataPoint[];
  cancelledSeries: AnalyticsDataPoint[];
}

export interface TeacherTrends {
  windowDays: number;
  sessionsSeries: AnalyticsDataPoint[];
  earningsSeries: AnalyticsDataPoint[];
}

export interface SubjectBreakdownItem {
  subject: string;
  sessionCount: number;
}

export interface StudentInsights {
  windowDays: number;
  totalSessionsCompleted: number;
  totalMinutesLearned: number;
  distinctTeachersStudiedWith: number;
  subjectBreakdown: SubjectBreakdownItem[];
  sessionsSeries: AnalyticsDataPoint[];
}

export type SubscriptionPlan = 'FREE' | 'PLUS' | 'PRO';

export interface PlanDetails {
  plan: SubscriptionPlan;
  displayName: string;
  priceGhcPerMonth: number;
  aiHomeworkDailyLimit: number;
  aiQuizDailyLimit: number;
  aiMatchDailyLimit: number;
  priorityBookingMinutes: number;
}

export interface MySubscription {
  plan: SubscriptionPlan;
  expiresAt: string | null;
  planDetails: PlanDetails;
}

export interface PromoPreview {
  valid: boolean;
  originalAmount: number;
  discountAmount: number;
  finalAmount: number;
  error?: string;
}

export interface PlatformSettings {
  globalCommissionRatePercent: number;
}

export interface ReferralStats {
  referralCode: string;
  totalReferrals: number;
  progressTowardNextReward: number;
  referralsPerReward: number;
  rewardsEarned: number;
}

export interface VideoCallJoinInfo {
  roomId: string;
  roomCode: string;
  token: string;
  role: 'HOST' | 'GUEST';
}
