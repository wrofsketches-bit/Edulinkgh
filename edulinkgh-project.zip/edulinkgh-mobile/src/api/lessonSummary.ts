import { apiRequest } from './client';
import { LessonSummary } from './types';

export function getLessonSummary(sessionId: number) {
  return apiRequest<LessonSummary>(`/api/ai/lesson-summary/${sessionId}`);
}
