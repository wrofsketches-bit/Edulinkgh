import { apiRequest } from './client';
import { MySubscription, PlanDetails, SubscriptionPlan } from './types';

export function getPlans() {
  return apiRequest<Record<SubscriptionPlan, PlanDetails>>('/api/subscriptions/plans', { auth: false });
}

export function getMySubscription() {
  return apiRequest<MySubscription>('/api/subscriptions/me');
}

export interface InitiateSubscriptionResult {
  checkoutUrl: string;
  reference: string;
  providerReference: string;
  amount: number;
  plan: SubscriptionPlan;
}

export function subscribeToPlan(plan: SubscriptionPlan) {
  return apiRequest<InitiateSubscriptionResult>('/api/subscriptions/subscribe', {
    method: 'POST',
    body: { plan },
  });
}

export interface ConfirmSubscriptionResult {
  status: 'SUCCESS' | 'FAILED' | 'PENDING' | 'NOT_FOUND';
  message: string;
  plan?: SubscriptionPlan;
  expiresAt?: string;
}

export function confirmSubscription(providerReference: string) {
  return apiRequest<ConfirmSubscriptionResult>(`/api/subscriptions/confirm/${providerReference}`, { method: 'POST' });
}
