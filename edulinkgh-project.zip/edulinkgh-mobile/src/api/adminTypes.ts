export interface PlatformStats {
  totalStudents: number;
  totalTeachers: number;
  totalSessions: number;
  liveSessions: number;
  totalRevenue: number;
  pendingVerifications: number;
}

export interface AdminUserSummary {
  id: number;
  fullName: string;
  email: string;
  phone: string;
  role: string;
  status: string;
  schoolName?: string;
  schoolLevel?: string;
  subject?: string;
  teachingLevel?: string;
  qualification?: string;
  bio?: string;
  qualificationVerified: boolean;
  averageRating?: number;
}

export interface AdminSessionSummary {
  id: number;
  subject: string;
  status: string;
  scheduledAt: string;
  enrolledCount: number;
  teacher: string;
  feeGhc: number;
}
