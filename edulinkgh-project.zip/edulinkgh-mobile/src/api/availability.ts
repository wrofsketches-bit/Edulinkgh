import { apiRequest } from './client';
import { AvailabilityWindow, DayOfWeek } from './types';

export function getTeacherAvailability(teacherId: number) {
  return apiRequest<AvailabilityWindow[]>(`/api/teachers/${teacherId}/availability`, { auth: false });
}

export function addAvailabilityWindow(dayOfWeek: DayOfWeek, startTime: string, endTime: string) {
  return apiRequest<AvailabilityWindow>('/api/teachers/me/availability', {
    method: 'POST',
    body: { dayOfWeek, startTime, endTime },
  });
}

export function removeAvailabilityWindow(windowId: number) {
  return apiRequest<{ message: string }>(`/api/teachers/me/availability/${windowId}`, { method: 'DELETE' });
}
