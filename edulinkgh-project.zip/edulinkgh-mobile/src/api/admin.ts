import { apiRequest } from './client';
import { AdminSessionSummary, AdminUserSummary, PlatformStats } from './adminTypes';
import { PlatformSettings, RevenueAnalytics, SessionVolumeAnalytics } from './types';

export function getPlatformStats() {
  return apiRequest<PlatformStats>('/api/admin/stats');
}

export function getAllTeachers() {
  return apiRequest<AdminUserSummary[]>('/api/admin/teachers');
}

export function getAllStudents() {
  return apiRequest<AdminUserSummary[]>('/api/admin/students');
}

export function getAllSessions() {
  return apiRequest<AdminSessionSummary[]>('/api/admin/sessions');
}

export function verifyTeacher(id: number) {
  return apiRequest<{ message: string }>(`/api/admin/teachers/${id}/verify`, { method: 'POST' });
}

export function suspendUser(id: number) {
  return apiRequest<{ message: string }>(`/api/admin/users/${id}/suspend`, { method: 'POST' });
}

export function reactivateUser(id: number) {
  return apiRequest<{ message: string }>(`/api/admin/users/${id}/reactivate`, { method: 'POST' });
}

export function deleteUser(id: number) {
  return apiRequest<{ message: string }>(`/api/admin/users/${id}`, { method: 'DELETE' });
}

export function cancelSessionAsAdmin(id: number) {
  return apiRequest<{ message: string }>(`/api/admin/sessions/${id}`, { method: 'DELETE' });
}

export function payTeacher(id: number, amount: number, notes?: string) {
  return apiRequest<{ message: string; reference: string }>(`/api/admin/teachers/${id}/pay`, {
    method: 'POST',
    body: { amount, notes },
  });
}

export function getPlatformRevenue() {
  return apiRequest<{ totalRevenue: number }>('/api/admin/revenue');
}

export function reconcileStalePayments() {
  return apiRequest<{ resolved: number }>('/api/admin/payments/reconcile', { method: 'POST' });
}

export function getPlatformSettings() {
  return apiRequest<PlatformSettings>('/api/admin/settings');
}

export function setGlobalCommissionRate(percent: number) {
  return apiRequest<PlatformSettings>('/api/admin/settings/commission-rate', {
    method: 'POST',
    body: { percent },
  });
}

export function setTeacherCommissionOverride(teacherId: number, percent: number | null) {
  return apiRequest<{ teacherId: number; commissionRateOverride: number | null; effectiveRate: number }>(
    `/api/admin/teachers/${teacherId}/commission-rate`,
    { method: 'POST', body: { percent } }
  );
}

export function getRevenueAnalytics(days?: number) {
  const qs = days ? `?days=${days}` : '';
  return apiRequest<RevenueAnalytics>(`/api/admin/analytics/revenue${qs}`);
}

export function getSessionVolumeAnalytics(days?: number) {
  const qs = days ? `?days=${days}` : '';
  return apiRequest<SessionVolumeAnalytics>(`/api/admin/analytics/sessions${qs}`);
}
