import React, { createContext, useContext, useEffect, useState } from 'react';
import * as authApi from '../api/auth';
import { clearToken, getToken, setToken } from '../api/client';
import { RegisterPayload, Role } from '../api/types';
import { registerForPushNotifications, unregisterPushNotifications } from '../notifications/pushRegistration';

interface CurrentUser {
  userId: number;
  fullName: string;
  email: string;
  role: Role;
  qualificationVerified: boolean;
}

interface AuthContextValue {
  user: CurrentUser | null;
  isLoading: boolean; // true while restoring session on app launch
  isSubmitting: boolean; // true during a login/register call
  error: string | null;
  login: (email: string, password: string) => Promise<void>;
  register: (payload: RegisterPayload) => Promise<void>;
  logout: () => Promise<void>;
  clearError: () => void;
}

const AuthContext = createContext<AuthContextValue | undefined>(undefined);

const SESSION_KEY = 'edulinkgh:session';

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<CurrentUser | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    (async () => {
      try {
        const token = await getToken();
        const AsyncStorage = (await import('@react-native-async-storage/async-storage')).default;
        const stored = await AsyncStorage.getItem(SESSION_KEY);
        if (token && stored) {
          setUser(JSON.parse(stored));
        }
      } finally {
        setIsLoading(false);
      }
    })();
  }, []);

  async function persistSession(response: {
    token: string;
    userId: number;
    fullName: string;
    email: string;
    role: Role;
    qualificationVerified: boolean;
  }) {
    await setToken(response.token);
    const currentUser: CurrentUser = {
      userId: response.userId,
      fullName: response.fullName,
      email: response.email,
      role: response.role,
      qualificationVerified: response.qualificationVerified,
    };
    const AsyncStorage = (await import('@react-native-async-storage/async-storage')).default;
    await AsyncStorage.setItem(SESSION_KEY, JSON.stringify(currentUser));
    setUser(currentUser);

    // Best-effort — don't block login/register on push permission prompts or failures.
    registerForPushNotifications().catch(() => {});
  }

  const login = async (email: string, password: string) => {
    setIsSubmitting(true);
    setError(null);
    try {
      const response = await authApi.login(email, password);
      await persistSession(response);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Login failed');
      throw err;
    } finally {
      setIsSubmitting(false);
    }
  };

  const register = async (payload: RegisterPayload) => {
    setIsSubmitting(true);
    setError(null);
    try {
      const response = await authApi.register(payload);
      await persistSession(response);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Registration failed');
      throw err;
    } finally {
      setIsSubmitting(false);
    }
  };

  const logout = async () => {
    await unregisterPushNotifications();
    await clearToken();
    const AsyncStorage = (await import('@react-native-async-storage/async-storage')).default;
    await AsyncStorage.removeItem(SESSION_KEY);
    setUser(null);
  };

  const clearError = () => setError(null);

  return (
    <AuthContext.Provider
      value={{ user, isLoading, isSubmitting, error, login, register, logout, clearError }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export function useAuth(): AuthContextValue {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
}
