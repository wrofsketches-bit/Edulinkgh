import React, { createContext, useContext, useEffect, useRef, useState } from 'react';
import { chatSocket } from '../api/chatSocket';
import { getInbox } from '../api/chat';
import { ChatMessage, InboxEntry } from '../api/types';
import { useAuth } from './AuthContext';

interface ChatContextValue {
  inbox: InboxEntry[];
  totalUnread: number;
  refreshInbox: () => Promise<void>;
  subscribeToMessages: (listener: (message: ChatMessage) => void) => () => void;
}

const ChatContext = createContext<ChatContextValue | undefined>(undefined);

export const ChatProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user } = useAuth();
  const [inbox, setInbox] = useState<InboxEntry[]>([]);
  const listenersRef = useRef(new Set<(message: ChatMessage) => void>());

  const refreshInbox = async () => {
    try {
      const result = await getInbox();
      setInbox(result);
    } catch {
      // inbox refresh failures are non-fatal; the badge just stays stale
    }
  };

  useEffect(() => {
    if (!user) {
      chatSocket.disconnect();
      setInbox([]);
      return;
    }

    chatSocket.connect().catch(() => {
      // connection errors are surfaced implicitly (chat screens will show
      // "not connected" state); no need to crash the app over a dropped socket
    });
    refreshInbox();

    const unsubscribe = chatSocket.onMessage((message) => {
      listenersRef.current.forEach((listener) => listener(message));
      refreshInbox();
    });

    return () => {
      unsubscribe();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user?.userId]);

  const subscribeToMessages = (listener: (message: ChatMessage) => void) => {
    listenersRef.current.add(listener);
    return () => listenersRef.current.delete(listener);
  };

  const totalUnread = inbox.reduce((sum, entry) => sum + entry.unreadCount, 0);

  return (
    <ChatContext.Provider value={{ inbox, totalUnread, refreshInbox, subscribeToMessages }}>
      {children}
    </ChatContext.Provider>
  );
};

export function useChat(): ChatContextValue {
  const ctx = useContext(ChatContext);
  if (!ctx) throw new Error('useChat must be used within ChatProvider');
  return ctx;
}
