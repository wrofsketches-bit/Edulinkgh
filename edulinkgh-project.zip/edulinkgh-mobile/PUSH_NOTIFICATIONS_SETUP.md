# Push Notifications Setup (Firebase Cloud Messaging)

This app is wired for FCM push notifications, but needs your own Firebase
project before it will actually deliver anything. Nothing will break if you
skip this — chat still works in real time over WebSocket while the app is
open — but backgrounded users won't get a system notification for new
messages until this is done.

## 1. Create a Firebase project

Go to https://console.firebase.google.com, create a project, then add an
Android app with package name `com.edulinkgh.app` (must match `app.json`'s
`android.package`). Download the generated `google-services.json` and place
it at the root of this project (`edulinkgh-mobile/google-services.json`),
replacing nothing — the path is already referenced in `app.json`.

For iOS, add an iOS app with bundle id `com.edulinkgh.app`, download
`GoogleService-Info.plist`, and add it similarly (add
`"googleServicesFile": "./GoogleService-Info.plist"` under `expo.ios` in
`app.json`) — iOS push also requires an Apple Developer account and APNs
key configured in the Firebase console under Project Settings > Cloud
Messaging.

## 2. Backend service account

In the Firebase console: Project Settings > Service Accounts > Generate new
private key. Save the downloaded JSON as:

```
edulinkgh-backend/src/main/resources/firebase-service-account.json
```

This file is gitignored — never commit it. Then in
`edulinkgh-backend/src/main/resources/application.properties`, set:

```
app.firebase.enabled=true
```

Restart the backend. If the file is missing or this flag is false, the
backend silently skips sending pushes (logged as a warning) rather than
crashing — so you can develop everything else first and turn this on later.

## 3. You need a development build, not Expo Go

Since Expo SDK 53, Expo Go on Android can no longer receive real FCM push
notifications — this is an Expo Go limitation, not something in this
codebase. To actually test push delivery you need either:

- `npx expo run:android` / `npx expo run:ios` (builds a real native app on
  a connected device/emulator), or
- an EAS Build (`eas build`) for a distributable dev/production build.

Everything else in the app (auth, booking, in-app real-time chat over
WebSocket, etc.) works fine in plain Expo Go — only the push notification
piece needs a real build.
