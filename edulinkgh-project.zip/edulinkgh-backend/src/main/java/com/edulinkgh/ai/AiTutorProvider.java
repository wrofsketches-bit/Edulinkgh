package com.edulinkgh.ai;

/**
 * Abstraction over "whichever LLM actually answers". Only implementation
 * today is OpenAiTutorProvider. If Anthropic or another provider is ever
 * added instead/alongside, implement this same interface and switch via
 * config — nothing in AiTutorService or the controller needs to change.
 */
public interface AiTutorProvider {

    /**
     * Asks the model to help with a homework question. Implementations are
     * responsible for the actual system prompt / pedagogy framing — see
     * OpenAiTutorProvider for the "explain, don't just hand over the
     * answer" instruction, which is the whole point of this feature.
     */
    String askHomeworkQuestion(String studentQuestion, String subjectContext);

    /**
     * Streaming variant of askHomeworkQuestion. Calls onToken for each text
     * fragment as it arrives, then onComplete with the full assembled answer
     * once the stream ends (so callers that need to persist/rate-limit on
     * the final text don't have to reassemble it themselves). onError fires
     * if the request fails partway through — callers should treat whatever
     * was already streamed as incomplete/unreliable in that case.
     *
     * This call BLOCKS the calling thread for the duration of the stream —
     * callers must run it on a background thread (see AiTutorController),
     * never directly on a request-handling thread that also needs to stay
     * responsive.
     */
    void askHomeworkQuestionStreaming(String studentQuestion, String subjectContext,
                                       java.util.function.Consumer<String> onToken,
                                       java.util.function.Consumer<String> onComplete,
                                       java.util.function.Consumer<Throwable> onError);

    /**
     * Generates a multiple-choice quiz as raw JSON text matching the shape:
     * { "questions": [ { "question": "...", "options": ["...","...","...","..."],
     *   "correctIndex": 0, "explanation": "..." }, ... ] }
     * Callers (AiQuizService) are responsible for parsing/validating this —
     * implementations should request JSON mode from the provider where
     * available, but must not be trusted to always return perfectly
     * schema-conformant output without validation downstream.
     */
    String generateQuiz(String topic, String difficulty, int questionCount);

    /**
     * Given a student's plain-language request and a list of candidate
     * teachers (already fetched from the database — the model NEVER invents
     * teachers, only ranks/selects from what's given), returns raw JSON:
     * { "matches": [ { "teacherId": 5, "reason": "..." }, ... ] }
     * ordered best-match first. Callers must validate that every returned
     * teacherId actually exists in the candidate list before trusting it.
     */
    String matchTeachers(String studentRequest, String candidatesDescription);

    /**
     * Generates a general topic-overview summary for a session's subject and
     * description. IMPORTANT: this is NOT a record of what was actually
     * taught in that specific class — there's no transcript/recording
     * capture in this system yet, so this only has the session's stated
     * subject/description to work from. It's framed to the user accordingly
     * (see AiLessonSummaryService) — don't let this drift into implying it
     * knows what happened in the room.
     */
    String generateLessonSummary(String subject, String description);

    /** Whether this provider is actually configured and usable right now (e.g. has an API key). */
    boolean isAvailable();
}
