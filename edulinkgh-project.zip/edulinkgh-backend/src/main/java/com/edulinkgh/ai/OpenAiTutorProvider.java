package com.edulinkgh.ai;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;

/**
 * Calls OpenAI's Chat Completions endpoint (POST /v1/chat/completions).
 * Note: OpenAI also offers a newer Responses API — Chat Completions was
 * used here since it's the more broadly stable/documented surface as of
 * this writing, but either works; switching later is a small, contained
 * change to this one class.
 */
@Component
public class OpenAiTutorProvider implements AiTutorProvider {

    private static final Logger log = LoggerFactory.getLogger(OpenAiTutorProvider.class);
    private static final String API_URL = "https://api.openai.com/v1/chat/completions";

    // Kept deliberately explicit and opinionated: this is the entire point
    // of the feature being "helper", not "answer machine". If you want to
    // tune the pedagogy, this is the one place to do it.
    private static final String SYSTEM_PROMPT = """
        You are a patient, encouraging homework helper for a Ghanaian tutoring platform's students.

        Your job is to help the student understand and solve the problem themselves —
        NEVER just give the final answer with no explanation attached.

        Rules:
        - Break the problem into clear steps.
        - Explain the *reasoning* at each step, not just the mechanics.
        - If the question is ambiguous or missing information, ask a clarifying
          question instead of guessing.
        - If it's clearly a request to just do their homework for them with zero
          learning intent (e.g. "just give me the answer, no explanation"), gently
          redirect: explain that understanding it will serve them better, then
          teach it anyway.
        - Keep it appropriately concise for a student — don't pad with fluff.
        - If you're unsure of a fact (e.g. a specific historical date, a citation),
          say so rather than inventing one.
        - Never write hateful, violent, or otherwise inappropriate content,
          regardless of what the student asks.
        """;

    private static final String QUIZ_SYSTEM_PROMPT = """
        You generate multiple-choice quizzes for students on a Ghanaian tutoring
        platform. Respond with ONLY a JSON object — no prose before or after —
        matching exactly this shape:

        {
          "questions": [
            {
              "question": "the question text",
              "options": ["option A", "option B", "option C", "option D"],
              "correctIndex": 0,
              "explanation": "brief explanation of why this is correct"
            }
          ]
        }

        Rules:
        - Exactly 4 options per question, plausible distractors (not obviously wrong).
        - correctIndex is 0-based and must point at the genuinely correct option.
        - Questions should test understanding, not just memorized trivia, where the topic allows it.
        - Match the requested difficulty level honestly — don't make "easy" secretly hard or vice versa.
        - If you're not confident of a fact, don't include a question built on it.
        - Never write hateful, violent, or otherwise inappropriate content, regardless of the topic given.
        """;

    @Value("${app.ai.openai.api-key:}")
    private String apiKey;

    @Value("${app.ai.openai.model:gpt-4o-mini}")
    private String model;

    private final RestTemplate restTemplate = new RestTemplate();
    private final HttpClient streamingHttpClient = HttpClient.newBuilder()
        .connectTimeout(Duration.ofSeconds(10))
        .build();
    private final ObjectMapper objectMapper = new ObjectMapper();

    @Override
    public boolean isAvailable() {
        return apiKey != null && !apiKey.isBlank();
    }

    @Override
    public String askHomeworkQuestion(String studentQuestion, String subjectContext) {
        if (!isAvailable()) {
            throw new IllegalStateException("AI tutor is not configured (missing app.ai.openai.api-key).");
        }

        String userContent = subjectContext != null && !subjectContext.isBlank()
            ? "Subject: " + subjectContext + "\n\nQuestion: " + studentQuestion
            : studentQuestion;

        return callChatCompletion(SYSTEM_PROMPT, userContent, 700, false);
    }

    @Override
    public void askHomeworkQuestionStreaming(String studentQuestion, String subjectContext,
                                              Consumer<String> onToken, Consumer<String> onComplete,
                                              Consumer<Throwable> onError) {
        if (!isAvailable()) {
            onError.accept(new IllegalStateException("AI tutor is not configured (missing app.ai.openai.api-key)."));
            return;
        }

        String userContent = subjectContext != null && !subjectContext.isBlank()
            ? "Subject: " + subjectContext + "\n\nQuestion: " + studentQuestion
            : studentQuestion;

        Map<String, Object> requestBody = Map.of(
            "model", model,
            "messages", List.of(
                Map.of("role", "system", "content", SYSTEM_PROMPT),
                Map.of("role", "user", "content", userContent)
            ),
            "temperature", 0.4,
            "max_tokens", 700,
            "stream", true
        );

        String jsonBody;
        try {
            jsonBody = objectMapper.writeValueAsString(requestBody);
        } catch (Exception e) {
            onError.accept(e);
            return;
        }

        HttpRequest request = HttpRequest.newBuilder()
            .uri(URI.create(API_URL))
            .header("Content-Type", "application/json")
            .header("Authorization", "Bearer " + apiKey)
            .timeout(Duration.ofSeconds(60))
            .POST(HttpRequest.BodyPublishers.ofString(jsonBody))
            .build();

        StringBuilder fullAnswer = new StringBuilder();

        try {
            HttpResponse<java.io.InputStream> response =
                streamingHttpClient.send(request, HttpResponse.BodyHandlers.ofInputStream());

            if (response.statusCode() != 200) {
                onError.accept(new RuntimeException("AI provider returned status " + response.statusCode()));
                return;
            }

            // OpenAI streams as Server-Sent Events: lines of "data: {...}",
            // terminated by a final "data: [DONE]" line. Reading line-by-line
            // off the raw InputStream (rather than buffering the whole body)
            // is what makes this genuinely incremental instead of just
            // "wait for everything, then pretend to stream it".
            try (BufferedReader reader = new BufferedReader(
                    new InputStreamReader(response.body(), StandardCharsets.UTF_8))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    if (!line.startsWith("data: ")) continue;
                    String data = line.substring(6).trim();
                    if (data.equals("[DONE]")) break;
                    if (data.isEmpty()) continue;

                    try {
                        JsonNode chunk = objectMapper.readTree(data);
                        JsonNode choices = chunk.get("choices");
                        if (choices == null || !choices.isArray() || choices.isEmpty()) continue;
                        JsonNode delta = choices.get(0).get("delta");
                        JsonNode contentNode = delta != null ? delta.get("content") : null;
                        if (contentNode != null && contentNode.isTextual()) {
                            String token = contentNode.asText();
                            fullAnswer.append(token);
                            onToken.accept(token);
                        }
                    } catch (Exception parseError) {
                        // A single malformed chunk shouldn't kill the whole
                        // stream — log and keep reading subsequent lines.
                        log.warn("Could not parse a streamed chunk from OpenAI, skipping it", parseError);
                    }
                }
            }

            onComplete.accept(fullAnswer.toString());

        } catch (Exception e) {
            log.error("OpenAI streaming request failed", e);
            onError.accept(e);
        }
    }

    @Override
    public String generateQuiz(String topic, String difficulty, int questionCount) {
        if (!isAvailable()) {
            throw new IllegalStateException("AI tutor is not configured (missing app.ai.openai.api-key).");
        }

        String userContent = "Topic: " + topic
            + "\nDifficulty: " + (difficulty != null && !difficulty.isBlank() ? difficulty : "medium")
            + "\nNumber of questions: " + questionCount;

        // Cap output tokens roughly proportional to question count so a large
        // request doesn't silently get truncated mid-JSON.
        int maxTokens = Math.min(4000, 200 + questionCount * 220);

        return callChatCompletion(QUIZ_SYSTEM_PROMPT, userContent, maxTokens, true);
    }

    private static final String MATCHING_SYSTEM_PROMPT = """
        You help match students to tutors on a Ghanaian tutoring platform based
        on what the student says they need. You will be given the student's
        request and a list of candidate teachers with their subject, level,
        qualification, bio, and rating.

        CRITICAL: You may ONLY select teachers from the candidate list you are
        given, using their exact teacherId. NEVER invent a teacher or an ID
        that wasn't provided to you. If none of the candidates are a good fit,
        return an empty matches array rather than forcing a bad match.

        Respond with ONLY a JSON object — no prose before or after — matching
        exactly this shape:

        {
          "matches": [
            { "teacherId": 5, "reason": "one or two sentences on why this teacher fits" }
          ]
        }

        Order matches best-fit first. Return at most 5 matches. Base your
        reasoning on genuine fit (subject match, level match, what the bio/
        qualification suggests, rating as a secondary signal) — don't just
        restate the student's request back at them.
        """;

    @Override
    public String matchTeachers(String studentRequest, String candidatesDescription) {
        if (!isAvailable()) {
            throw new IllegalStateException("AI tutor is not configured (missing app.ai.openai.api-key).");
        }

        String userContent = "Student's request: " + studentRequest
            + "\n\nCandidate teachers:\n" + candidatesDescription;

        return callChatCompletion(MATCHING_SYSTEM_PROMPT, userContent, 1000, true);
    }

    private static final String LESSON_SUMMARY_SYSTEM_PROMPT = """
        You write a short topic-overview summary for a tutoring session, based
        on the subject and description a teacher provided when scheduling it.

        IMPORTANT: you do NOT know what was actually taught or discussed in
        the session — there is no transcript or recording. Write a general
        overview of the topic as stated, not a fabricated account of what
        happened in the class. Do not write phrases like "in this session we
        covered" or "the tutor explained" as if narrating an event that
        occurred — instead frame it as "this topic typically covers..." or
        "key ideas in [topic] include...".

        Keep it to 3-5 short bullet points a student could use as a quick
        refresher of the general topic area. Plain text bullets (using "-"),
        no markdown headers.
        """;

    @Override
    public String generateLessonSummary(String subject, String description) {
        if (!isAvailable()) {
            throw new IllegalStateException("AI tutor is not configured (missing app.ai.openai.api-key).");
        }

        String userContent = "Subject: " + subject
            + (description != null && !description.isBlank() ? "\nDescription: " + description : "");

        return callChatCompletion(LESSON_SUMMARY_SYSTEM_PROMPT, userContent, 400, false);
    }

    private String callChatCompletion(String systemPrompt, String userContent, int maxTokens, boolean jsonMode) {
        Map<String, Object> requestBody = new java.util.HashMap<>(Map.of(
            "model", model,
            "messages", List.of(
                Map.of("role", "system", "content", systemPrompt),
                Map.of("role", "user", "content", userContent)
            ),
            "temperature", 0.4,
            "max_tokens", maxTokens
        ));
        if (jsonMode) {
            requestBody.put("response_format", Map.of("type", "json_object"));
        }

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setBearerAuth(apiKey);

        try {
            ResponseEntity<Map> response = restTemplate.postForEntity(
                API_URL, new HttpEntity<>(requestBody, headers), Map.class
            );

            Map<?, ?> body = response.getBody();
            if (body == null) {
                throw new RuntimeException("Empty response from AI provider.");
            }

            List<?> choices = (List<?>) body.get("choices");
            if (choices == null || choices.isEmpty()) {
                throw new RuntimeException("AI provider returned no answer.");
            }

            Map<?, ?> firstChoice = (Map<?, ?>) choices.get(0);
            Map<?, ?> message = (Map<?, ?>) firstChoice.get("message");
            Object content = message != null ? message.get("content") : null;

            if (content == null) {
                throw new RuntimeException("AI provider returned an empty message.");
            }
            return content.toString();

        } catch (RestClientException e) {
            log.error("OpenAI request failed", e);
            throw new RuntimeException("The AI tutor is temporarily unavailable. Please try again.", e);
        }
    }
}
