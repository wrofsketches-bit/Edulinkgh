package com.edulinkgh.gamification;

import java.util.List;
import java.util.function.Predicate;

/**
 * Static catalog of achievements. Each has a stable id (used as the DB key
 * in StudentAchievement — never rename an existing id, only add new ones,
 * or students will lose earned achievements silently) and a predicate over
 * StudentActivityStats that decides whether it's earned.
 */
public class AchievementCatalog {

    public record Achievement(String id, String title, String description, String icon, Predicate<StudentActivityStats> criteria) {}

    public static final List<Achievement> ALL = List.of(
        new Achievement(
            "first_session",
            "First Steps",
            "Complete your first session",
            "🎉",
            stats -> stats.completedSessionCount() >= 1
        ),
        new Achievement(
            "five_sessions",
            "Getting Into It",
            "Complete 5 sessions",
            "📚",
            stats -> stats.completedSessionCount() >= 5
        ),
        new Achievement(
            "twenty_sessions",
            "Committed Learner",
            "Complete 20 sessions",
            "🏆",
            stats -> stats.completedSessionCount() >= 20
        ),
        new Achievement(
            "fifty_sessions",
            "Scholar",
            "Complete 50 sessions",
            "🎓",
            stats -> stats.completedSessionCount() >= 50
        ),
        new Achievement(
            "three_day_streak",
            "Warming Up",
            "Reach a 3-day streak",
            "🔥",
            stats -> stats.currentStreakDays() >= 3 || stats.longestStreakDays() >= 3
        ),
        new Achievement(
            "seven_day_streak",
            "On a Roll",
            "Reach a 7-day streak",
            "🔥",
            stats -> stats.currentStreakDays() >= 7 || stats.longestStreakDays() >= 7
        ),
        new Achievement(
            "three_subjects",
            "Well Rounded",
            "Complete sessions in 3 different subjects",
            "🌟",
            stats -> stats.distinctSubjectCount() >= 3
        ),
        new Achievement(
            "first_review",
            "Giving Back",
            "Leave your first teacher review",
            "⭐",
            stats -> stats.ratingsGivenCount() >= 1
        )
    );
}
