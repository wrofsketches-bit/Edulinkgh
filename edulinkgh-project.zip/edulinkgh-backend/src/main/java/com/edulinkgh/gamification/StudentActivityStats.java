package com.edulinkgh.gamification;

public record StudentActivityStats(
    int completedSessionCount,
    int currentStreakDays,
    int longestStreakDays,
    int distinctSubjectCount,
    long ratingsGivenCount
) {}
