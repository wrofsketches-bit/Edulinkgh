package com.edulinkgh.video;

/**
 * Abstraction over "whichever video provider actually hosts the call".
 * Only implementation today is MockVideoCallProvider. When 100ms
 * credentials are available, add a HundredMsVideoCallProvider implementing
 * this same interface and switch it in — see VIDEO_INTEGRATION.md.
 *
 * Deliberately backend-owned, not client-owned: 100ms's own docs are
 * explicit that auth tokens must be generated server-side in production,
 * never embedded/hardcoded in the client — same reasoning already applied
 * to PaymentProvider (Paystack) and AiTutorProvider (OpenAI) in this
 * codebase.
 */
public interface VideoCallProvider {

    /**
     * Creates (or looks up, if createRoom is called again for the same
     * externalId) a call room for a session. externalId should be a stable
     * identifier derived from the session (e.g. "session-42") so repeated
     * calls are idempotent rather than creating duplicate rooms.
     */
    RoomResult createRoom(String externalId, String roomName);

    /**
     * Generates a short-lived auth token for a specific user to join a
     * specific room. Never reused across users or cached beyond a single
     * join — request a fresh one each time a user actually joins.
     */
    String generateJoinToken(String roomId, String userId, String userName, Role role);

    /** Whether this provider is actually configured and usable right now (e.g. has an API key). */
    boolean isAvailable();

    enum Role { HOST, GUEST } // teacher gets HOST (can end the call for everyone), student gets GUEST

    record RoomResult(String roomId, String roomCode) {}
}
