package com.edulinkgh.video;

import org.springframework.stereotype.Component;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Stand-in for a real provider (100ms) until credentials exist. Rooms are
 * tracked in memory only — fine for dev/testing, NOT durable across a
 * restart; a real provider has no need for this at all since the provider
 * itself is the source of truth.
 */
@Component
public class MockVideoCallProvider implements VideoCallProvider {

    private final Map<String, RoomResult> roomsByExternalId = new ConcurrentHashMap<>();

    @Override
    public RoomResult createRoom(String externalId, String roomName) {
        return roomsByExternalId.computeIfAbsent(externalId, id -> {
            String roomId = "mock-room-" + UUID.randomUUID().toString().substring(0, 8);
            String roomCode = "MOCK-" + UUID.randomUUID().toString().substring(0, 6).toUpperCase();
            return new RoomResult(roomId, roomCode);
        });
    }

    @Override
    public String generateJoinToken(String roomId, String userId, String userName, Role role) {
        // A real token would be a signed JWT from the provider; the mock
        // just returns an opaque placeholder — the mobile client's mock
        // video screen doesn't attempt to actually parse or use this.
        return "mock-token-" + UUID.randomUUID();
    }

    @Override
    public boolean isAvailable() {
        return true;
    }
}
