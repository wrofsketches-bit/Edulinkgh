package com.edulinkgh.controllers;

import com.edulinkgh.models.User;
import com.edulinkgh.services.AiTutorService;
import com.edulinkgh.services.UserService;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@RestController
@RequestMapping("/api/ai")
public class AiTutorController {

    private final AiTutorService aiTutorService;
    private final UserService userService;

    // A small dedicated pool for streaming AI requests — kept separate from
    // Spring MVC's own request-handling threads (which return immediately
    // once the SseEmitter is created; the actual streaming work happens
    // here instead, per Spring's documented SseEmitter pattern).
    private final ExecutorService streamingExecutor = Executors.newFixedThreadPool(4);

    public AiTutorController(AiTutorService aiTutorService, UserService userService) {
        this.aiTutorService = aiTutorService;
        this.userService = userService;
    }

    public record AskQuestionRequest(String question, String subjectContext) {}

    @PostMapping("/homework")
    public ResponseEntity<?> askHomeworkQuestion(@RequestBody AskQuestionRequest request, Authentication auth) {
        User user = userService.findByEmail(auth.getName());
        if (user.getRole() != User.Role.STUDENT) {
            return ResponseEntity.status(403).body(Map.of("error", "The homework helper is available to students only."));
        }
        try {
            return ResponseEntity.ok(aiTutorService.askQuestion(auth.getName(), request.question(), request.subjectContext()));
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    /**
     * Streaming variant of /homework. Emits SSE events as the answer is
     * generated token-by-token:
     *   event: token    — data is one text fragment (send these in order,
     *                      concatenated, to build up the answer as it streams)
     *   event: done      — signals successful completion, no further events follow
     *   event: error     — signals failure; data is a user-facing message
     *
     * The response never uses a plain HTTP error status once the stream has
     * started (SSE doesn't support that mid-stream) — validation failures
     * that happen before any token is sent still arrive as an "error" event,
     * not an HTTP 4xx, so the client should always listen for both event
     * types rather than checking the HTTP status.
     */
    @PostMapping(value = "/homework/stream", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
    public SseEmitter askHomeworkQuestionStreaming(@RequestBody AskQuestionRequest request, Authentication auth) {
        SseEmitter emitter = new SseEmitter(120_000L); // 2 minute timeout — generous for a long answer

        User user = userService.findByEmail(auth.getName());
        if (user.getRole() != User.Role.STUDENT) {
            streamingExecutor.execute(() -> completeWithError(emitter, "The homework helper is available to students only."));
            return emitter;
        }

        streamingExecutor.execute(() -> {
            aiTutorService.askQuestionStreaming(
                auth.getName(), request.question(), request.subjectContext(),
                token -> {
                    try {
                        emitter.send(SseEmitter.event().name("token").data(token));
                    } catch (Exception e) {
                        emitter.completeWithError(e);
                    }
                },
                () -> {
                    try {
                        emitter.send(SseEmitter.event().name("done").data(""));
                        emitter.complete();
                    } catch (Exception e) {
                        emitter.completeWithError(e);
                    }
                },
                error -> completeWithError(emitter, error.getMessage() != null ? error.getMessage() : "Something went wrong.")
            );
        });

        return emitter;
    }

    private void completeWithError(SseEmitter emitter, String message) {
        try {
            emitter.send(SseEmitter.event().name("error").data(message));
            emitter.complete();
        } catch (Exception e) {
            emitter.completeWithError(e);
        }
    }

    @GetMapping("/homework/history")
    public ResponseEntity<List<Map<String, Object>>> getHistory(Authentication auth) {
        return ResponseEntity.ok(aiTutorService.getHistory(auth.getName()));
    }
}
