package com.edulinkgh.controllers;

import com.edulinkgh.services.RatingService;
import com.edulinkgh.services.UserService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/teachers")
public class TeacherController {

    private final UserService   userService;
    private final RatingService ratingService;

    public TeacherController(UserService userService, RatingService ratingService) {
        this.userService   = userService;
        this.ratingService = ratingService;
    }

    @GetMapping
    public ResponseEntity<?> getTeachers(
        @RequestParam(required = false) String search,
        @RequestParam(required = false) String subject,
        @RequestParam(required = false) String level,
        @RequestParam(required = false) Double minRating
    ) {
        return ResponseEntity.ok(userService.getAllTeachers(search, subject, level, minRating));
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> getTeacher(@PathVariable Long id) {
        try {
            return ResponseEntity.ok(userService.getTeacher(id));
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    @GetMapping("/{id}/ratings")
    public ResponseEntity<?> getTeacherRatings(@PathVariable Long id) {
        return ResponseEntity.ok(ratingService.getTeacherRatings(id));
    }

    @PostMapping("/{id}/rate")
    public ResponseEntity<?> rateTeacher(
        @PathVariable Long id,
        @AuthenticationPrincipal UserDetails userDetails,
        @RequestBody Map<String, Object> body
    ) {
        try {
            int stars      = (Integer) body.get("stars");
            String comment = (String)  body.getOrDefault("comment", "");
            return ResponseEntity.ok(
                ratingService.rateTeacher(userDetails.getUsername(), id, stars, comment));
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    @GetMapping("/{id}/rating-status")
    public ResponseEntity<?> getRatingStatus(
        @PathVariable Long id,
        @AuthenticationPrincipal UserDetails userDetails
    ) {
        return ResponseEntity.ok(ratingService.getRatingStatus(userDetails.getUsername(), id));
    }
}
