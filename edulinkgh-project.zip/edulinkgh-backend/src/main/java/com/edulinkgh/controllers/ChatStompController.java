package com.edulinkgh.controllers;

import com.edulinkgh.repositories.UserRepository;
import com.edulinkgh.services.ChatService;
import com.edulinkgh.services.UserService;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;

import java.util.Map;

/**
 * STOMP destinations (client sends to "/app/chat.send"):
 *   SUBSCRIBE /user/queue/messages   -> where incoming messages arrive
 *   SEND      /app/chat.send         -> { "recipientId": 5, "content": "hi" }
 *   SUBSCRIBE /user/queue/typing     -> where typing indicator events arrive
 *   SEND      /app/chat.typing       -> { "recipientId": 5, "isTyping": true }
 *
 * REST endpoints for history/inbox live in ChatRestController since a plain
 * GET is simpler than a STOMP round-trip for one-off fetches.
 */
@Controller
public class ChatStompController {

    private final ChatService chatService;
    private final UserService userService;
    private final UserRepository userRepository;
    private final SimpMessagingTemplate messagingTemplate;

    public ChatStompController(ChatService chatService, UserService userService,
                                UserRepository userRepository, SimpMessagingTemplate messagingTemplate) {
        this.chatService = chatService;
        this.userService = userService;
        this.userRepository = userRepository;
        this.messagingTemplate = messagingTemplate;
    }

    @MessageMapping("/chat.send")
    public void send(@Payload ChatSendRequest request, @AuthenticationPrincipal UserDetails principal) {
        if (principal == null) return; // unauthenticated frame; silently drop
        chatService.sendMessage(principal.getUsername(), request.recipientId(), request.content());
    }

    /**
     * Purely ephemeral — never persisted, no history, no delivery guarantee.
     * If the recipient isn't currently connected, the event is just dropped,
     * which is the correct behavior for a typing indicator (there's nothing
     * meaningful to "catch up on" later).
     */
    @MessageMapping("/chat.typing")
    public void typing(@Payload TypingRequest request, @AuthenticationPrincipal UserDetails principal) {
        if (principal == null) return;

        var sender = userService.findByEmail(principal.getUsername());
        var recipient = userRepository.findById(request.recipientId()).orElse(null);
        if (recipient == null) return; // unknown recipient — silently drop

        messagingTemplate.convertAndSendToUser(
            recipient.getEmail(),
            "/queue/typing",
            Map.of("fromUserId", sender.getId(), "isTyping", request.isTyping())
        );
    }

    public record ChatSendRequest(Long recipientId, String content) {}
    public record TypingRequest(Long recipientId, boolean isTyping) {}
}
