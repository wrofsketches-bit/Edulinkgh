package com.edulinkgh.controllers;

import com.edulinkgh.services.AiLessonSummaryService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
@RequestMapping("/api/ai/lesson-summary")
public class AiLessonSummaryController {

    private final AiLessonSummaryService summaryService;

    public AiLessonSummaryController(AiLessonSummaryService summaryService) {
        this.summaryService = summaryService;
    }

    @GetMapping("/{sessionId}")
    public ResponseEntity<?> getSummary(@PathVariable Long sessionId, Authentication auth) {
        try {
            return ResponseEntity.ok(summaryService.getOrGenerateSummary(sessionId, auth.getName()));
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }
}
