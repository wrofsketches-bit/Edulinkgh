package com.edulinkgh.controllers;

import com.edulinkgh.services.SubscriptionService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/subscriptions")
public class SubscriptionController {

    private final SubscriptionService subscriptionService;

    public SubscriptionController(SubscriptionService subscriptionService) {
        this.subscriptionService = subscriptionService;
    }

    /** Public — anyone (even logged out) should be able to see pricing before signing up. */
    @GetMapping("/plans")
    public ResponseEntity<?> getPlans() {
        return ResponseEntity.ok(subscriptionService.getPlans());
    }

    @GetMapping("/me")
    public ResponseEntity<?> getMySubscription(Authentication auth) {
        return ResponseEntity.ok(subscriptionService.getMySubscription(auth.getName()));
    }

    public record SubscribeRequest(String plan) {}

    @PostMapping("/subscribe")
    public ResponseEntity<?> subscribe(@RequestBody SubscribeRequest request, Authentication auth) {
        try {
            return ResponseEntity.ok(subscriptionService.initiateSubscription(auth.getName(), request.plan()));
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    @PostMapping("/confirm/{providerReference}")
    public ResponseEntity<?> confirm(@PathVariable String providerReference) {
        try {
            return ResponseEntity.ok(subscriptionService.confirmSubscription(providerReference));
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }
}
