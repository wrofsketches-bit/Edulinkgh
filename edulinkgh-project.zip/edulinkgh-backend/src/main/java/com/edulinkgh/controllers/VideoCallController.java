package com.edulinkgh.controllers;

import com.edulinkgh.services.VideoCallService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
@RequestMapping("/api/video-calls")
public class VideoCallController {

    private final VideoCallService videoCallService;

    public VideoCallController(VideoCallService videoCallService) {
        this.videoCallService = videoCallService;
    }

    @GetMapping("/session/{sessionId}/join")
    public ResponseEntity<?> getJoinInfo(@PathVariable Long sessionId, Authentication auth) {
        try {
            return ResponseEntity.ok(videoCallService.getJoinInfo(sessionId, auth.getName()));
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }
}
