package com.edulinkgh.controllers;

import com.edulinkgh.services.PaymentService;

import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/payments")

public class PaymentController {

    private final PaymentService paymentService;

    public PaymentController(PaymentService paymentService) {
        this.paymentService = paymentService;
    }

    @GetMapping("/history")
    public ResponseEntity<?> getPaymentHistory(@AuthenticationPrincipal UserDetails ud) {
        return ResponseEntity.ok(paymentService.getPaymentHistory(ud.getUsername()));
    }

    public record InitiateSessionPaymentRequest(String promoCode) {}

    /** Starts a session payment — returns a checkout URL to open, not an instant success. Call /confirm/{reference} after the user completes checkout. Body is optional; omit or send {} if no promo code. */
    @PostMapping("/session/{sessionId}")
    public ResponseEntity<?> initiateSessionPayment(
        @PathVariable Long sessionId,
        @RequestBody(required = false) InitiateSessionPaymentRequest request,
        @AuthenticationPrincipal UserDetails ud
    ) {
        try {
            String promoCode = request != null ? request.promoCode() : null;
            return ResponseEntity.ok(paymentService.initiateSessionPayment(ud.getUsername(), sessionId, promoCode));
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    /** Client calls this after returning from the checkout browser, using the providerReference from initiate. Real webhook handling should call PaymentService.confirmPayment the same way. */
    @PostMapping("/confirm/{providerReference}")
    public ResponseEntity<?> confirmPayment(@PathVariable String providerReference) {
        try {
            return ResponseEntity.ok(paymentService.confirmPayment(providerReference));
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    @PostMapping("/withdraw")
    public ResponseEntity<?> withdraw(
        @AuthenticationPrincipal UserDetails ud,
        @RequestBody Map<String, Object> body
    ) {
        try {
            double amount     = ((Number) body.get("amount")).doubleValue();
            String momoNumber = (String)  body.get("momoNumber");
            return ResponseEntity.ok(paymentService.requestWithdrawal(ud.getUsername(), amount, momoNumber));
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }
}
