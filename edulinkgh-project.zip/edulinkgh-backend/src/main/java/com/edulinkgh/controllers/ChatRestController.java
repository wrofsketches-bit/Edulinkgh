package com.edulinkgh.controllers;

import com.edulinkgh.services.ChatService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@RestController
@RequestMapping("/api/chat")
public class ChatRestController {

    private final ChatService chatService;

    // 10MB cap for chat attachments — generous enough for a photo or a
    // short document, without letting someone dump huge files into the chat.
    private static final long MAX_ATTACHMENT_BYTES = 10L * 1024 * 1024;

    public ChatRestController(ChatService chatService) {
        this.chatService = chatService;
    }

    /** List of conversations with last message preview + unread count, for an inbox screen. */
    @GetMapping("/inbox")
    public ResponseEntity<List<Map<String, Object>>> inbox(Authentication auth) {
        return ResponseEntity.ok(chatService.getInbox(auth.getName()));
    }

    /** Full message history with one other user, oldest first. */
    @GetMapping("/conversation/{otherUserId}")
    public ResponseEntity<List<Map<String, Object>>> conversation(
        @PathVariable Long otherUserId, Authentication auth
    ) {
        return ResponseEntity.ok(chatService.getConversation(auth.getName(), otherUserId));
    }

    /**
     * Uploads a file attachment and sends it as a chat message in one step.
     * Multipart form fields: file (required), recipientId (required), caption (optional).
     */
    @PostMapping(value = "/attachment", consumes = "multipart/form-data")
    public ResponseEntity<?> sendAttachment(
        @RequestParam("file") MultipartFile file,
        @RequestParam("recipientId") Long recipientId,
        @RequestParam(value = "caption", required = false) String caption,
        Authentication auth
    ) {
        if (file.isEmpty()) {
            return ResponseEntity.badRequest().body(Map.of("error", "No file was provided."));
        }
        if (file.getSize() > MAX_ATTACHMENT_BYTES) {
            return ResponseEntity.badRequest().body(Map.of("error", "File exceeds the 10MB limit."));
        }

        try {
            String originalName = file.getOriginalFilename() != null ? file.getOriginalFilename() : "file";
            String ext = originalName.contains(".") ? originalName.substring(originalName.lastIndexOf('.')) : "";
            String storedName = UUID.randomUUID() + ext;

            Path uploadPath = Paths.get("uploads/chat");
            Files.createDirectories(uploadPath);
            Files.copy(file.getInputStream(), uploadPath.resolve(storedName), StandardCopyOption.REPLACE_EXISTING);

            String relativePath = "uploads/chat/" + storedName;
            Map<String, Object> payload = chatService.sendAttachment(
                auth.getName(), recipientId, caption, relativePath, originalName, file.getContentType()
            );
            return ResponseEntity.ok(payload);
        } catch (IOException e) {
            return ResponseEntity.internalServerError().body(Map.of("error", "Could not save the file."));
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }
}
