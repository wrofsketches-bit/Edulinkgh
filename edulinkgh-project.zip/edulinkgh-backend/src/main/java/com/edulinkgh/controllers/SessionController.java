package com.edulinkgh.controllers;

import com.edulinkgh.services.SessionService;

import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/sessions")

public class SessionController {

    private final SessionService sessionService;

    public SessionController(SessionService sessionService) {
        this.sessionService = sessionService;
    }

    @GetMapping
    public ResponseEntity<?> getUpcomingSessions() {
        return ResponseEntity.ok(sessionService.getUpcomingSessions());
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> getSession(@PathVariable Long id) {
        try {
            return ResponseEntity.ok(sessionService.getSession(id));
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    @GetMapping("/my/teacher")
    public ResponseEntity<?> getMyTeacherSessions(@AuthenticationPrincipal UserDetails ud) {
        return ResponseEntity.ok(sessionService.getTeacherSessions(ud.getUsername()));
    }

    @GetMapping("/my/student")
    public ResponseEntity<?> getMyStudentSessions(@AuthenticationPrincipal UserDetails ud) {
        return ResponseEntity.ok(sessionService.getStudentSessions(ud.getUsername()));
    }

    @PostMapping("/create")
    public ResponseEntity<?> createSession(
        @AuthenticationPrincipal UserDetails ud,
        @RequestBody Map<String, Object> body
    ) {
        try {
            return ResponseEntity.ok(sessionService.createSession(ud.getUsername(), body));
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    @PostMapping("/enroll/{id}")
    public ResponseEntity<?> enrollInSession(
        @PathVariable Long id,
        @AuthenticationPrincipal UserDetails ud
    ) {
        try {
            return ResponseEntity.ok(sessionService.enrollStudent(id, ud.getUsername()));
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    @PostMapping("/start/{id}")
    public ResponseEntity<?> startSession(
        @PathVariable Long id,
        @AuthenticationPrincipal UserDetails ud
    ) {
        try {
            return ResponseEntity.ok(sessionService.startSession(id, ud.getUsername()));
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    @PostMapping("/end/{id}")
    public ResponseEntity<?> endSession(
        @PathVariable Long id,
        @AuthenticationPrincipal UserDetails ud
    ) {
        try {
            return ResponseEntity.ok(sessionService.endSession(id, ud.getUsername()));
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> cancelSession(
        @PathVariable Long id,
        @AuthenticationPrincipal UserDetails ud
    ) {
        try {
            return ResponseEntity.ok(sessionService.cancelSession(id, ud.getUsername()));
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }
}
