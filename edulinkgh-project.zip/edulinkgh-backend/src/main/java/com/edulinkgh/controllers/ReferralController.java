package com.edulinkgh.controllers;

import com.edulinkgh.services.ReferralService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/referrals")
public class ReferralController {

    private final ReferralService referralService;

    public ReferralController(ReferralService referralService) {
        this.referralService = referralService;
    }

    @GetMapping("/me")
    public ResponseEntity<?> getMyReferralStats(Authentication auth) {
        return ResponseEntity.ok(referralService.getMyReferralStats(auth.getName()));
    }
}
