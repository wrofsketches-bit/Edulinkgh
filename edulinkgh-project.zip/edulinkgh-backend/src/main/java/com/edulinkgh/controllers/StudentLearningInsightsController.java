package com.edulinkgh.controllers;

import com.edulinkgh.services.StudentLearningInsightsService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/students/me")
public class StudentLearningInsightsController {

    private final StudentLearningInsightsService insightsService;

    public StudentLearningInsightsController(StudentLearningInsightsService insightsService) {
        this.insightsService = insightsService;
    }

    @GetMapping("/insights")
    public ResponseEntity<?> getInsights(@RequestParam(required = false) Integer days, Authentication auth) {
        return ResponseEntity.ok(insightsService.getInsights(auth.getName(), days));
    }
}
