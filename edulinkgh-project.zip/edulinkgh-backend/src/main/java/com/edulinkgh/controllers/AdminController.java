package com.edulinkgh.controllers;

import com.edulinkgh.services.AdminAnalyticsService;
import com.edulinkgh.services.AdminService;
import com.edulinkgh.services.PaymentService;
import com.edulinkgh.services.PlatformSettingsService;
import com.edulinkgh.services.PromoCodeService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.Map;

@RestController
@RequestMapping("/api/admin")
@PreAuthorize("hasRole('ADMIN')")
public class AdminController {

    private final AdminService   adminService;
    private final PaymentService paymentService;
    private final AdminAnalyticsService analyticsService;
    private final PromoCodeService promoCodeService;
    private final PlatformSettingsService platformSettingsService;

    public AdminController(AdminService adminService, PaymentService paymentService,
                            AdminAnalyticsService analyticsService, PromoCodeService promoCodeService,
                            PlatformSettingsService platformSettingsService) {
        this.adminService   = adminService;
        this.paymentService = paymentService;
        this.analyticsService = analyticsService;
        this.promoCodeService = promoCodeService;
        this.platformSettingsService = platformSettingsService;
    }

    @GetMapping("/stats")
    public ResponseEntity<?> getStats() {
        return ResponseEntity.ok(adminService.getPlatformStats());
    }

    @GetMapping("/teachers")
    public ResponseEntity<?> getAllTeachers() {
        return ResponseEntity.ok(adminService.getAllTeachers());
    }

    @GetMapping("/students")
    public ResponseEntity<?> getAllStudents() {
        return ResponseEntity.ok(adminService.getAllStudents());
    }

    @GetMapping("/sessions")
    public ResponseEntity<?> getAllSessions() {
        return ResponseEntity.ok(adminService.getAllSessions());
    }

    @PostMapping("/teachers/{id}/verify")
    public ResponseEntity<?> verifyTeacher(@PathVariable Long id) {
        try { return ResponseEntity.ok(adminService.verifyTeacher(id)); }
        catch (RuntimeException e) { return ResponseEntity.badRequest().body(Map.of("error", e.getMessage())); }
    }

    @PostMapping("/users/{id}/suspend")
    public ResponseEntity<?> suspendUser(@PathVariable Long id) {
        try { return ResponseEntity.ok(adminService.suspendUser(id)); }
        catch (RuntimeException e) { return ResponseEntity.badRequest().body(Map.of("error", e.getMessage())); }
    }

    @PostMapping("/users/{id}/reactivate")
    public ResponseEntity<?> reactivateUser(@PathVariable Long id) {
        try { return ResponseEntity.ok(adminService.reactivateUser(id)); }
        catch (RuntimeException e) { return ResponseEntity.badRequest().body(Map.of("error", e.getMessage())); }
    }

    @DeleteMapping("/users/{id}")
    public ResponseEntity<?> deleteUser(@PathVariable Long id) {
        try { return ResponseEntity.ok(adminService.deleteUser(id)); }
        catch (RuntimeException e) { return ResponseEntity.badRequest().body(Map.of("error", e.getMessage())); }
    }

    @DeleteMapping("/sessions/{id}")
    public ResponseEntity<?> cancelSession(@PathVariable Long id) {
        try { return ResponseEntity.ok(adminService.cancelSession(id)); }
        catch (RuntimeException e) { return ResponseEntity.badRequest().body(Map.of("error", e.getMessage())); }
    }

    @PostMapping("/teachers/{id}/pay")
    public ResponseEntity<?> payTeacher(@PathVariable Long id, @RequestBody Map<String, Object> body) {
        try {
            double amount = ((Number) body.get("amount")).doubleValue();
            String notes  = (String) body.getOrDefault("notes", "");
            return ResponseEntity.ok(paymentService.adminPayTeacher(id, amount, notes));
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    @GetMapping("/revenue")
    public ResponseEntity<?> getRevenue() {
        return ResponseEntity.ok(paymentService.getPlatformRevenue());
    }

    @GetMapping("/analytics/revenue")
    public ResponseEntity<?> getRevenueOverTime(@RequestParam(required = false) Integer days) {
        return ResponseEntity.ok(analyticsService.getRevenueOverTime(days));
    }

    @GetMapping("/analytics/sessions")
    public ResponseEntity<?> getSessionVolumeOverTime(@RequestParam(required = false) Integer days) {
        return ResponseEntity.ok(analyticsService.getSessionVolumeOverTime(days));
    }

    /** Manually sweep stuck PENDING payments right now, instead of waiting for the scheduled job. Useful for support/debugging. */
    @PostMapping("/payments/reconcile")
    public ResponseEntity<?> reconcilePayments() {
        int resolved = paymentService.reconcileStalePayments(java.time.LocalDateTime.now().minusMinutes(5));
        return ResponseEntity.ok(Map.of("resolved", resolved));
    }

    public record CreatePromoCodeRequest(
        String code, double percentOff, String expiresAt,
        Integer maxRedemptions, Integer maxRedemptionsPerUser
    ) {}

    @PostMapping("/promo-codes")
    public ResponseEntity<?> createPromoCode(@RequestBody CreatePromoCodeRequest request) {
        try {
            LocalDateTime expiresAt = request.expiresAt() != null && !request.expiresAt().isBlank()
                ? LocalDateTime.parse(request.expiresAt())
                : null;
            return ResponseEntity.ok(promoCodeService.createCode(
                request.code(), request.percentOff(), expiresAt,
                request.maxRedemptions(), request.maxRedemptionsPerUser()
            ));
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    @GetMapping("/promo-codes")
    public ResponseEntity<?> listPromoCodes() {
        return ResponseEntity.ok(promoCodeService.listAll());
    }

    @PostMapping("/promo-codes/{codeId}/deactivate")
    public ResponseEntity<?> deactivatePromoCode(@PathVariable Long codeId) {
        try {
            return ResponseEntity.ok(promoCodeService.setActive(codeId, false));
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    @PostMapping("/promo-codes/{codeId}/activate")
    public ResponseEntity<?> activatePromoCode(@PathVariable Long codeId) {
        try {
            return ResponseEntity.ok(promoCodeService.setActive(codeId, true));
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    @GetMapping("/settings")
    public ResponseEntity<?> getSettings() {
        return ResponseEntity.ok(platformSettingsService.getSettings());
    }

    public record SetCommissionRateRequest(double percent) {}

    @PostMapping("/settings/commission-rate")
    public ResponseEntity<?> setGlobalCommissionRate(@RequestBody SetCommissionRateRequest request) {
        try {
            platformSettingsService.setGlobalCommissionRatePercent(request.percent());
            return ResponseEntity.ok(platformSettingsService.getSettings());
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    public record SetTeacherCommissionOverrideRequest(Double percent) {} // null percent clears the override, reverting to the global rate

    @PostMapping("/teachers/{teacherId}/commission-rate")
    public ResponseEntity<?> setTeacherCommissionOverride(
        @PathVariable Long teacherId, @RequestBody SetTeacherCommissionOverrideRequest request
    ) {
        try {
            return ResponseEntity.ok(platformSettingsService.setTeacherOverride(teacherId, request.percent()));
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }
}
