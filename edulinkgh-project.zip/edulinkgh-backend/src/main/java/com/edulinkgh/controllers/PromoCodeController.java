package com.edulinkgh.controllers;

import com.edulinkgh.services.PromoCodeService;
import com.edulinkgh.services.SessionService;
import com.edulinkgh.services.UserService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.LinkedHashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/promo-codes")
public class PromoCodeController {

    private final PromoCodeService promoCodeService;
    private final SessionService sessionService;
    private final UserService userService;

    public PromoCodeController(PromoCodeService promoCodeService, SessionService sessionService, UserService userService) {
        this.promoCodeService = promoCodeService;
        this.sessionService = sessionService;
        this.userService = userService;
    }

    public record PreviewRequest(String code, Long sessionId) {}

    /** Lets the student see the discount before actually starting checkout. */
    @PostMapping("/preview")
    public ResponseEntity<?> preview(@RequestBody PreviewRequest request, Authentication auth) {
        try {
            var session = sessionService.findById(request.sessionId());
            var user = userService.findByEmail(auth.getName());
            var result = promoCodeService.validate(request.code(), user, session.getFeeGhc());

            Map<String, Object> payload = new LinkedHashMap<>();
            payload.put("valid", true);
            payload.put("originalAmount", session.getFeeGhc());
            payload.put("discountAmount", result.discountAmountGhc());
            payload.put("finalAmount", result.finalAmountGhc());
            return ResponseEntity.ok(payload);
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(Map.of("valid", false, "error", e.getMessage()));
        }
    }
}
