package com.edulinkgh.controllers;

import com.edulinkgh.services.PushNotificationService;
import com.edulinkgh.services.UserService;
import jakarta.validation.constraints.NotBlank;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/notifications")
public class PushNotificationController {

    private final PushNotificationService pushNotificationService;
    private final UserService userService;

    public PushNotificationController(PushNotificationService pushNotificationService, UserService userService) {
        this.pushNotificationService = pushNotificationService;
        this.userService = userService;
    }

    public record RegisterTokenRequest(@NotBlank String fcmToken, @NotBlank String platform) {}

    @PostMapping("/register-token")
    public ResponseEntity<Map<String, String>> registerToken(
        @RequestBody RegisterTokenRequest request, Authentication auth
    ) {
        Long userId = userService.findByEmail(auth.getName()).getId();
        pushNotificationService.registerToken(userId, request.fcmToken(), request.platform());
        return ResponseEntity.ok(Map.of("message", "Device registered for push notifications."));
    }

    public record UnregisterTokenRequest(@NotBlank String fcmToken) {}

    @PostMapping("/unregister-token")
    public ResponseEntity<Map<String, String>> unregisterToken(@RequestBody UnregisterTokenRequest request) {
        pushNotificationService.unregisterToken(request.fcmToken());
        return ResponseEntity.ok(Map.of("message", "Device unregistered."));
    }
}
