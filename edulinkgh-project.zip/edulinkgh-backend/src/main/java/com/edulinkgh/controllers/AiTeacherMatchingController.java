package com.edulinkgh.controllers;

import com.edulinkgh.services.AiTeacherMatchingService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/ai/match")
public class AiTeacherMatchingController {

    private final AiTeacherMatchingService matchingService;

    public AiTeacherMatchingController(AiTeacherMatchingService matchingService) {
        this.matchingService = matchingService;
    }

    public record MatchRequest(String request) {}

    @PostMapping
    public ResponseEntity<?> matchTeachers(@RequestBody MatchRequest matchRequest, Authentication auth) {
        try {
            List<Map<String, Object>> results = matchingService.matchTeachers(auth.getName(), matchRequest.request());
            return ResponseEntity.ok(results);
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }
}
