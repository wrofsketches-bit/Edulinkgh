package com.edulinkgh.controllers;

import com.edulinkgh.services.TeacherAvailabilityService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.time.DayOfWeek;
import java.time.LocalTime;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/teachers")
public class TeacherAvailabilityController {

    private final TeacherAvailabilityService availabilityService;

    public TeacherAvailabilityController(TeacherAvailabilityService availabilityService) {
        this.availabilityService = availabilityService;
    }

    /** Public — students browsing a teacher's profile need to see this without any special role. */
    @GetMapping("/{teacherId}/availability")
    public ResponseEntity<List<Map<String, Object>>> getAvailability(@PathVariable Long teacherId) {
        return ResponseEntity.ok(availabilityService.getForTeacher(teacherId));
    }

    public record AddWindowRequest(String dayOfWeek, String startTime, String endTime) {}

    /** Authenticated teacher manages their own availability windows. */
    @PostMapping("/me/availability")
    public ResponseEntity<?> addWindow(@RequestBody AddWindowRequest request, Authentication auth) {
        try {
            DayOfWeek day = DayOfWeek.valueOf(request.dayOfWeek().toUpperCase());
            LocalTime start = LocalTime.parse(request.startTime());
            LocalTime end = LocalTime.parse(request.endTime());
            return ResponseEntity.ok(availabilityService.addWindow(auth.getName(), day, start, end));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(Map.of("error", "Invalid day or time format."));
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    @DeleteMapping("/me/availability/{windowId}")
    public ResponseEntity<Map<String, String>> removeWindow(@PathVariable Long windowId, Authentication auth) {
        availabilityService.removeWindow(auth.getName(), windowId);
        return ResponseEntity.ok(Map.of("message", "Availability window removed."));
    }
}
