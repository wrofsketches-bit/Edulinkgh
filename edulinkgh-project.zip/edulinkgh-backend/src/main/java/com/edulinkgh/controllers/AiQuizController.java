package com.edulinkgh.controllers;

import com.edulinkgh.services.AiQuizService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/ai/quiz")
public class AiQuizController {

    private final AiQuizService quizService;

    public AiQuizController(AiQuizService quizService) {
        this.quizService = quizService;
    }

    public record GenerateQuizRequest(String topic, String difficulty, Integer questionCount) {}

    @PostMapping("/generate")
    public ResponseEntity<?> generateQuiz(@RequestBody GenerateQuizRequest request, Authentication auth) {
        try {
            return ResponseEntity.ok(
                quizService.generateQuiz(auth.getName(), request.topic(), request.difficulty(), request.questionCount())
            );
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    @GetMapping("/history")
    public ResponseEntity<List<Map<String, Object>>> getHistory(Authentication auth) {
        return ResponseEntity.ok(quizService.getHistory(auth.getName()));
    }

    @GetMapping("/{quizId}")
    public ResponseEntity<?> getQuiz(@PathVariable Long quizId, Authentication auth) {
        try {
            return ResponseEntity.ok(quizService.getById(quizId, auth.getName()));
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }
}
