package com.edulinkgh.controllers;

import com.edulinkgh.services.TeacherStatsService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/teachers/me")
public class TeacherStatsController {

    private final TeacherStatsService teacherStatsService;

    public TeacherStatsController(TeacherStatsService teacherStatsService) {
        this.teacherStatsService = teacherStatsService;
    }

    @GetMapping("/stats")
    public ResponseEntity<?> getStats(Authentication auth) {
        return ResponseEntity.ok(teacherStatsService.getStats(auth.getName()));
    }

    @GetMapping("/trends")
    public ResponseEntity<?> getTrends(@RequestParam(required = false) Integer days, Authentication auth) {
        return ResponseEntity.ok(teacherStatsService.getTrends(auth.getName(), days));
    }
}
