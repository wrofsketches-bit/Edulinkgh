package com.edulinkgh.payments;

import com.edulinkgh.services.PaymentService;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * Stands in for Paystack's own hosted checkout page during development.
 * DELETE THIS CONTROLLER once a real PaymentProvider (Paystack) is wired in —
 * it exists purely so the mobile app has something real to open in a
 * browser and confirm against, without needing live payment credentials.
 */
@RestController
public class MockCheckoutController {

    private final MockPaymentProvider mockPaymentProvider;
    private final PaymentService paymentService;

    public MockCheckoutController(MockPaymentProvider mockPaymentProvider, PaymentService paymentService) {
        this.mockPaymentProvider = mockPaymentProvider;
        this.paymentService = paymentService;
    }

    @GetMapping(value = "/api/payments/mock-checkout", produces = MediaType.TEXT_HTML_VALUE)
    public ResponseEntity<String> checkoutPage(@RequestParam String ref) {
        String html = """
            <!DOCTYPE html>
            <html>
            <head><meta name="viewport" content="width=device-width, initial-scale=1">
            <style>
              body { font-family: -apple-system, sans-serif; background: #0F172A; color: #F8FAFC;
                     display: flex; align-items: center; justify-content: center; height: 100vh; margin: 0; }
              .card { background: #1E293B; padding: 32px; border-radius: 20px; max-width: 320px; text-align: center; }
              button { background: #4F46E5; color: white; border: none; padding: 14px 24px; border-radius: 12px;
                       font-size: 16px; font-weight: 600; margin-top: 16px; width: 100%%; }
              p { color: #94A3B8; }
            </style></head>
            <body>
              <div class="card">
                <h2>Test Checkout</h2>
                <p>This stands in for Paystack's real page until live keys are added.</p>
                <p style="font-size:12px">Reference: %s</p>
                <button onclick="confirm()">Simulate Successful Payment</button>
              </div>
              <script>
                function confirm() {
                  fetch('/api/payments/mock-confirm?ref=%s', { method: 'POST' })
                    .then(() => { document.body.innerHTML = '<div class="card"><h2>✓ Payment confirmed</h2><p>You can close this window.</p></div>'; });
                }
              </script>
            </body>
            </html>
            """.formatted(ref, ref);
        return ResponseEntity.ok(html);
    }

    @PostMapping("/api/payments/mock-confirm")
    public ResponseEntity<?> confirm(@RequestParam String ref) {
        try {
            return ResponseEntity.ok(paymentService.confirmPayment(ref));
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(java.util.Map.of("error", e.getMessage()));
        }
    }
}
