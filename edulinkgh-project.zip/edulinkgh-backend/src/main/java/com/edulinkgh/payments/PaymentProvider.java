package com.edulinkgh.payments;

/**
 * Abstraction over "whoever actually moves the money". Today the only
 * implementation is MockPaymentProvider (no real charging happens).
 * When Paystack credentials are available, add a PaystackPaymentProvider
 * implementing this same interface and switch it in via
 * app.payments.provider=paystack in application.properties — nothing in
 * PaymentService or the controllers needs to change.
 */
public interface PaymentProvider {

    /**
     * Starts a payment. Returns a checkout URL the client opens in a
     * browser/webview, plus the provider's own reference for that attempt
     * (used later to verify or to match an incoming webhook).
     */
    InitResult initializePayment(InitRequest request);

    /**
     * Called either by a webhook handler or (for the mock provider) directly
     * by a "confirm" endpoint, to check whether a given provider reference
     * actually succeeded. This is the only place that should ever mark a
     * Payment COMPLETED — never trust the client's word that it paid.
     */
    VerificationResult verifyPayment(String providerReference);

    record InitRequest(
        String internalReference,   // our own Payment.reference, so we can reconcile it later
        double amountGhc,
        String payerEmail,
        String description
    ) {}

    record InitResult(
        String checkoutUrl,
        String providerReference
    ) {}

    enum VerificationStatus { SUCCESS, FAILED, PENDING, NOT_FOUND }

    record VerificationResult(
        VerificationStatus status,
        double amountGhc, // as reported by the provider, so we can cross-check against what we expected
        String internalReference
    ) {}
}
