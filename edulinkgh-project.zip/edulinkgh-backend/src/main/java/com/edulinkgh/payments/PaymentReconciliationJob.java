package com.edulinkgh.payments;

import com.edulinkgh.services.PaymentService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;

/**
 * Safety net for payments that never got confirmed by the client — e.g. the
 * app was closed mid-checkout, or a network drop happened right after the
 * user paid. Without this, such a payment would sit PENDING forever even if
 * the money genuinely moved at the gateway.
 *
 * A real Paystack webhook (see PAYSTACK_INTEGRATION.md) is the *primary*
 * mechanism for catching this quickly — this job is the backstop for when
 * even the webhook is missed (rare, but "rare" isn't "never" with webhooks).
 */
@Component
public class PaymentReconciliationJob {

    private static final Logger log = LoggerFactory.getLogger(PaymentReconciliationJob.class);

    // Anything younger than this is left alone — checkout can legitimately
    // still be in progress (entering a MoMo PIN, waiting on a prompt, etc.).
    private static final int STALE_AFTER_MINUTES = 5;

    private final PaymentService paymentService;

    public PaymentReconciliationJob(PaymentService paymentService) {
        this.paymentService = paymentService;
    }

    @Scheduled(fixedDelay = 5 * 60 * 1000) // every 5 minutes
    public void reconcile() {
        LocalDateTime cutoff = LocalDateTime.now().minusMinutes(STALE_AFTER_MINUTES);
        int resolved = paymentService.reconcileStalePayments(cutoff);
        if (resolved > 0) {
            log.info("Payment reconciliation resolved {} stale pending payment(s).", resolved);
        }
    }
}
