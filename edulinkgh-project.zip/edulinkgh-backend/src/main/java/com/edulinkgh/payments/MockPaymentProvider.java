package com.edulinkgh.payments;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Stand-in for a real gateway (Paystack, Hubtel, etc.) until credentials
 * exist. Mimics the real shape of a hosted-checkout flow:
 *   1. initializePayment() returns a "checkout URL" (actually just an
 *      internal confirmation page) and a provider reference.
 *   2. The transaction sits PENDING until something calls verifyPayment().
 *
 * This is active only when app.payments.provider=mock (the default).
 * A real PaystackPaymentProvider should implement the same interface and
 * be swapped in via that property — see PaymentProvider.java.
 */
@Component
public class MockPaymentProvider implements PaymentProvider {

    // In-memory only — fine for local/dev testing, NOT for anything durable.
    // A real provider has no need for this at all, since Paystack itself is
    // the source of truth; this map exists purely to simulate that.
    private final Map<String, InitRequest> pendingByProviderRef = new ConcurrentHashMap<>();

    @Value("${app.base-url:http://localhost:8080}")
    private String baseUrl;

    @Override
    public InitResult initializePayment(InitRequest request) {
        String providerRef = "MOCK-" + UUID.randomUUID().toString().substring(0, 12).toUpperCase();
        pendingByProviderRef.put(providerRef, request);

        // A real provider returns Paystack's own hosted page here instead.
        String checkoutUrl = baseUrl + "/api/payments/mock-checkout?ref=" + providerRef;
        return new InitResult(checkoutUrl, providerRef);
    }

    @Override
    public VerificationResult verifyPayment(String providerReference) {
        InitRequest original = pendingByProviderRef.get(providerReference);
        if (original == null) {
            return new VerificationResult(VerificationStatus.NOT_FOUND, 0, null);
        }
        // The mock always "succeeds" once confirmed — see MockCheckoutController
        // for the page that triggers this, standing in for the user actually
        // completing MoMo/card entry on Paystack's real page.
        return new VerificationResult(VerificationStatus.SUCCESS, original.amountGhc(), original.internalReference());
    }
}
