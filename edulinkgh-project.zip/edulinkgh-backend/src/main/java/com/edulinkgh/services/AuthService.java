package com.edulinkgh.services;

import com.edulinkgh.dto.AuthDTOs;
import com.edulinkgh.models.PasswordResetOtp;
import com.edulinkgh.models.User;
import com.edulinkgh.repositories.PasswordResetOtpRepository;
import com.edulinkgh.repositories.UserRepository;
import com.edulinkgh.security.JwtUtil;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.security.SecureRandom;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

@Service
public class AuthService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtUtil jwtUtil;
    private final AuthenticationManager authenticationManager;
    private final UserDetailsService userDetailsService;
    private final PasswordResetOtpRepository passwordResetOtpRepository;
    private final ReferralService referralService;

    private static final SecureRandom RANDOM = new SecureRandom();
    private static final int OTP_VALID_MINUTES = 10;

    public AuthService(UserRepository userRepository, PasswordEncoder passwordEncoder,
                       JwtUtil jwtUtil, AuthenticationManager authenticationManager,
                       UserDetailsService userDetailsService,
                       PasswordResetOtpRepository passwordResetOtpRepository,
                       ReferralService referralService) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
        this.jwtUtil = jwtUtil;
        this.authenticationManager = authenticationManager;
        this.userDetailsService = userDetailsService;
        this.passwordResetOtpRepository = passwordResetOtpRepository;
        this.referralService = referralService;
    }

    public AuthDTOs.AuthResponse register(AuthDTOs.RegisterRequest request) {
        if (userRepository.existsByEmail(request.getEmail())) {
            throw new RuntimeException("Email already registered.");
        }
        User user = User.builder()
            .fullName(request.getFullName())
            .email(request.getEmail())
            .password(passwordEncoder.encode(request.getPassword()))
            .phone(request.getPhone())
            .role(request.getRole())
            .schoolName(request.getSchoolName())
            .schoolLevel(request.getSchoolLevel())
            .subject(request.getSubject())
            .teachingLevel(request.getTeachingLevel())
            .qualification(request.getQualification())
            .status(request.getRole() == User.Role.TEACHER
                ? User.AccountStatus.PENDING_VERIFICATION
                : User.AccountStatus.ACTIVE)
            .build();
        user.setReferralCode(referralService.generateReferralCode());
        userRepository.save(user);

        // Attribute this signup to whoever referred them, if a valid code
        // was provided — deliberately non-fatal: an invalid/missing code
        // should never block registration itself.
        referralService.recordReferralIfValid(request.getReferralCode(), user);

        String token = generateToken(user);
        return AuthDTOs.AuthResponse.builder()
            .token(token)
            .role(user.getRole().name())
            .userId(user.getId())
            .fullName(user.getFullName())
            .email(user.getEmail())
            .qualificationVerified(user.isQualificationVerified())
            .build();
    }

    public AuthDTOs.AuthResponse login(AuthDTOs.LoginRequest request) {
        authenticationManager.authenticate(
            new UsernamePasswordAuthenticationToken(request.getEmail(), request.getPassword())
        );
        User user = userRepository.findByEmail(request.getEmail())
            .orElseThrow(() -> new RuntimeException("User not found."));
        if (user.getStatus() == User.AccountStatus.SUSPENDED) {
            throw new RuntimeException("Your account has been suspended. Contact support.");
        }
        String token = generateToken(user);
        return AuthDTOs.AuthResponse.builder()
            .token(token)
            .role(user.getRole().name())
            .userId(user.getId())
            .fullName(user.getFullName())
            .email(user.getEmail())
            .qualificationVerified(user.isQualificationVerified())
            .build();
    }

    /**
     * Generic response regardless of whether the email is registered — this
     * prevents an attacker from using this endpoint to discover which emails
     * have accounts. Real delivery (email/SMS) isn't wired up yet; until it
     * is, the OTP is returned directly in the response so it can be tested
     * end-to-end. WARNING: returning the OTP in the API response is a
     * temporary development stand-in — remove "otp" from the response the
     * moment real delivery (email/SMS) is wired up, since otherwise anyone
     * who can call this endpoint can read the code meant for the account
     * owner only.
     */
    public Map<String, String> forgotPassword(String email) {
        Map<String, String> response = new HashMap<>();
        response.put("message", "If that email is registered, a reset code has been sent.");

        boolean exists = userRepository.findByEmail(email).isPresent();
        if (!exists) {
            return response; // same generic message either way — no enumeration signal
        }

        String code = String.format("%06d", RANDOM.nextInt(1_000_000));
        PasswordResetOtp otp = new PasswordResetOtp();
        otp.setEmail(email);
        otp.setCode(code);
        otp.setExpiresAt(LocalDateTime.now().plusMinutes(OTP_VALID_MINUTES));
        passwordResetOtpRepository.save(otp);

        // TODO(you): send `code` via email/SMS here, then delete the next line.
        response.put("otp", code);
        return response;
    }

    public Map<String, String> resetPassword(String email, String otpCode, String newPassword) {
        PasswordResetOtp otp = passwordResetOtpRepository.findTopByEmailAndUsedFalseOrderByIdDesc(email)
            .orElseThrow(() -> new RuntimeException("Invalid or expired code."));

        if (otp.isUsed() || otp.getExpiresAt().isBefore(LocalDateTime.now())) {
            throw new RuntimeException("Invalid or expired code.");
        }
        if (!otp.getCode().equals(otpCode)) {
            throw new RuntimeException("Invalid or expired code.");
        }

        User user = userRepository.findByEmail(email)
            .orElseThrow(() -> new RuntimeException("Invalid or expired code."));

        user.setPassword(passwordEncoder.encode(newPassword));
        userRepository.save(user);

        otp.setUsed(true);
        passwordResetOtpRepository.save(otp);

        Map<String, String> response = new HashMap<>();
        response.put("message", "Password reset successfully.");
        return response;
    }

    private String generateToken(User user) {
        UserDetails userDetails = userDetailsService.loadUserByUsername(user.getEmail());
        Map<String, Object> claims = new HashMap<>();
        claims.put("role", user.getRole().name());
        claims.put("userId", user.getId());
        claims.put("fullName", user.getFullName());
        return jwtUtil.generateToken(userDetails, claims);
    }
}
