package com.edulinkgh.services;

import com.edulinkgh.ai.AiTutorProvider;
import com.edulinkgh.models.AiHomeworkQuestion;
import com.edulinkgh.models.User;
import com.edulinkgh.repositories.AiHomeworkQuestionRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class AiTutorService {

    private final AiTutorProvider provider;
    private final AiHomeworkQuestionRepository questionRepository;
    private final UserService userService;
    private final SubscriptionService subscriptionService;

    private static final int MAX_QUESTION_LENGTH = 2000;

    public AiTutorService(AiTutorProvider provider, AiHomeworkQuestionRepository questionRepository,
                          UserService userService, SubscriptionService subscriptionService) {
        this.provider = provider;
        this.questionRepository = questionRepository;
        this.userService = userService;
        this.subscriptionService = subscriptionService;
    }

    public Map<String, Object> askQuestion(String studentEmail, String question, String subjectContext) {
        User student = validateAndCheckLimit(studentEmail, question);

        String answer = provider.askHomeworkQuestion(question.trim(), subjectContext);

        AiHomeworkQuestion record = new AiHomeworkQuestion();
        record.setStudent(student);
        record.setQuestion(question.trim());
        record.setSubjectContext(subjectContext);
        record.setAnswer(answer);
        questionRepository.save(record);

        int limit = subscriptionService.getCurrentPlanDefinition(student.getId()).aiHomeworkDailyLimit();
        long askedToday = questionRepository.countByStudentSince(student.getId(), LocalDateTime.now().minusHours(24));
        Map<String, Object> result = new LinkedHashMap<>();
        result.put("answer", answer);
        result.put("questionsRemainingToday", Math.max(0, limit - askedToday));
        return result;
    }

    /**
     * Streaming variant. Validates and rate-limits up front (same rules as
     * askQuestion), then hands token-by-token delivery to the provider.
     * Persists the full question/answer to history once the stream
     * completes successfully — an interrupted stream is NOT saved to
     * history, since a partial answer isn't a meaningful record.
     *
     * onToken/onComplete/onError run on whatever thread the provider calls
     * them from (a background thread — see OpenAiTutorProvider) — this
     * method itself does not block waiting for the stream, except for the
     * synchronous up-front validation.
     */
    public void askQuestionStreaming(String studentEmail, String question, String subjectContext,
                                      java.util.function.Consumer<String> onToken,
                                      Runnable onComplete,
                                      java.util.function.Consumer<Throwable> onError) {
        final User student;
        try {
            student = validateAndCheckLimit(studentEmail, question);
        } catch (RuntimeException e) {
            onError.accept(e);
            return;
        }

        provider.askHomeworkQuestionStreaming(
            question.trim(), subjectContext,
            onToken,
            fullAnswer -> {
                AiHomeworkQuestion record = new AiHomeworkQuestion();
                record.setStudent(student);
                record.setQuestion(question.trim());
                record.setSubjectContext(subjectContext);
                record.setAnswer(fullAnswer);
                questionRepository.save(record);
                onComplete.run();
            },
            onError
        );
    }

    private User validateAndCheckLimit(String studentEmail, String question) {
        if (!provider.isAvailable()) {
            throw new RuntimeException("The AI tutor isn't available right now. Please try again later.");
        }
        if (question == null || question.isBlank()) {
            throw new RuntimeException("Enter a question first.");
        }
        if (question.length() > MAX_QUESTION_LENGTH) {
            throw new RuntimeException("That's a bit long — try breaking it into a shorter, more specific question (max "
                + MAX_QUESTION_LENGTH + " characters).");
        }

        User student = userService.findByEmail(studentEmail);

        int limit = subscriptionService.getCurrentPlanDefinition(student.getId()).aiHomeworkDailyLimit();
        long askedToday = questionRepository.countByStudentSince(student.getId(), LocalDateTime.now().minusHours(24));
        if (askedToday >= limit) {
            throw new RuntimeException("You've reached today's limit of " + limit
                + " AI tutor questions. Upgrade your plan for a higher limit, or try again tomorrow.");
        }

        return student;
    }

    public List<Map<String, Object>> getHistory(String studentEmail) {
        User student = userService.findByEmail(studentEmail);
        return questionRepository.findByStudent_IdOrderByCreatedAtDesc(student.getId()).stream()
            .map(this::toPayload)
            .collect(Collectors.toList());
    }

    private Map<String, Object> toPayload(AiHomeworkQuestion q) {
        Map<String, Object> map = new LinkedHashMap<>();
        map.put("id", q.getId());
        map.put("question", q.getQuestion());
        map.put("subjectContext", q.getSubjectContext());
        map.put("answer", q.getAnswer());
        map.put("createdAt", q.getCreatedAt() != null ? q.getCreatedAt().toString() : "");
        return map;
    }
}
