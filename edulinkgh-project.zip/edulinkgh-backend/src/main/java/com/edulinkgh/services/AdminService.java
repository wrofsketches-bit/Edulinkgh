package com.edulinkgh.services;

import com.edulinkgh.models.Session;
import com.edulinkgh.models.User;
import com.edulinkgh.repositories.*;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class AdminService {

    private final UserRepository    userRepository;
    private final SessionRepository sessionRepository;
    private final PaymentRepository paymentRepository;
    private final UserService       userService;

    public AdminService(UserRepository userRepository, SessionRepository sessionRepository,
                        PaymentRepository paymentRepository, UserService userService) {
        this.userRepository    = userRepository;
        this.sessionRepository = sessionRepository;
        this.paymentRepository = paymentRepository;
        this.userService       = userService;
    }

    public Map<String, Object> getPlatformStats() {
        long   totalStudents = userRepository.findByRole(User.Role.STUDENT).size();
        long   totalTeachers = userRepository.findByRole(User.Role.TEACHER).size();
        long   totalSessions = sessionRepository.count();
        long   liveSessions  = sessionRepository.findByStatus(Session.SessionStatus.LIVE).size();
        Double revenue       = paymentRepository.getTotalPlatformRevenue();
        long   pendingVerif  = userRepository.findByRoleAndStatus(User.Role.TEACHER,
                                 User.AccountStatus.PENDING_VERIFICATION).size();
        Map<String, Object> map = new LinkedHashMap<>();
        map.put("totalStudents",       totalStudents);
        map.put("totalTeachers",       totalTeachers);
        map.put("totalSessions",       totalSessions);
        map.put("liveSessions",        liveSessions);
        map.put("totalRevenue",        revenue != null ? revenue : 0.0);
        map.put("pendingVerifications",pendingVerif);
        return map;
    }

    public List<Map<String, Object>> getAllTeachers() {
        return userRepository.findByRole(User.Role.TEACHER)
            .stream().map(userService::buildUserMap).toList();
    }

    public List<Map<String, Object>> getAllStudents() {
        return userRepository.findByRole(User.Role.STUDENT)
            .stream().map(userService::buildUserMap).toList();
    }

    public List<Map<String, Object>> getAllSessions() {
        return sessionRepository.findAll().stream()
            .map(s -> {
                Map<String, Object> m = new LinkedHashMap<>();
                m.put("id",            s.getId());
                m.put("subject",       s.getSubject());
                m.put("status",        s.getStatus().name());
                m.put("scheduledAt",   s.getScheduledAt().toString());
                m.put("enrolledCount", s.getEnrolledStudents().size());
                m.put("teacher",       s.getTeacher().getFullName());
                m.put("feeGhc",        s.getFeeGhc());
                return m;
            })
            .toList();
    }

    public Map<String, String> verifyTeacher(Long teacherId) {
        User teacher = userRepository.findById(teacherId)
            .orElseThrow(() -> new RuntimeException("Teacher not found."));
        teacher.setQualificationVerified(true);
        teacher.setStatus(User.AccountStatus.ACTIVE);
        userRepository.save(teacher);
        return Map.of("message", teacher.getFullName() + " qualification verified.");
    }

    public Map<String, String> suspendUser(Long userId) {
        User user = userRepository.findById(userId)
            .orElseThrow(() -> new RuntimeException("User not found."));
        user.setStatus(User.AccountStatus.SUSPENDED);
        userRepository.save(user);
        return Map.of("message", user.getFullName() + " has been suspended.");
    }

    public Map<String, String> reactivateUser(Long userId) {
        User user = userRepository.findById(userId)
            .orElseThrow(() -> new RuntimeException("User not found."));
        user.setStatus(User.AccountStatus.ACTIVE);
        userRepository.save(user);
        return Map.of("message", user.getFullName() + " account reactivated.");
    }

    public Map<String, String> deleteUser(Long userId) {
        userRepository.deleteById(userId);
        return Map.of("message", "User deleted.");
    }

    public Map<String, String> cancelSession(Long sessionId) {
        Session session = sessionRepository.findById(sessionId)
            .orElseThrow(() -> new RuntimeException("Session not found."));
        session.setStatus(Session.SessionStatus.CANCELLED);
        sessionRepository.save(session);
        return Map.of("message", "Session cancelled.");
    }
}
