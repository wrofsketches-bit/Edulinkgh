package com.edulinkgh.services;

import com.edulinkgh.models.Payment;
import com.edulinkgh.models.PromoCode;
import com.edulinkgh.models.Session;
import com.edulinkgh.models.User;
import com.edulinkgh.payments.PaymentProvider;
import com.edulinkgh.repositories.PaymentRepository;
import com.edulinkgh.repositories.PromoCodeRepository;
import com.edulinkgh.repositories.SessionRepository;
import com.edulinkgh.repositories.UserRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.*;

@Service
public class PaymentService {

    private final PaymentRepository paymentRepository;
    private final SessionRepository sessionRepository;
    private final UserRepository    userRepository;
    private final UserService       userService;
    private final PaymentProvider   paymentProvider;
    private final PromoCodeService  promoCodeService;
    private final PromoCodeRepository promoCodeRepository;
    private final PlatformSettingsService platformSettingsService;

    public PaymentService(PaymentRepository paymentRepository, SessionRepository sessionRepository,
                          UserRepository userRepository, UserService userService,
                          PaymentProvider paymentProvider, PromoCodeService promoCodeService,
                          PromoCodeRepository promoCodeRepository, PlatformSettingsService platformSettingsService) {
        this.paymentRepository = paymentRepository;
        this.sessionRepository = sessionRepository;
        this.userRepository    = userRepository;
        this.userService       = userService;
        this.paymentProvider   = paymentProvider;
        this.promoCodeService  = promoCodeService;
        this.promoCodeRepository = promoCodeRepository;
        this.platformSettingsService = platformSettingsService;
    }

    /**
     * Starts a session payment: creates a PENDING Payment row, asks the
     * provider (mock today, Paystack later) to initialize a checkout, and
     * returns the URL for the client to open. Nothing is considered paid
     * yet — that only happens in confirmPayment(), after the provider says
     * so, never based on the client's say-so alone.
     *
     * If promoCode is provided and valid, the student is charged the
     * discounted amount, but the teacher's eventual payout (in
     * confirmPayment) is still computed from the session's full stated
     * fee — the discount comes out of platform revenue, not the teacher's
     * earnings. The redemption itself isn't recorded until the payment
     * actually completes (see confirmPayment), so an abandoned checkout
     * doesn't burn a limited-use code.
     */
    public Map<String, Object> initiateSessionPayment(String studentEmail, Long sessionId, String promoCode) {
        User    student = userService.findByEmail(studentEmail);
        Session session = sessionRepository.findById(sessionId)
            .orElseThrow(() -> new RuntimeException("Session not found."));

        boolean alreadyPaid = paymentRepository.findByUserOrderByCreatedAtDesc(student).stream()
            .anyMatch(p -> p.getSession() != null
                && p.getSession().getId().equals(sessionId)
                && p.getType() == Payment.PaymentType.SESSION_FEE
                && p.getStatus() == Payment.PaymentStatus.COMPLETED);
        if (alreadyPaid) {
            throw new RuntimeException("You have already paid for this session.");
        }

        double chargeAmount = session.getFeeGhc();
        Long promoCodeId = null;
        double discountAmount = 0;
        if (promoCode != null && !promoCode.isBlank()) {
            PromoCodeService.ValidationResult validation = promoCodeService.validate(promoCode, student, session.getFeeGhc());
            chargeAmount = validation.finalAmountGhc();
            discountAmount = validation.discountAmountGhc();
            promoCodeId = validation.promoCode().getId();
        }

        String ref = "PAY-" + UUID.randomUUID().toString().substring(0,8).toUpperCase();

        Payment payment = Payment.builder()
            .user(student)
            .session(session)
            .amountGhc(chargeAmount)
            .type(Payment.PaymentType.SESSION_FEE)
            .status(Payment.PaymentStatus.PENDING)
            .reference(ref)
            .description("Session: " + session.getSubject() + " with " + session.getTeacher().getFullName()
                + (promoCodeId != null ? " (promo applied)" : ""))
            .build();
        payment.setPromoCodeId(promoCodeId);
        paymentRepository.save(payment);

        PaymentProvider.InitResult initResult = paymentProvider.initializePayment(
            new PaymentProvider.InitRequest(ref, chargeAmount, student.getEmail(), payment.getDescription())
        );

        payment.setProviderReference(initResult.providerReference());
        paymentRepository.save(payment);

        Map<String, Object> result = new LinkedHashMap<>();
        result.put("checkoutUrl", initResult.checkoutUrl());
        result.put("reference", ref);
        result.put("providerReference", initResult.providerReference());
        result.put("amount", chargeAmount);
        result.put("originalAmount", session.getFeeGhc());
        result.put("discountAmount", discountAmount);
        return result;
    }

    /**
     * Confirms a payment by asking the provider whether it actually
     * succeeded, then — only on a verified SUCCESS — completes the payment
     * and runs the commission split. This is the single place a Payment can
     * transition from PENDING to COMPLETED; nothing else should ever set
     * that status directly for a session-fee payment.
     */
    public Map<String, Object> confirmPayment(String providerReference) {
        PaymentProvider.VerificationResult verification = paymentProvider.verifyPayment(providerReference);

        if (verification.status() != PaymentProvider.VerificationStatus.SUCCESS) {
            // FAILED or NOT_FOUND means the gateway has definitively said this
            // isn't going to succeed — mark it so instead of leaving it PENDING
            // forever. Genuine PENDING (still processing at the gateway) is
            // left alone so a later check can still complete it.
            if (verification.status() == PaymentProvider.VerificationStatus.FAILED
                || verification.status() == PaymentProvider.VerificationStatus.NOT_FOUND) {
                paymentRepository.findByProviderReference(providerReference).ifPresent(p -> {
                    if (p.getStatus() == Payment.PaymentStatus.PENDING) {
                        p.setStatus(Payment.PaymentStatus.FAILED);
                        paymentRepository.save(p);
                    }
                });
            }
            Map<String, Object> result = new LinkedHashMap<>();
            result.put("status", verification.status().name());
            result.put("message", "Payment was not successful.");
            return result;
        }

        Payment payment = paymentRepository.findByProviderReference(providerReference)
            .orElseThrow(() -> new RuntimeException("Payment record not found for this reference."));

        if (payment.getStatus() == Payment.PaymentStatus.COMPLETED) {
            // Already processed (e.g. a webhook and a client-side confirm
            // both fired) — don't double-run the commission split.
            Map<String, Object> result = new LinkedHashMap<>();
            result.put("status", "SUCCESS");
            result.put("message", "Payment already confirmed.");
            result.put("reference", payment.getReference());
            return result;
        }

        // Sanity check: the amount the provider reports should match what
        // we asked for. A mismatch here would mean something is very wrong
        // (tampering, a provider bug) and should never be silently accepted.
        if (Math.abs(verification.amountGhc() - payment.getAmountGhc()) > 0.01) {
            throw new RuntimeException("Payment amount mismatch — refusing to confirm.");
        }

        Session session = payment.getSession();
        payment.setStatus(Payment.PaymentStatus.COMPLETED);
        paymentRepository.save(payment);

        if (payment.getPromoCodeId() != null) {
            promoCodeRepository.findById(payment.getPromoCodeId()).ifPresent(promo -> {
                double discountAmount = session.getFeeGhc() - payment.getAmountGhc();
                promoCodeService.recordRedemption(promo, payment.getUser(), payment.getId(), discountAmount);
            });
        }

        // Platform commission — computed from the session's full stated
        // fee, NOT the (possibly promo-discounted) amount the student
        // actually paid. This means a promo's cost comes out of platform
        // revenue, never the teacher's earnings — the teacher is paid as
        // if the student paid full price. Rate is the teacher's own
        // override if set, otherwise the platform-wide default — see
        // PlatformSettingsService.
        double commissionRatePercent = platformSettingsService.getEffectiveCommissionRatePercent(session.getTeacher());
        double commission = session.getFeeGhc() * (commissionRatePercent / 100.0);
        Payment fee = Payment.builder()
            .user(session.getTeacher())
            .session(session)
            .amountGhc(-commission)
            .type(Payment.PaymentType.PLATFORM_FEE)
            .status(Payment.PaymentStatus.COMPLETED)
            .description("Platform commission for: " + session.getSubject())
            .build();
        paymentRepository.save(fee);

        // Teacher credit
        Payment teacherCredit = Payment.builder()
            .user(session.getTeacher())
            .session(session)
            .amountGhc(session.getFeeGhc() - commission)
            .type(Payment.PaymentType.SESSION_FEE)
            .status(Payment.PaymentStatus.COMPLETED)
            .reference(payment.getReference())
            .description("Earnings from: " + session.getSubject())
            .build();
        paymentRepository.save(teacherCredit);

        Map<String, Object> result = new LinkedHashMap<>();
        result.put("status", "SUCCESS");
        result.put("message", "Payment successful.");
        result.put("reference", payment.getReference());
        result.put("amount", payment.getAmountGhc());
        return result;
    }

    public Map<String, String> requestWithdrawal(String teacherEmail, double amount, String momoNumber) {
        if (amount <= 0) {
            throw new RuntimeException("Withdrawal amount must be greater than zero.");
        }
        User teacher = userService.findByEmail(teacherEmail);
        Double totalEarned = paymentRepository.getTotalEarningsByTeacher(teacher);
        if (totalEarned == null || totalEarned < amount) {
            throw new RuntimeException("Insufficient balance.");
        }
        String ref = "PAYOUT-" + UUID.randomUUID().toString().substring(0,8).toUpperCase();
        Payment payout = Payment.builder()
            .user(teacher)
            .amountGhc(-amount)
            .type(Payment.PaymentType.PAYOUT)
            .status(Payment.PaymentStatus.PENDING)
            .reference(ref)
            .description("MoMo withdrawal to " + momoNumber)
            .build();
        paymentRepository.save(payout);
        return Map.of(
            "message",   "Withdrawal of GHC " + amount + " initiated. Ref: " + payout.getReference(),
            "reference", payout.getReference()
        );
    }

    public List<Map<String, Object>> getPaymentHistory(String email) {
        User user = userService.findByEmail(email);
        List<Map<String, Object>> list = new ArrayList<>();
        for (Payment p : paymentRepository.findByUserOrderByCreatedAtDesc(user)) {
            Map<String, Object> m = new LinkedHashMap<>();
            m.put("id",          p.getId());
            m.put("type",        p.getType().name());
            m.put("description", p.getDescription() != null ? p.getDescription() : "");
            m.put("amountGhc",   p.getAmountGhc());
            m.put("status",      p.getStatus().name());
            m.put("reference",   p.getReference() != null ? p.getReference() : "");
            m.put("createdAt",   p.getCreatedAt() != null ? p.getCreatedAt().toString() : "");
            list.add(m);
        }
        return list;
    }

    public Map<String, String> adminPayTeacher(Long teacherId, double amount, String notes) {
        if (amount <= 0) {
            throw new RuntimeException("Payout amount must be greater than zero.");
        }
        User teacher = userRepository.findById(teacherId)
            .orElseThrow(() -> new RuntimeException("Teacher not found."));
        String ref = "ADMIN-" + UUID.randomUUID().toString().substring(0,8).toUpperCase();
        Payment payout = Payment.builder()
            .user(teacher)
            .amountGhc(amount)
            .type(Payment.PaymentType.PAYOUT)
            .status(Payment.PaymentStatus.COMPLETED)
            .reference(ref)
            .description(notes != null ? notes : "Manual payout by admin")
            .build();
        paymentRepository.save(payout);
        return Map.of(
            "message",   "GHC " + amount + " paid to " + teacher.getFullName(),
            "reference", payout.getReference()
        );
    }

    public Map<String, Object> getPlatformRevenue() {
        Double total = paymentRepository.getTotalPlatformRevenue();
        return Map.of("totalRevenue", total != null ? total : 0.0);
    }

    /**
     * Safety net for payments that never got confirmed — e.g. the user
     * closed the app mid-checkout before the client could call confirm.
     * Re-verifies each stale PENDING session-fee payment against the
     * provider and resolves it one way or the other. Called by
     * PaymentReconciliationJob on a schedule; also safe to call manually
     * (e.g. from an admin tool) since confirmPayment is idempotent.
     */
    public int reconcileStalePayments(LocalDateTime olderThan) {
        List<Payment> stale = paymentRepository.findStalePendingPayments(olderThan);
        int resolved = 0;
        for (Payment payment : stale) {
            if (payment.getProviderReference() == null) {
                continue; // shouldn't happen, but nothing to reconcile against without it
            }
            try {
                confirmPayment(payment.getProviderReference());
                resolved++;
            } catch (RuntimeException e) {
                // Leave it PENDING and let the next scheduled run retry —
                // a transient provider error shouldn't permanently fail a
                // payment that might actually still succeed.
            }
        }
        return resolved;
    }
}
