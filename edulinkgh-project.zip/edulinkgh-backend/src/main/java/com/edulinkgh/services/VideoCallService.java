package com.edulinkgh.services;

import com.edulinkgh.models.Session;
import com.edulinkgh.models.User;
import com.edulinkgh.repositories.SessionRepository;
import com.edulinkgh.video.VideoCallProvider;
import org.springframework.stereotype.Service;

import java.util.LinkedHashMap;
import java.util.Map;

@Service
public class VideoCallService {

    private final SessionRepository sessionRepository;
    private final UserService userService;
    private final VideoCallProvider provider;

    public VideoCallService(SessionRepository sessionRepository, UserService userService, VideoCallProvider provider) {
        this.sessionRepository = sessionRepository;
        this.userService = userService;
        this.provider = provider;
    }

    /**
     * Returns everything the mobile client needs to join this session's
     * video call: creates the room on first request (idempotent — a
     * second student joining the same session reuses the same room rather
     * than creating a duplicate), then issues a fresh join token for this
     * specific user.
     *
     * Access is restricted to the session's teacher or an enrolled student
     * — same model already used for cancellation and topic summaries.
     * Only sessions in LIVE or UPCOMING status can be joined; a COMPLETED
     * or CANCELLED session has no reason to open a call.
     */
    public Map<String, Object> getJoinInfo(Long sessionId, String requesterEmail) {
        if (!provider.isAvailable()) {
            throw new RuntimeException("Video calls aren't available right now. Please try again later.");
        }

        Session session = sessionRepository.findById(sessionId)
            .orElseThrow(() -> new RuntimeException("Session not found."));

        User requester = userService.findByEmail(requesterEmail);
        boolean isTeacher = session.getTeacher().getId().equals(requester.getId());
        boolean isEnrolledStudent = session.getEnrolledStudents().stream()
            .anyMatch(s -> s.getId().equals(requester.getId()));
        if (!isTeacher && !isEnrolledStudent) {
            throw new RuntimeException("You don't have access to this session.");
        }

        if (session.getStatus() == Session.SessionStatus.COMPLETED || session.getStatus() == Session.SessionStatus.CANCELLED) {
            throw new RuntimeException("This session has ended — the call is no longer available.");
        }

        if (session.getVideoRoomId() == null) {
            VideoCallProvider.RoomResult room = provider.createRoom(
                "session-" + session.getId(),
                session.getSubject() + " — " + session.getTeacher().getFullName()
            );
            session.setVideoRoomId(room.roomId());
            session.setVideoRoomCode(room.roomCode());
            sessionRepository.save(session);
        }

        VideoCallProvider.Role role = isTeacher ? VideoCallProvider.Role.HOST : VideoCallProvider.Role.GUEST;
        String token = provider.generateJoinToken(session.getVideoRoomId(), requester.getId().toString(), requester.getFullName(), role);

        Map<String, Object> result = new LinkedHashMap<>();
        result.put("roomId", session.getVideoRoomId());
        result.put("roomCode", session.getVideoRoomCode());
        result.put("token", token);
        result.put("role", role.name());
        return result;
    }
}
