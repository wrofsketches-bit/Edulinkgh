package com.edulinkgh.services;

import com.edulinkgh.models.ChatMessage;
import com.edulinkgh.models.User;
import com.edulinkgh.repositories.ChatMessageRepository;
import com.edulinkgh.repositories.UserRepository;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class ChatService {

    private final ChatMessageRepository chatMessageRepository;
    private final UserRepository userRepository;
    private final UserService userService;
    private final SimpMessagingTemplate messagingTemplate;
    private final PushNotificationService pushNotificationService;

    public ChatService(ChatMessageRepository chatMessageRepository,
                        UserRepository userRepository,
                        UserService userService,
                        SimpMessagingTemplate messagingTemplate,
                        PushNotificationService pushNotificationService) {
        this.chatMessageRepository = chatMessageRepository;
        this.userRepository = userRepository;
        this.userService = userService;
        this.messagingTemplate = messagingTemplate;
        this.pushNotificationService = pushNotificationService;
    }

    /** Called from the STOMP @MessageMapping handler for plain text messages. */
    public Map<String, Object> sendMessage(String senderEmail, Long recipientId, String content) {
        if (content == null || content.isBlank()) {
            throw new RuntimeException("Message cannot be empty.");
        }
        return persistAndBroadcast(senderEmail, recipientId, content.trim(), null, null, null);
    }

    /** Called from ChatRestController after a file has been saved to disk. */
    public Map<String, Object> sendAttachment(String senderEmail, Long recipientId, String caption,
                                               String attachmentPath, String attachmentFileName, String attachmentMimeType) {
        return persistAndBroadcast(senderEmail, recipientId,
            caption != null ? caption.trim() : null, attachmentPath, attachmentFileName, attachmentMimeType);
    }

    private Map<String, Object> persistAndBroadcast(String senderEmail, Long recipientId, String content,
                                                      String attachmentPath, String attachmentFileName, String attachmentMimeType) {
        User sender = userService.findByEmail(senderEmail);
        User recipient = userRepository.findById(recipientId)
            .orElseThrow(() -> new RuntimeException("Recipient not found."));

        if (sender.getId().equals(recipient.getId())) {
            throw new RuntimeException("You cannot message yourself.");
        }

        ChatMessage message = new ChatMessage();
        message.setConversationId(ChatMessage.buildConversationId(sender.getId(), recipient.getId()));
        message.setSender(sender);
        message.setRecipient(recipient);
        message.setContent(content);
        message.setAttachmentPath(attachmentPath);
        message.setAttachmentFileName(attachmentFileName);
        message.setAttachmentMimeType(attachmentMimeType);
        chatMessageRepository.save(message);

        Map<String, Object> payload = toPayload(message);

        // Push to both participants' personal queues so both devices update live.
        messagingTemplate.convertAndSendToUser(recipient.getEmail(), "/queue/messages", payload);
        messagingTemplate.convertAndSendToUser(sender.getEmail(), "/queue/messages", payload);

        // Also fire a push notification for the recipient, in case their app
        // is backgrounded and not listening on the WebSocket right now.
        String pushBody = attachmentPath != null
            ? (content != null && !content.isBlank() ? content : "Sent an attachment")
            : content;
        pushNotificationService.sendToUser(
            recipient.getId(),
            sender.getFullName(),
            pushBody,
            Map.of("type", "chat_message", "senderId", String.valueOf(sender.getId()))
        );

        return payload;
    }

    public List<Map<String, Object>> getConversation(String currentUserEmail, Long otherUserId) {
        User currentUser = userService.findByEmail(currentUserEmail);
        User otherUser = userRepository.findById(otherUserId)
            .orElseThrow(() -> new RuntimeException("User not found."));

        String conversationId = ChatMessage.buildConversationId(currentUser.getId(), otherUser.getId());
        List<ChatMessage> messages = chatMessageRepository.findByConversationIdOrderByCreatedAtAsc(conversationId);

        // Mark incoming messages as read now that the recipient is viewing the
        // thread, and collect their IDs so the sender can be told live —
        // otherwise the sender only finds out on their next fetch, which
        // defeats the point of a "read" receipt being live.
        List<Long> newlyReadIds = new ArrayList<>();
        for (ChatMessage m : messages) {
            if (m.getRecipient().getId().equals(currentUser.getId()) && !m.isRead()) {
                m.setRead(true);
                newlyReadIds.add(m.getId());
            }
        }
        if (!newlyReadIds.isEmpty()) {
            chatMessageRepository.saveAll(messages);
            messagingTemplate.convertAndSendToUser(
                otherUser.getEmail(),
                "/queue/read-receipts",
                Map.of("readByUserId", currentUser.getId(), "messageIds", newlyReadIds)
            );
        }

        return messages.stream().map(this::toPayload).collect(Collectors.toList());
    }

    /** List of conversation partners with last message preview and unread count, for an inbox screen. */
    public List<Map<String, Object>> getInbox(String currentUserEmail) {
        User currentUser = userService.findByEmail(currentUserEmail);
        List<String> conversationIds = chatMessageRepository.findConversationIdsForUser(currentUser.getId());

        List<Map<String, Object>> inbox = new ArrayList<>();
        for (String conversationId : conversationIds) {
            List<ChatMessage> messages = chatMessageRepository.findByConversationIdOrderByCreatedAtAsc(conversationId);
            if (messages.isEmpty()) continue;

            ChatMessage last = messages.get(messages.size() - 1);
            User other = last.getSender().getId().equals(currentUser.getId()) ? last.getRecipient() : last.getSender();
            long unread = chatMessageRepository.countByConversationIdAndRecipient_IdAndReadFalse(conversationId, currentUser.getId());

            String preview = (last.getContent() != null && !last.getContent().isBlank())
                ? last.getContent()
                : (last.getAttachmentPath() != null ? "📎 " + (last.getAttachmentFileName() != null ? last.getAttachmentFileName() : "Attachment") : "");

            Map<String, Object> entry = new LinkedHashMap<>();
            entry.put("otherUserId", other.getId());
            entry.put("otherUserName", other.getFullName());
            entry.put("lastMessage", preview);
            entry.put("lastMessageAt", last.getCreatedAt() != null ? last.getCreatedAt().toString() : "");
            entry.put("unreadCount", unread);
            inbox.add(entry);
        }

        inbox.sort((a, b) -> String.valueOf(b.get("lastMessageAt")).compareTo(String.valueOf(a.get("lastMessageAt"))));
        return inbox;
    }

    private Map<String, Object> toPayload(ChatMessage m) {
        Map<String, Object> map = new LinkedHashMap<>();
        map.put("id", m.getId());
        map.put("senderId", m.getSender().getId());
        map.put("senderName", m.getSender().getFullName());
        map.put("recipientId", m.getRecipient().getId());
        map.put("content", m.getContent());
        map.put("attachmentUrl", m.getAttachmentPath() != null ? "/" + m.getAttachmentPath() : null);
        map.put("attachmentFileName", m.getAttachmentFileName());
        map.put("attachmentMimeType", m.getAttachmentMimeType());
        map.put("read", m.isRead());
        map.put("createdAt", m.getCreatedAt() != null ? m.getCreatedAt().toString() : "");
        return map;
    }
}
