package com.edulinkgh.services;

import com.edulinkgh.ai.AiTutorProvider;
import com.edulinkgh.models.Quiz;
import com.edulinkgh.models.User;
import com.edulinkgh.repositories.QuizRepository;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class AiQuizService {

    private final AiTutorProvider provider;
    private final QuizRepository quizRepository;
    private final UserService userService;
    private final SubscriptionService subscriptionService;
    private final ObjectMapper objectMapper = new ObjectMapper();

    private static final int MIN_QUESTIONS = 1;
    private static final int MAX_QUESTIONS = 15;
    private static final int MAX_TOPIC_LENGTH = 200;

    public AiQuizService(AiTutorProvider provider, QuizRepository quizRepository, UserService userService,
                          SubscriptionService subscriptionService) {
        this.provider = provider;
        this.quizRepository = quizRepository;
        this.userService = userService;
        this.subscriptionService = subscriptionService;
    }

    public Map<String, Object> generateQuiz(String userEmail, String topic, String difficulty, Integer questionCount) {
        if (!provider.isAvailable()) {
            throw new RuntimeException("Quiz generation isn't available right now. Please try again later.");
        }
        if (topic == null || topic.isBlank()) {
            throw new RuntimeException("Enter a topic first.");
        }
        if (topic.length() > MAX_TOPIC_LENGTH) {
            throw new RuntimeException("That topic is too long — try something shorter and more specific.");
        }

        int count = questionCount != null ? questionCount : 5;
        if (count < MIN_QUESTIONS || count > MAX_QUESTIONS) {
            throw new RuntimeException("Choose between " + MIN_QUESTIONS + " and " + MAX_QUESTIONS + " questions.");
        }

        User user = userService.findByEmail(userEmail);
        int limit = subscriptionService.getCurrentPlanDefinition(user.getId()).aiQuizDailyLimit();
        long generatedToday = quizRepository.countByCreatorSince(user.getId(), LocalDateTime.now().minusHours(24));
        if (generatedToday >= limit) {
            throw new RuntimeException("You've reached today's limit of " + limit
                + " generated quizzes. Upgrade your plan for a higher limit, or try again tomorrow.");
        }

        String rawJson = provider.generateQuiz(topic.trim(), difficulty, count);
        JsonNode validated = parseAndValidate(rawJson);

        Quiz quiz = new Quiz();
        quiz.setCreatedBy(user);
        quiz.setTopic(topic.trim());
        quiz.setDifficulty(difficulty);
        quiz.setQuestionsJson(validated.toString());
        quizRepository.save(quiz);

        return toPayload(quiz);
    }

    public List<Map<String, Object>> getHistory(String userEmail) {
        User user = userService.findByEmail(userEmail);
        return quizRepository.findByCreatedBy_IdOrderByCreatedAtDesc(user.getId()).stream()
            .map(this::toPayload)
            .collect(Collectors.toList());
    }

    public Map<String, Object> getById(Long quizId, String userEmail) {
        User user = userService.findByEmail(userEmail);
        Quiz quiz = quizRepository.findById(quizId)
            .orElseThrow(() -> new RuntimeException("Quiz not found."));
        if (!quiz.getCreatedBy().getId().equals(user.getId())) {
            throw new RuntimeException("You don't have access to this quiz.");
        }
        return toPayload(quiz);
    }

    /**
     * The model is instructed to return a specific JSON shape, but "asked
     * nicely" is not a validation strategy — this actually checks the shape
     * before anything gets stored or shown to a user. Throws with a message
     * fit to surface to the user if the AI's output doesn't hold up.
     */
    private JsonNode parseAndValidate(String rawJson) {
        JsonNode root;
        try {
            root = objectMapper.readTree(rawJson);
        } catch (Exception e) {
            throw new RuntimeException("The AI generated something we couldn't read. Please try again.");
        }

        JsonNode questions = root.get("questions");
        if (questions == null || !questions.isArray() || questions.isEmpty()) {
            throw new RuntimeException("The AI didn't generate any usable questions. Please try again.");
        }

        for (JsonNode q : questions) {
            JsonNode questionText = q.get("question");
            JsonNode options = q.get("options");
            JsonNode correctIndex = q.get("correctIndex");

            if (questionText == null || !questionText.isTextual() || questionText.asText().isBlank()) {
                throw new RuntimeException("The AI generated an incomplete question. Please try again.");
            }
            if (options == null || !options.isArray() || options.size() != 4) {
                throw new RuntimeException("The AI generated a question with the wrong number of options. Please try again.");
            }
            if (correctIndex == null || !correctIndex.isInt()
                || correctIndex.asInt() < 0 || correctIndex.asInt() > 3) {
                throw new RuntimeException("The AI generated a question with an invalid answer key. Please try again.");
            }
        }

        return root;
    }

    private Map<String, Object> toPayload(Quiz quiz) {
        Map<String, Object> map = new LinkedHashMap<>();
        map.put("id", quiz.getId());
        map.put("topic", quiz.getTopic());
        map.put("difficulty", quiz.getDifficulty());
        try {
            map.put("questions", objectMapper.readTree(quiz.getQuestionsJson()).get("questions"));
        } catch (Exception e) {
            map.put("questions", List.of());
        }
        map.put("createdAt", quiz.getCreatedAt() != null ? quiz.getCreatedAt().toString() : "");
        return map;
    }
}
