package com.edulinkgh.services;

import com.edulinkgh.models.PromoCode;
import com.edulinkgh.models.PromoCodeRedemption;
import com.edulinkgh.models.User;
import com.edulinkgh.repositories.PromoCodeRedemptionRepository;
import com.edulinkgh.repositories.PromoCodeRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class PromoCodeService {

    private final PromoCodeRepository promoCodeRepository;
    private final PromoCodeRedemptionRepository redemptionRepository;

    public PromoCodeService(PromoCodeRepository promoCodeRepository, PromoCodeRedemptionRepository redemptionRepository) {
        this.promoCodeRepository = promoCodeRepository;
        this.redemptionRepository = redemptionRepository;
    }

    /**
     * Validates a code for a given user and base amount, returning the
     * discount to apply — but does NOT record a redemption. Redemption is
     * recorded separately (recordRedemption) only once a payment actually
     * completes, so an abandoned checkout doesn't burn a use of a
     * limited-redemption code.
     */
    public ValidationResult validate(String rawCode, User user, double baseAmountGhc) {
        if (rawCode == null || rawCode.isBlank()) {
            throw new RuntimeException("Enter a promo code.");
        }
        String code = rawCode.trim().toUpperCase();

        PromoCode promo = promoCodeRepository.findByCode(code)
            .orElseThrow(() -> new RuntimeException("Invalid promo code."));

        if (!promo.isActive()) {
            throw new RuntimeException("This promo code is no longer active.");
        }
        if (promo.getExpiresAt() != null && promo.getExpiresAt().isBefore(LocalDateTime.now())) {
            throw new RuntimeException("This promo code has expired.");
        }
        if (promo.getMaxRedemptions() != null) {
            long totalUses = redemptionRepository.countByPromoCode_Id(promo.getId());
            if (totalUses >= promo.getMaxRedemptions()) {
                throw new RuntimeException("This promo code has reached its usage limit.");
            }
        }
        if (promo.getMaxRedemptionsPerUser() != null) {
            long myUses = redemptionRepository.countByPromoCode_IdAndUser_Id(promo.getId(), user.getId());
            if (myUses >= promo.getMaxRedemptionsPerUser()) {
                throw new RuntimeException("You've already used this promo code the maximum number of times.");
            }
        }

        double discount = Math.round(baseAmountGhc * (promo.getPercentOff() / 100.0) * 100) / 100.0;
        double finalAmount = Math.max(0, Math.round((baseAmountGhc - discount) * 100) / 100.0);

        return new ValidationResult(promo, discount, finalAmount);
    }

    public void recordRedemption(PromoCode promoCode, User user, Long paymentId, double discountAmountGhc) {
        PromoCodeRedemption redemption = new PromoCodeRedemption();
        redemption.setPromoCode(promoCode);
        redemption.setUser(user);
        redemption.setPaymentId(paymentId);
        redemption.setDiscountAmountGhc(discountAmountGhc);
        redemptionRepository.save(redemption);
    }

    // ── Admin management ─────────────────────────────────────────────────

    public Map<String, Object> createCode(String code, double percentOff, LocalDateTime expiresAt,
                                           Integer maxRedemptions, Integer maxRedemptionsPerUser) {
        if (code == null || code.isBlank()) {
            throw new RuntimeException("Code is required.");
        }
        if (percentOff <= 0 || percentOff > 100) {
            throw new RuntimeException("Percent off must be between 0 and 100.");
        }
        String normalized = code.trim().toUpperCase();
        if (promoCodeRepository.findByCode(normalized).isPresent()) {
            throw new RuntimeException("A promo code with that name already exists.");
        }

        PromoCode promo = new PromoCode();
        promo.setCode(normalized);
        promo.setPercentOff(percentOff);
        promo.setExpiresAt(expiresAt);
        promo.setMaxRedemptions(maxRedemptions);
        promo.setMaxRedemptionsPerUser(maxRedemptionsPerUser);
        promo.setActive(true);
        promoCodeRepository.save(promo);

        return toPayload(promo);
    }

    public Map<String, Object> setActive(Long codeId, boolean active) {
        PromoCode promo = promoCodeRepository.findById(codeId)
            .orElseThrow(() -> new RuntimeException("Promo code not found."));
        promo.setActive(active);
        promoCodeRepository.save(promo);
        return toPayload(promo);
    }

    public List<Map<String, Object>> listAll() {
        return promoCodeRepository.findAllByOrderByCreatedAtDesc().stream()
            .map(this::toPayloadWithUsage)
            .collect(Collectors.toList());
    }

    private Map<String, Object> toPayload(PromoCode promo) {
        Map<String, Object> map = new LinkedHashMap<>();
        map.put("id", promo.getId());
        map.put("code", promo.getCode());
        map.put("percentOff", promo.getPercentOff());
        map.put("expiresAt", promo.getExpiresAt() != null ? promo.getExpiresAt().toString() : null);
        map.put("maxRedemptions", promo.getMaxRedemptions());
        map.put("maxRedemptionsPerUser", promo.getMaxRedemptionsPerUser());
        map.put("active", promo.isActive());
        return map;
    }

    private Map<String, Object> toPayloadWithUsage(PromoCode promo) {
        Map<String, Object> map = toPayload(promo);
        map.put("totalRedemptions", redemptionRepository.countByPromoCode_Id(promo.getId()));
        return map;
    }

    public record ValidationResult(PromoCode promoCode, double discountAmountGhc, double finalAmountGhc) {}
}
