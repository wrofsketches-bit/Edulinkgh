package com.edulinkgh.services;

import com.edulinkgh.analytics.TimeSeriesBuilder;
import com.edulinkgh.models.Session;
import com.edulinkgh.models.User;
import com.edulinkgh.repositories.PaymentRepository;
import com.edulinkgh.repositories.RatingRepository;
import com.edulinkgh.repositories.SessionRepository;
import org.springframework.stereotype.Service;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

@Service
public class TeacherStatsService {

    private final SessionRepository sessionRepository;
    private final RatingRepository ratingRepository;
    private final PaymentRepository paymentRepository;
    private final UserService userService;

    public TeacherStatsService(SessionRepository sessionRepository, RatingRepository ratingRepository,
                                PaymentRepository paymentRepository, UserService userService) {
        this.sessionRepository = sessionRepository;
        this.ratingRepository = ratingRepository;
        this.paymentRepository = paymentRepository;
        this.userService = userService;
    }

    public Map<String, Object> getStats(String teacherEmail) {
        User teacher = userService.findByEmail(teacherEmail);
        List<Session> allSessions = sessionRepository.findByTeacher(teacher);

        long completedCount = allSessions.stream().filter(s -> s.getStatus() == Session.SessionStatus.COMPLETED).count();
        long cancelledCount = allSessions.stream().filter(s -> s.getStatus() == Session.SessionStatus.CANCELLED).count();
        // Completion rate is measured against sessions that reached a final
        // state (completed or cancelled) — UPCOMING/LIVE sessions haven't
        // happened yet, so including them would understate a new teacher's
        // rate for no real reason.
        long finalizedCount = completedCount + cancelledCount;
        double completionRate = finalizedCount > 0 ? (double) completedCount / finalizedCount * 100 : 0;

        Set<Long> distinctStudentIds = allSessions.stream()
            .filter(s -> s.getStatus() == Session.SessionStatus.COMPLETED)
            .flatMap(s -> s.getEnrolledStudents().stream())
            .map(User::getId)
            .collect(Collectors.toSet());

        Double averageRating = ratingRepository.findAverageRatingByTeacher(teacher);
        Long ratingCount = ratingRepository.countByTeacher(teacher);
        Double totalEarnings = paymentRepository.getTotalEarningsByTeacher(teacher);

        Map<String, Object> result = new LinkedHashMap<>();
        result.put("totalSessionsCompleted", completedCount);
        result.put("totalStudentsTaught", distinctStudentIds.size());
        result.put("completionRate", Math.round(completionRate * 10) / 10.0); // one decimal place
        result.put("averageRating", averageRating != null ? Math.round(averageRating * 10) / 10.0 : null);
        result.put("ratingCount", ratingCount != null ? ratingCount : 0);
        result.put("totalEarningsGhc", totalEarnings != null ? totalEarnings : 0.0);
        return result;
    }

    /**
     * Sessions-taught and earnings trends over a trailing window, so a
     * teacher can see whether they're growing rather than just a lifetime
     * total. Earnings here means the teacher's own net credit (post-
     * commission) — see PaymentService for how that record is created.
     */
    public Map<String, Object> getTrends(String teacherEmail, Integer days) {
        int window = (days != null && days > 0) ? days : 30;
        User teacher = userService.findByEmail(teacherEmail);

        List<Session> completedSessions = sessionRepository.findByTeacher(teacher).stream()
            .filter(s -> s.getStatus() == Session.SessionStatus.COMPLETED)
            .collect(Collectors.toList());

        List<TimeSeriesBuilder.DataPoint> sessionSeries = TimeSeriesBuilder.dailyCounts(
            completedSessions, s -> s.getScheduledAt().toLocalDate(), window
        );

        List<com.edulinkgh.models.Payment> earningsPayments = paymentRepository.findByUserOrderByCreatedAtDesc(teacher).stream()
            .filter(p -> p.getType() == com.edulinkgh.models.Payment.PaymentType.SESSION_FEE
                && p.getStatus() == com.edulinkgh.models.Payment.PaymentStatus.COMPLETED)
            .collect(Collectors.toList());
        List<TimeSeriesBuilder.DataPoint> earningsSeries = TimeSeriesBuilder.dailySeries(
            earningsPayments, p -> p.getCreatedAt().toLocalDate(), com.edulinkgh.models.Payment::getAmountGhc, window
        );

        Map<String, Object> result = new LinkedHashMap<>();
        result.put("windowDays", window);
        result.put("sessionsSeries", toPayload(sessionSeries));
        result.put("earningsSeries", toPayload(earningsSeries));
        return result;
    }

    private List<Map<String, Object>> toPayload(List<TimeSeriesBuilder.DataPoint> series) {
        return series.stream().map(dp -> {
            Map<String, Object> point = new LinkedHashMap<>();
            point.put("date", dp.date().toString());
            point.put("value", dp.value());
            return point;
        }).collect(Collectors.toList());
    }
}
