package com.edulinkgh.services;

import com.edulinkgh.models.TeacherAvailability;
import com.edulinkgh.models.User;
import com.edulinkgh.repositories.TeacherAvailabilityRepository;
import org.springframework.stereotype.Service;

import java.time.DayOfWeek;
import java.time.LocalTime;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class TeacherAvailabilityService {

    private final TeacherAvailabilityRepository availabilityRepository;
    private final UserService userService;

    public TeacherAvailabilityService(TeacherAvailabilityRepository availabilityRepository, UserService userService) {
        this.availabilityRepository = availabilityRepository;
        this.userService = userService;
    }

    public List<Map<String, Object>> getForTeacher(Long teacherId) {
        return availabilityRepository.findByTeacher_IdOrderByDayOfWeekAscStartTimeAsc(teacherId)
            .stream().map(this::toPayload).collect(Collectors.toList());
    }

    public Map<String, Object> addWindow(String teacherEmail, DayOfWeek dayOfWeek, LocalTime startTime, LocalTime endTime) {
        if (!startTime.isBefore(endTime)) {
            throw new RuntimeException("Start time must be before end time.");
        }

        User teacher = userService.findByEmail(teacherEmail);
        List<TeacherAvailability> existing = availabilityRepository.findByTeacher_IdOrderByDayOfWeekAscStartTimeAsc(teacher.getId());

        boolean overlaps = existing.stream()
            .filter(w -> w.getDayOfWeek() == dayOfWeek)
            .anyMatch(w -> startTime.isBefore(w.getEndTime()) && w.getStartTime().isBefore(endTime));
        if (overlaps) {
            throw new RuntimeException("This overlaps with an existing availability window on that day.");
        }

        TeacherAvailability window = new TeacherAvailability();
        window.setTeacher(teacher);
        window.setDayOfWeek(dayOfWeek);
        window.setStartTime(startTime);
        window.setEndTime(endTime);
        availabilityRepository.save(window);

        return toPayload(window);
    }

    public void removeWindow(String teacherEmail, Long windowId) {
        User teacher = userService.findByEmail(teacherEmail);
        availabilityRepository.deleteByIdAndTeacher_Id(windowId, teacher.getId());
    }

    private Map<String, Object> toPayload(TeacherAvailability w) {
        Map<String, Object> map = new LinkedHashMap<>();
        map.put("id", w.getId());
        map.put("dayOfWeek", w.getDayOfWeek().toString());
        map.put("startTime", w.getStartTime().toString());
        map.put("endTime", w.getEndTime().toString());
        return map;
    }
}
