package com.edulinkgh.services;

import com.edulinkgh.models.Referral;
import com.edulinkgh.models.Subscription;
import com.edulinkgh.models.User;
import com.edulinkgh.repositories.ReferralRepository;
import com.edulinkgh.repositories.SubscriptionRepository;
import com.edulinkgh.repositories.UserRepository;
import org.springframework.stereotype.Service;

import java.security.SecureRandom;
import java.time.LocalDateTime;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class ReferralService {

    private static final int REFERRALS_PER_REWARD = 80;
    private static final int REWARD_DAYS = 1; // 1 free day of Plus per 80 referrals

    private final ReferralRepository referralRepository;
    private final UserRepository userRepository;
    private final SubscriptionRepository subscriptionRepository;
    private final UserService userService;

    private static final SecureRandom RANDOM = new SecureRandom();
    private static final String CODE_CHARS = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"; // no O/0/I/1 — avoids visual ambiguity when shared verbally/in print

    public ReferralService(ReferralRepository referralRepository, UserRepository userRepository,
                            SubscriptionRepository subscriptionRepository, UserService userService) {
        this.referralRepository = referralRepository;
        this.userRepository = userRepository;
        this.subscriptionRepository = subscriptionRepository;
        this.userService = userService;
    }

    /** Generates a stable, unique referral code for a newly-registered user. Called once from AuthService.register. */
    public String generateReferralCode() {
        String code;
        do {
            code = randomCode(7);
        } while (userRepository.findByReferralCode(code).isPresent());
        return code;
    }

    private String randomCode(int length) {
        StringBuilder sb = new StringBuilder(length);
        for (int i = 0; i < length; i++) {
            sb.append(CODE_CHARS.charAt(RANDOM.nextInt(CODE_CHARS.length())));
        }
        return sb.toString();
    }

    /**
     * Records a referral if the given code is valid and the new user hasn't
     * already been referred by someone else. Called from AuthService.register
     * right after the new user account is persisted (so refereeId exists).
     * Silently no-ops on an invalid/self-referral code rather than failing
     * registration — a bad referral code should never block someone from
     * signing up.
     */
    public void recordReferralIfValid(String referralCode, User newUser) {
        if (referralCode == null || referralCode.isBlank()) return;
        if (referralRepository.existsByReferee_Id(newUser.getId())) return; // already attributed (shouldn't happen at signup, but safe)

        userRepository.findByReferralCode(referralCode.trim().toUpperCase()).ifPresent(referrer -> {
            if (referrer.getId().equals(newUser.getId())) return; // can't refer yourself

            Referral referral = new Referral();
            referral.setReferrer(referrer);
            referral.setReferee(newUser);
            referralRepository.save(referral);

            grantRewardIfThresholdReached(referrer.getId());
        });
    }

    /**
     * Checks whether the referrer has accumulated REFERRALS_PER_REWARD
     * ungranted referrals and, if so, grants one reward and marks exactly
     * that many referrals as rewarded — consuming them so the count resets
     * cleanly for the next batch, rather than re-triggering on every
     * referral once the threshold is first crossed.
     */
    private void grantRewardIfThresholdReached(Long referrerId) {
        long ungranted = referralRepository.countByReferrer_IdAndRewardGrantedFalse(referrerId);
        if (ungranted < REFERRALS_PER_REWARD) return;

        User referrer = userRepository.findById(referrerId).orElse(null);
        if (referrer == null) return;

        List<Referral> toConsume = referralRepository.findByReferrer_IdOrderByCreatedAtDesc(referrerId).stream()
            .filter(r -> !r.isRewardGranted())
            .limit(REFERRALS_PER_REWARD)
            .collect(Collectors.toList());
        toConsume.forEach(r -> r.setRewardGranted(true));
        referralRepository.saveAll(toConsume);

        grantFreeDays(referrer, REWARD_DAYS);
    }

    /**
     * Grants free Plus days by extending an existing active subscription's
     * expiry, or creating a fresh short PLUS subscription if the user has
     * none. This reuses the same Subscription rows SubscriptionService
     * reads from (getCurrentPlan), so a referral reward and a paid
     * subscription behave identically from every other feature's
     * perspective — nothing else needs to know a subscription came from a
     * referral versus a real purchase.
     */
    private void grantFreeDays(User user, int days) {
        var existingActive = subscriptionRepository.findTopByUser_IdAndStatusOrderByExpiresAtDesc(user.getId(), Subscription.Status.ACTIVE)
            .filter(s -> s.getExpiresAt().isAfter(LocalDateTime.now()));

        if (existingActive.isPresent()) {
            Subscription sub = existingActive.get();
            sub.setExpiresAt(sub.getExpiresAt().plusDays(days));
            subscriptionRepository.save(sub);
        } else {
            Subscription sub = new Subscription();
            sub.setUser(user);
            sub.setPlan(Subscription.Plan.PLUS);
            sub.setStatus(Subscription.Status.ACTIVE);
            sub.setStartedAt(LocalDateTime.now());
            sub.setExpiresAt(LocalDateTime.now().plusDays(days));
            sub.setPaymentId(null); // no payment — this is a referral reward, not a purchase
            subscriptionRepository.save(sub);
        }
    }

    public Map<String, Object> getMyReferralStats(String userEmail) {
        User user = userService.findByEmail(userEmail);
        long total = referralRepository.countByReferrer_Id(user.getId());
        long ungranted = referralRepository.countByReferrer_IdAndRewardGrantedFalse(user.getId());
        long rewardsEarned = (total - ungranted) / REFERRALS_PER_REWARD;

        Map<String, Object> result = new LinkedHashMap<>();
        result.put("referralCode", user.getReferralCode());
        result.put("totalReferrals", total);
        result.put("progressTowardNextReward", ungranted);
        result.put("referralsPerReward", REFERRALS_PER_REWARD);
        result.put("rewardsEarned", rewardsEarned);
        return result;
    }
}
