package com.edulinkgh.services;

import com.edulinkgh.ai.AiTutorProvider;
import com.edulinkgh.models.User;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class AiTeacherMatchingService {

    private final AiTutorProvider provider;
    private final UserService userService;
    private final SubscriptionService subscriptionService;
    private final ObjectMapper objectMapper = new ObjectMapper();

    // Simple in-memory per-user rate limiting (no DB table needed for this
    // one — matching isn't something a student would reasonably do dozens
    // of times a day, so a lightweight in-memory window is enough; unlike
    // the homework/quiz limits, losing this on a server restart is fine).
    private final Map<Long, List<LocalDateTime>> requestLog = new HashMap<>();

    private static final int MAX_REQUEST_LENGTH = 500;

    public AiTeacherMatchingService(AiTutorProvider provider, UserService userService,
                                     SubscriptionService subscriptionService) {
        this.provider = provider;
        this.userService = userService;
        this.subscriptionService = subscriptionService;
    }

    public List<Map<String, Object>> matchTeachers(String studentEmail, String request) {
        if (!provider.isAvailable()) {
            throw new RuntimeException("Teacher matching isn't available right now. Please try again later.");
        }
        if (request == null || request.isBlank()) {
            throw new RuntimeException("Describe what you're looking for first.");
        }
        if (request.length() > MAX_REQUEST_LENGTH) {
            throw new RuntimeException("That's a bit long — try a shorter, more specific description.");
        }

        User student = userService.findByEmail(studentEmail);
        enforceRateLimit(student.getId());

        List<Map<String, Object>> candidates = userService.getAllTeachers(null, null, null, null);
        if (candidates.isEmpty()) {
            return List.of();
        }

        String candidatesDescription = buildCandidatesDescription(candidates);
        String rawJson = provider.matchTeachers(request.trim(), candidatesDescription);

        return parseAndEnrich(rawJson, candidates);
    }

    private void enforceRateLimit(Long studentId) {
        int limit = subscriptionService.getCurrentPlanDefinition(studentId).aiMatchDailyLimit();
        LocalDateTime cutoff = LocalDateTime.now().minus(24, ChronoUnit.HOURS);
        List<LocalDateTime> log = requestLog.computeIfAbsent(studentId, k -> new ArrayList<>());
        log.removeIf(t -> t.isBefore(cutoff));
        if (log.size() >= limit) {
            throw new RuntimeException("You've reached today's limit of " + limit + " matching requests. Upgrade your plan for a higher limit, or try again tomorrow.");
        }
        log.add(LocalDateTime.now());
    }

    private String buildCandidatesDescription(List<Map<String, Object>> candidates) {
        StringBuilder sb = new StringBuilder();
        for (Map<String, Object> t : candidates) {
            sb.append("teacherId: ").append(t.get("id"))
              .append(", subject: ").append(orNone(t.get("subject")))
              .append(", level: ").append(orNone(t.get("teachingLevel")))
              .append(", qualification: ").append(orNone(t.get("qualification")))
              .append(", rating: ").append(orNone(t.get("averageRating")))
              .append(", bio: ").append(orNone(t.get("bio")))
              .append("\n");
        }
        return sb.toString();
    }

    private String orNone(Object value) {
        return value == null || value.toString().isBlank() ? "not specified" : value.toString();
    }

    /**
     * Parses the model's response and cross-checks every returned teacherId
     * against the actual candidate set — the model is told never to invent
     * an ID, but "told" is not "guaranteed", so anything not in the real
     * candidate list is silently dropped rather than shown to the student.
     */
    private List<Map<String, Object>> parseAndEnrich(String rawJson, List<Map<String, Object>> candidates) {
        Map<Object, Map<String, Object>> byId = candidates.stream()
            .collect(Collectors.toMap(t -> t.get("id"), t -> t, (a, b) -> a));

        JsonNode root;
        try {
            root = objectMapper.readTree(rawJson);
        } catch (Exception e) {
            throw new RuntimeException("Could not process matching results. Please try again.");
        }

        JsonNode matches = root.get("matches");
        if (matches == null || !matches.isArray()) {
            return List.of();
        }

        List<Map<String, Object>> results = new ArrayList<>();
        for (JsonNode match : matches) {
            JsonNode idNode = match.get("teacherId");
            JsonNode reasonNode = match.get("reason");
            if (idNode == null || !idNode.isNumber()) continue;

            // The candidate map is keyed by Long (User.getId()'s return type),
            // so normalize the JSON number the same way before looking it up.
            long id = idNode.asLong();
            Map<String, Object> teacher = byId.get(id);
            if (teacher == null) {
                continue; // model returned an ID that isn't a real candidate — drop it, never show it
            }

            Map<String, Object> enriched = new LinkedHashMap<>(teacher);
            enriched.put("matchReason", reasonNode != null && reasonNode.isTextual() ? reasonNode.asText() : "");
            results.add(enriched);

            if (results.size() >= 5) break;
        }

        return results;
    }
}
