package com.edulinkgh.services;

import com.edulinkgh.models.DeviceToken;
import com.edulinkgh.models.User;
import com.edulinkgh.repositories.DeviceTokenRepository;
import com.edulinkgh.repositories.UserRepository;
import com.google.firebase.FirebaseApp;
import com.google.firebase.messaging.FirebaseMessaging;
import com.google.firebase.messaging.FirebaseMessagingException;
import com.google.firebase.messaging.Message;
import com.google.firebase.messaging.MessagingErrorCode;
import com.google.firebase.messaging.Notification;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class PushNotificationService {

    private static final Logger log = LoggerFactory.getLogger(PushNotificationService.class);

    private final DeviceTokenRepository deviceTokenRepository;
    private final UserRepository userRepository;
    private final FirebaseApp firebaseApp; // null when Firebase isn't configured yet — see FirebaseConfig

    public PushNotificationService(DeviceTokenRepository deviceTokenRepository,
                                    UserRepository userRepository,
                                    FirebaseApp firebaseApp) {
        this.deviceTokenRepository = deviceTokenRepository;
        this.userRepository = userRepository;
        this.firebaseApp = firebaseApp;
    }

    public void registerToken(Long userId, String fcmToken, String platform) {
        User user = userRepository.findById(userId)
            .orElseThrow(() -> new RuntimeException("User not found."));

        // Re-registering an existing token (e.g. re-login on the same device) just updates ownership.
        DeviceToken token = deviceTokenRepository.findByFcmToken(fcmToken).orElseGet(DeviceToken::new);
        token.setUser(user);
        token.setFcmToken(fcmToken);
        token.setPlatform(DeviceToken.Platform.valueOf(platform.toUpperCase()));
        deviceTokenRepository.save(token);
    }

    public void unregisterToken(String fcmToken) {
        deviceTokenRepository.deleteByFcmToken(fcmToken);
    }

    /** Sends a notification to every device registered for a user. Silently no-ops if Firebase isn't configured. */
    public void sendToUser(Long userId, String title, String body, Map<String, String> data) {
        if (firebaseApp == null) {
            log.debug("Firebase not configured — skipping push to user {}", userId);
            return;
        }

        List<DeviceToken> tokens = deviceTokenRepository.findByUser_Id(userId);
        for (DeviceToken deviceToken : tokens) {
            Message message = Message.builder()
                .setToken(deviceToken.getFcmToken())
                .setNotification(Notification.builder().setTitle(title).setBody(body).build())
                .putAllData(data != null ? data : Map.of())
                .build();

            try {
                FirebaseMessaging.getInstance(firebaseApp).send(message);
            } catch (FirebaseMessagingException e) {
                if (e.getMessagingErrorCode() == MessagingErrorCode.UNREGISTERED
                    || e.getMessagingErrorCode() == MessagingErrorCode.INVALID_ARGUMENT) {
                    // Token is stale (app uninstalled, token rotated) — remove it so we stop retrying.
                    deviceTokenRepository.deleteByFcmToken(deviceToken.getFcmToken());
                } else {
                    log.warn("Push send failed for user {}: {}", userId, e.getMessage());
                }
            }
        }
    }
}

