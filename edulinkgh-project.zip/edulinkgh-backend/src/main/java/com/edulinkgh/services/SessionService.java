package com.edulinkgh.services;

import com.edulinkgh.models.Session;
import com.edulinkgh.models.TeacherAvailability;
import com.edulinkgh.models.User;
import com.edulinkgh.repositories.SessionRepository;
import com.edulinkgh.repositories.TeacherAvailabilityRepository;
import com.edulinkgh.repositories.UserRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class SessionService {

    private final SessionRepository sessionRepository;
    private final UserRepository    userRepository;
    private final UserService       userService;
    private final TeacherAvailabilityRepository availabilityRepository;
    private final SubscriptionService subscriptionService;

    public SessionService(SessionRepository sessionRepository,
                          UserRepository userRepository,
                          UserService userService,
                          TeacherAvailabilityRepository availabilityRepository,
                          SubscriptionService subscriptionService) {
        this.sessionRepository = sessionRepository;
        this.userRepository    = userRepository;
        this.userService       = userService;
        this.availabilityRepository = availabilityRepository;
        this.subscriptionService = subscriptionService;
    }

    public Map<String, Object> createSession(String teacherEmail, Map<String, Object> body) {
        User teacher = userService.findByEmail(teacherEmail);

        LocalDateTime scheduledAt = LocalDateTime.parse((String) body.get("scheduledAt"));
        int durationMinutes = (Integer) body.getOrDefault("durationMinutes", 60);

        validateAgainstAvailability(teacher.getId(), scheduledAt, durationMinutes);

        Session session = Session.builder()
            .subject((String) body.get("subject"))
            .description((String) body.getOrDefault("description", ""))
            .scheduledAt(scheduledAt)
            .durationMinutes(durationMinutes)
            .feeGhc(((Number) body.getOrDefault("feeGhc", 0)).doubleValue())
            .teacher(teacher)
            .status(Session.SessionStatus.UPCOMING)
            .build();
        sessionRepository.save(session);
        return buildSessionMap(session);
    }

    /**
     * Only enforced if the teacher has set up ANY availability windows at all —
     * a teacher who hasn't configured availability yet can still create
     * sessions freely, so this feature doesn't retroactively lock out
     * existing teachers or force setup before their first session.
     */
    private void validateAgainstAvailability(Long teacherId, LocalDateTime scheduledAt, int durationMinutes) {
        List<TeacherAvailability> windows = availabilityRepository.findByTeacher_IdOrderByDayOfWeekAscStartTimeAsc(teacherId);
        if (windows.isEmpty()) {
            return;
        }

        LocalTime sessionStart = scheduledAt.toLocalTime();
        LocalTime sessionEnd = sessionStart.plusMinutes(durationMinutes);
        boolean crossesMidnight = sessionEnd.isBefore(sessionStart);

        boolean fitsWithinAWindow = windows.stream()
            .filter(w -> w.getDayOfWeek() == scheduledAt.getDayOfWeek())
            .anyMatch(w -> !crossesMidnight
                && !sessionStart.isBefore(w.getStartTime())
                && !sessionEnd.isAfter(w.getEndTime()));

        if (!fitsWithinAWindow) {
            throw new RuntimeException(
                "This time falls outside your stated availability for " + scheduledAt.getDayOfWeek() + ". " +
                "Adjust the time, or update your availability first."
            );
        }
    }

    public List<Map<String, Object>> getUpcomingSessions() {
        return sessionRepository.findUpcomingAndLive()
            .stream().map(this::buildSessionMap).toList();
    }

    public List<Map<String, Object>> getTeacherSessions(String teacherEmail) {
        User teacher = userService.findByEmail(teacherEmail);
        return sessionRepository.findByTeacher(teacher)
            .stream().map(this::buildSessionMap).toList();
    }

    public List<Map<String, Object>> getStudentSessions(String studentEmail) {
        User student = userService.findByEmail(studentEmail);
        return sessionRepository.findByEnrolledStudent(student)
            .stream().map(this::buildSessionMap).toList();
    }

    public Map<String, Object> getSession(Long id) {
        return buildSessionMap(findById(id));
    }

    public Map<String, String> enrollStudent(Long sessionId, String studentEmail) {
        Session session = findById(sessionId);
        User student    = userService.findByEmail(studentEmail);
        if (session.getStatus() == Session.SessionStatus.CANCELLED) {
            throw new RuntimeException("Cannot enroll in a cancelled session.");
        }
        if (session.getEnrolledStudents().contains(student)) {
            throw new RuntimeException("Already enrolled in this session.");
        }

        checkPriorityBookingWindow(session, student);

        session.getEnrolledStudents().add(student);
        sessionRepository.save(session);
        return Map.of("message", "Enrolled successfully in " + session.getSubject());
    }

    /**
     * Staggered priority booking: higher-tier plans can book a newly-created
     * session before lower tiers can. Concretely, with Pro=15min and
     * Plus=10min priority windows (see SubscriptionPlanCatalog): Pro can
     * book from minute 0, Plus can book starting at minute (15-10)=5 — i.e.
     * once only 10 minutes remain in Pro's exclusive window — and everyone
     * (Free included) can book once the full window (15 min) has elapsed.
     * Plan windows are kept in a strict nesting order (Pro's window always
     * fully contains Plus's, which is contained in the "everyone" window);
     * tierWindowsDesc/maxPriorityMinutes below derive that nesting directly
     * from the catalog rather than hardcoding it, so changing the catalog's
     * numbers doesn't require touching this method.
     */
    private void checkPriorityBookingWindow(Session session, User student) {
        List<Integer> tierWindowsDesc = com.edulinkgh.subscriptions.SubscriptionPlanCatalog.all().values().stream()
            .map(com.edulinkgh.subscriptions.SubscriptionPlanCatalog.PlanDefinition::priorityBookingMinutes)
            .filter(m -> m > 0)
            .distinct()
            .sorted(Comparator.reverseOrder())
            .collect(Collectors.toList());
        if (tierWindowsDesc.isEmpty() || session.getCreatedAt() == null) {
            return; // no priority feature configured, or session predates this field — nothing to enforce
        }

        int maxPriorityMinutes = tierWindowsDesc.get(0);
        long minutesSinceCreated = java.time.Duration.between(session.getCreatedAt(), LocalDateTime.now()).toMinutes();
        if (minutesSinceCreated >= maxPriorityMinutes) {
            return; // the whole priority window has elapsed — open to everyone
        }

        int myPriorityMinutes = subscriptionService.getCurrentPlanDefinition(student.getId()).priorityBookingMinutes();
        if (myPriorityMinutes >= maxPriorityMinutes) {
            return; // top tier — always allowed within the window
        }

        long myUnlockAtMinutes = maxPriorityMinutes - myPriorityMinutes;
        if (minutesSinceCreated < myUnlockAtMinutes) {
            long minutesRemaining = myUnlockAtMinutes - minutesSinceCreated;
            throw new RuntimeException(
                "This session is currently in a priority booking window for higher-tier subscribers. " +
                "You can book it in " + minutesRemaining + " minute(s), or upgrade your plan for earlier access."
            );
        }
    }

    public Map<String, Object> startSession(Long sessionId, String teacherEmail) {
        Session session = findById(sessionId);
        User teacher    = userService.findByEmail(teacherEmail);
        if (!session.getTeacher().getId().equals(teacher.getId())) {
            throw new RuntimeException("You can only start your own sessions.");
        }
        session.setStatus(Session.SessionStatus.LIVE);
        session.setMeetingLink("https://meet.edulinkgh.com/session/" + sessionId);
        sessionRepository.save(session);
        return buildSessionMap(session);
    }

    public Map<String, Object> endSession(Long sessionId, String teacherEmail) {
        Session session = findById(sessionId);
        User teacher    = userService.findByEmail(teacherEmail);
        if (!session.getTeacher().getId().equals(teacher.getId())) {
            throw new RuntimeException("You can only end your own sessions.");
        }
        session.setStatus(Session.SessionStatus.COMPLETED);
        sessionRepository.save(session);
        return buildSessionMap(session);
    }

    public Map<String, String> cancelSession(Long sessionId, String userEmail) {
        Session session = findById(sessionId);
        User caller = userService.findByEmail(userEmail);

        boolean isOwningTeacher = session.getTeacher().getId().equals(caller.getId());
        boolean isEnrolledStudent = session.getEnrolledStudents().stream()
            .anyMatch(s -> s.getId().equals(caller.getId()));

        if (!isOwningTeacher && !isEnrolledStudent) {
            throw new RuntimeException("You do not have permission to cancel this session.");
        }

        if (isOwningTeacher) {
            session.setStatus(Session.SessionStatus.CANCELLED);
            sessionRepository.save(session);
            return Map.of("message", "Session cancelled.");
        }

        // An enrolled student "cancelling" just withdraws their own enrollment
        // rather than cancelling the whole session for everyone else.
        session.getEnrolledStudents().removeIf(s -> s.getId().equals(caller.getId()));
        sessionRepository.save(session);
        return Map.of("message", "You have been removed from this session.");
    }

    private Map<String, Object> buildSessionMap(Session s) {
        User t = s.getTeacher();
        Map<String, Object> map = new LinkedHashMap<>();
        map.put("id",             s.getId());
        map.put("subject",        s.getSubject());
        map.put("description",    s.getDescription() != null ? s.getDescription() : "");
        map.put("scheduledAt",    s.getScheduledAt().toString());
        map.put("durationMinutes",s.getDurationMinutes());
        map.put("status",         s.getStatus().name());
        map.put("enrolledCount",  s.getEnrolledStudents().size());
        map.put("feeGhc",         s.getFeeGhc());
        map.put("meetingLink",    s.getMeetingLink() != null ? s.getMeetingLink() : "");
        Map<String, Object> teacherMap = new LinkedHashMap<>();
        teacherMap.put("id",            t.getId());
        teacherMap.put("fullName",       t.getFullName());
        teacherMap.put("subject",        t.getSubject() != null ? t.getSubject() : "");
        teacherMap.put("qualification",  t.getQualification() != null ? t.getQualification() : "");
        map.put("teacher",        teacherMap);
        map.put("createdAt",      s.getCreatedAt() != null ? s.getCreatedAt().toString() : "");
        return map;
    }

    public Session findById(Long id) {
        return sessionRepository.findById(id)
            .orElseThrow(() -> new RuntimeException("Session not found: " + id));
    }
}
