package com.edulinkgh.services;

import com.edulinkgh.analytics.TimeSeriesBuilder;
import com.edulinkgh.analytics.TimeSeriesBuilder.DataPoint;
import com.edulinkgh.models.Payment;
import com.edulinkgh.models.Session;
import com.edulinkgh.repositories.PaymentRepository;
import com.edulinkgh.repositories.SessionRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class AdminAnalyticsService {

    private final PaymentRepository paymentRepository;
    private final SessionRepository sessionRepository;

    private static final int DEFAULT_WINDOW_DAYS = 30;

    public AdminAnalyticsService(PaymentRepository paymentRepository, SessionRepository sessionRepository) {
        this.paymentRepository = paymentRepository;
        this.sessionRepository = sessionRepository;
    }

    public Map<String, Object> getRevenueOverTime(Integer days) {
        int window = (days != null && days > 0) ? days : DEFAULT_WINDOW_DAYS;
        LocalDateTime since = LocalDateTime.now().minusDays(window - 1L).toLocalDate().atStartOfDay();

        List<Payment> platformFees = paymentRepository.findPlatformFeesSince(since);
        // Commission is stored as a negative amount (see PaymentService) —
        // negate it here so revenue reads as a positive number, since that's
        // what "revenue" should mean to anyone reading this endpoint.
        List<DataPoint> series = TimeSeriesBuilder.dailySeries(
            platformFees,
            p -> p.getCreatedAt().toLocalDate(),
            p -> -p.getAmountGhc(),
            window
        );

        double total = series.stream().mapToDouble(DataPoint::value).sum();

        Map<String, Object> result = new LinkedHashMap<>();
        result.put("windowDays", window);
        result.put("totalRevenueGhc", Math.round(total * 100) / 100.0);
        result.put("series", toPayload(series));
        return result;
    }

    public Map<String, Object> getSessionVolumeOverTime(Integer days) {
        int window = (days != null && days > 0) ? days : DEFAULT_WINDOW_DAYS;
        LocalDateTime since = LocalDateTime.now().minusDays(window - 1L).toLocalDate().atStartOfDay();

        List<Session> sessions = sessionRepository.findScheduledSince(since);

        List<DataPoint> totalSeries = TimeSeriesBuilder.dailyCounts(sessions, s -> s.getScheduledAt().toLocalDate(), window);
        List<DataPoint> completedSeries = TimeSeriesBuilder.dailyCounts(
            sessions.stream().filter(s -> s.getStatus() == Session.SessionStatus.COMPLETED).collect(Collectors.toList()),
            s -> s.getScheduledAt().toLocalDate(), window
        );
        List<DataPoint> cancelledSeries = TimeSeriesBuilder.dailyCounts(
            sessions.stream().filter(s -> s.getStatus() == Session.SessionStatus.CANCELLED).collect(Collectors.toList()),
            s -> s.getScheduledAt().toLocalDate(), window
        );

        Map<String, Object> result = new LinkedHashMap<>();
        result.put("windowDays", window);
        result.put("totalSessions", sessions.size());
        result.put("scheduledSeries", toPayload(totalSeries));
        result.put("completedSeries", toPayload(completedSeries));
        result.put("cancelledSeries", toPayload(cancelledSeries));
        return result;
    }

    private List<Map<String, Object>> toPayload(List<DataPoint> series) {
        return series.stream().map(dp -> {
            Map<String, Object> point = new LinkedHashMap<>();
            point.put("date", dp.date().toString());
            point.put("value", dp.value());
            return point;
        }).collect(Collectors.toList());
    }
}
