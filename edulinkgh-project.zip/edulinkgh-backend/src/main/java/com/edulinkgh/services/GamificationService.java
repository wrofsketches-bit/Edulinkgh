package com.edulinkgh.services;

import com.edulinkgh.gamification.AchievementCatalog;
import com.edulinkgh.gamification.StudentActivityStats;
import com.edulinkgh.models.Session;
import com.edulinkgh.models.StudentAchievement;
import com.edulinkgh.models.User;
import com.edulinkgh.repositories.RatingRepository;
import com.edulinkgh.repositories.SessionRepository;
import com.edulinkgh.repositories.StudentAchievementRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class GamificationService {

    private final SessionRepository sessionRepository;
    private final RatingRepository ratingRepository;
    private final StudentAchievementRepository achievementRepository;
    private final UserService userService;

    public GamificationService(SessionRepository sessionRepository, RatingRepository ratingRepository,
                                StudentAchievementRepository achievementRepository, UserService userService) {
        this.sessionRepository = sessionRepository;
        this.ratingRepository = ratingRepository;
        this.achievementRepository = achievementRepository;
        this.userService = userService;
    }

    /**
     * Computes current stats, unlocks any newly-earned achievements (persisting
     * them so the unlock date is permanent), and returns everything the
     * mobile app needs to render the streaks/achievements screen in one call.
     */
    public Map<String, Object> getProgress(String studentEmail) {
        User student = userService.findByEmail(studentEmail);

        List<Session> completed = sessionRepository.findByEnrolledStudent(student).stream()
            .filter(s -> s.getStatus() == Session.SessionStatus.COMPLETED)
            .collect(Collectors.toList());

        List<LocalDate> completionDates = completed.stream()
            .map(s -> s.getScheduledAt().toLocalDate())
            .distinct()
            .sorted()
            .collect(Collectors.toList());

        int currentStreak = computeCurrentStreak(completionDates);
        int longestStreak = computeLongestStreak(completionDates);
        int distinctSubjects = (int) completed.stream().map(Session::getSubject).filter(Objects::nonNull).distinct().count();
        long ratingsGiven = ratingRepository.findByStudent(student).size();

        StudentActivityStats stats = new StudentActivityStats(
            completed.size(), currentStreak, longestStreak, distinctSubjects, ratingsGiven
        );

        Set<String> alreadyUnlocked = achievementRepository.getUnlockedAchievementIds(student.getId());
        List<Map<String, Object>> newlyUnlocked = new ArrayList<>();

        for (AchievementCatalog.Achievement achievement : AchievementCatalog.ALL) {
            if (alreadyUnlocked.contains(achievement.id())) continue;
            if (achievement.criteria().test(stats)) {
                StudentAchievement record = new StudentAchievement();
                record.setStudent(student);
                record.setAchievementId(achievement.id());
                achievementRepository.save(record);
                newlyUnlocked.add(toAchievementPayload(achievement, true));
                alreadyUnlocked.add(achievement.id());
            }
        }

        List<Map<String, Object>> allAchievements = AchievementCatalog.ALL.stream()
            .map(a -> toAchievementPayload(a, alreadyUnlocked.contains(a.id())))
            .collect(Collectors.toList());

        Map<String, Object> result = new LinkedHashMap<>();
        result.put("completedSessionCount", stats.completedSessionCount());
        result.put("currentStreakDays", stats.currentStreakDays());
        result.put("longestStreakDays", stats.longestStreakDays());
        result.put("achievements", allAchievements);
        result.put("newlyUnlocked", newlyUnlocked);
        return result;
    }

    /**
     * A "current" streak only counts if the most recent completed-session day
     * is today or yesterday — otherwise the streak is broken (0), even if
     * there was a long run of consecutive days further in the past. That
     * older run still counts toward longestStreakDays, just not currentStreakDays.
     */
    private int computeCurrentStreak(List<LocalDate> sortedDistinctDates) {
        if (sortedDistinctDates.isEmpty()) return 0;

        LocalDate today = LocalDate.now();
        LocalDate mostRecent = sortedDistinctDates.get(sortedDistinctDates.size() - 1);
        if (mostRecent.isBefore(today.minusDays(1))) {
            return 0; // most recent activity was more than a day ago — streak is broken
        }

        int streak = 1;
        for (int i = sortedDistinctDates.size() - 1; i > 0; i--) {
            LocalDate current = sortedDistinctDates.get(i);
            LocalDate previous = sortedDistinctDates.get(i - 1);
            if (previous.equals(current.minusDays(1))) {
                streak++;
            } else {
                break;
            }
        }
        return streak;
    }

    private int computeLongestStreak(List<LocalDate> sortedDistinctDates) {
        if (sortedDistinctDates.isEmpty()) return 0;

        int longest = 1;
        int current = 1;
        for (int i = 1; i < sortedDistinctDates.size(); i++) {
            if (sortedDistinctDates.get(i).equals(sortedDistinctDates.get(i - 1).plusDays(1))) {
                current++;
                longest = Math.max(longest, current);
            } else {
                current = 1;
            }
        }
        return longest;
    }

    private Map<String, Object> toAchievementPayload(AchievementCatalog.Achievement achievement, boolean unlocked) {
        Map<String, Object> map = new LinkedHashMap<>();
        map.put("id", achievement.id());
        map.put("title", achievement.title());
        map.put("description", achievement.description());
        map.put("icon", achievement.icon());
        map.put("unlocked", unlocked);
        return map;
    }
}
