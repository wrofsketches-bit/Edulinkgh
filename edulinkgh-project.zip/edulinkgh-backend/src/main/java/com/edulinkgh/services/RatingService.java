package com.edulinkgh.services;

import com.edulinkgh.models.Rating;
import com.edulinkgh.models.User;
import com.edulinkgh.repositories.RatingRepository;
import com.edulinkgh.repositories.UserRepository;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class RatingService {

    private final RatingRepository ratingRepository;
    private final UserRepository   userRepository;
    private final UserService      userService;

    public RatingService(RatingRepository ratingRepository,
                         UserRepository userRepository,
                         UserService userService) {
        this.ratingRepository = ratingRepository;
        this.userRepository   = userRepository;
        this.userService      = userService;
    }

    public Map<String, Object> rateTeacher(String studentEmail, Long teacherId,
                                            int stars, String comment) {
        User student = userService.findByEmail(studentEmail);
        User teacher = userRepository.findById(teacherId)
            .orElseThrow(() -> new RuntimeException("Teacher not found."));
        if (teacher.getRole() != User.Role.TEACHER) {
            throw new RuntimeException("You can only rate teachers.");
        }
        if (student.getId().equals(teacher.getId())) {
            throw new RuntimeException("You cannot rate yourself.");
        }
        if (stars < 1 || stars > 5) {
            throw new RuntimeException("Rating must be between 1 and 5 stars.");
        }
        Rating rating = ratingRepository.findByStudentAndTeacher(student, teacher)
            .orElse(Rating.builder().student(student).teacher(teacher).build());
        rating.setStars(stars);
        rating.setComment(comment);
        ratingRepository.save(rating);

        Double avg   = ratingRepository.findAverageRatingByTeacher(teacher);
        Long   count = ratingRepository.countByTeacher(teacher);

        Map<String, Object> result = new LinkedHashMap<>();
        result.put("message",       "Rating submitted successfully.");
        result.put("averageRating", avg   != null ? Math.round(avg*10.0)/10.0 : 0.0);
        result.put("reviewCount",   count != null ? count : 0L);
        return result;
    }

    public List<Map<String, Object>> getTeacherRatings(Long teacherId) {
        User teacher = userRepository.findById(teacherId)
            .orElseThrow(() -> new RuntimeException("Teacher not found."));
        List<Map<String, Object>> list = new ArrayList<>();
        for (Rating r : ratingRepository.findByTeacher(teacher)) {
            Map<String, Object> m = new LinkedHashMap<>();
            m.put("id",          r.getId());
            m.put("studentName", r.getStudent().getFullName());
            m.put("stars",       r.getStars());
            m.put("comment",     r.getComment() != null ? r.getComment() : "");
            m.put("createdAt",   r.getCreatedAt() != null ? r.getCreatedAt().toString() : "");
            list.add(m);
        }
        return list;
    }

    public Map<String, Object> getRatingStatus(String studentEmail, Long teacherId) {
        User student = userService.findByEmail(studentEmail);
        User teacher = userRepository.findById(teacherId)
            .orElseThrow(() -> new RuntimeException("Teacher not found."));
        boolean hasRated = ratingRepository.existsByStudentAndTeacher(student, teacher);
        return Map.of("hasRated", hasRated);
    }
}
