package com.edulinkgh.services;

import com.edulinkgh.models.Payment;
import com.edulinkgh.models.Subscription;
import com.edulinkgh.models.User;
import com.edulinkgh.payments.PaymentProvider;
import com.edulinkgh.repositories.PaymentRepository;
import com.edulinkgh.repositories.SubscriptionRepository;
import com.edulinkgh.subscriptions.SubscriptionPlanCatalog;
import com.edulinkgh.subscriptions.SubscriptionPlanCatalog.PlanDefinition;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@Service
public class SubscriptionService {

    private final SubscriptionRepository subscriptionRepository;
    private final PaymentRepository paymentRepository;
    private final UserService userService;
    private final PaymentProvider paymentProvider;

    public SubscriptionService(SubscriptionRepository subscriptionRepository, PaymentRepository paymentRepository,
                                UserService userService, PaymentProvider paymentProvider) {
        this.subscriptionRepository = subscriptionRepository;
        this.paymentRepository = paymentRepository;
        this.userService = userService;
        this.paymentProvider = paymentProvider;
    }

    /**
     * The plan a user is currently entitled to. Defaults to FREE if there is
     * no active, unexpired subscription row — this is the single source of
     * truth other services (AiTutorService, booking) should call to decide
     * limits/priority access, rather than each maintaining its own notion
     * of "what plan is this user on".
     */
    public Subscription.Plan getCurrentPlan(Long userId) {
        return subscriptionRepository.findTopByUser_IdAndStatusOrderByExpiresAtDesc(userId, Subscription.Status.ACTIVE)
            .filter(s -> s.getExpiresAt().isAfter(LocalDateTime.now()))
            .map(Subscription::getPlan)
            .orElse(Subscription.Plan.FREE);
    }

    public PlanDefinition getCurrentPlanDefinition(Long userId) {
        return SubscriptionPlanCatalog.get(getCurrentPlan(userId));
    }

    public Map<String, Object> getPlans() {
        Map<String, Object> result = new LinkedHashMap<>();
        for (PlanDefinition def : SubscriptionPlanCatalog.all().values()) {
            result.put(def.plan().name(), toPlanPayload(def));
        }
        return result;
    }

    public Map<String, Object> getMySubscription(String userEmail) {
        User user = userService.findByEmail(userEmail);
        Subscription.Plan currentPlan = getCurrentPlan(user.getId());
        var active = subscriptionRepository.findTopByUser_IdAndStatusOrderByExpiresAtDesc(user.getId(), Subscription.Status.ACTIVE)
            .filter(s -> s.getExpiresAt().isAfter(LocalDateTime.now()));

        Map<String, Object> result = new LinkedHashMap<>();
        result.put("plan", currentPlan.name());
        result.put("expiresAt", active.map(s -> s.getExpiresAt().toString()).orElse(null));
        result.put("planDetails", toPlanPayload(SubscriptionPlanCatalog.get(currentPlan)));
        return result;
    }

    /**
     * Starts a subscription purchase: creates a PENDING Payment (reusing the
     * exact same provider-backed init/confirm pattern as session payments —
     * see PaymentService), returns a checkout URL. The subscription itself
     * is only activated in confirmSubscription() once the provider verifies
     * the charge actually succeeded.
     */
    public Map<String, Object> initiateSubscription(String userEmail, String planName) {
        User user = userService.findByEmail(userEmail);
        Subscription.Plan plan = parsePlan(planName);
        if (plan == Subscription.Plan.FREE) {
            throw new RuntimeException("The free plan doesn't require a purchase.");
        }

        PlanDefinition def = SubscriptionPlanCatalog.get(plan);
        // Encode the plan directly in the reference (not just the free-text
        // description) so confirmSubscription() can recover it exactly and
        // unambiguously — parsing it back out of a human-readable
        // description string would be fragile if plan names ever overlap
        // as prefixes of each other.
        String ref = "SUB-" + plan.name() + "-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();

        Payment payment = Payment.builder()
            .user(user)
            .amountGhc(def.priceGhcPerMonth())
            .type(Payment.PaymentType.SUBSCRIPTION)
            .status(Payment.PaymentStatus.PENDING)
            .reference(ref)
            .description(def.displayName() + " subscription (1 month)")
            .build();
        paymentRepository.save(payment);

        PaymentProvider.InitResult initResult = paymentProvider.initializePayment(
            new PaymentProvider.InitRequest(ref, def.priceGhcPerMonth(), user.getEmail(), payment.getDescription())
        );
        payment.setProviderReference(initResult.providerReference());
        paymentRepository.save(payment);

        Map<String, Object> result = new LinkedHashMap<>();
        result.put("checkoutUrl", initResult.checkoutUrl());
        result.put("reference", ref);
        result.put("providerReference", initResult.providerReference());
        result.put("amount", def.priceGhcPerMonth());
        result.put("plan", plan.name());
        return result;
    }

    public Map<String, Object> confirmSubscription(String providerReference) {
        PaymentProvider.VerificationResult verification = paymentProvider.verifyPayment(providerReference);

        if (verification.status() != PaymentProvider.VerificationStatus.SUCCESS) {
            Map<String, Object> result = new LinkedHashMap<>();
            result.put("status", verification.status().name());
            result.put("message", "Payment was not successful.");
            return result;
        }

        Payment payment = paymentRepository.findByProviderReference(providerReference)
            .orElseThrow(() -> new RuntimeException("Payment record not found for this reference."));

        if (payment.getType() != Payment.PaymentType.SUBSCRIPTION) {
            throw new RuntimeException("This reference does not correspond to a subscription payment.");
        }

        if (payment.getStatus() == Payment.PaymentStatus.COMPLETED) {
            Map<String, Object> result = new LinkedHashMap<>();
            result.put("status", "SUCCESS");
            result.put("message", "Subscription already active.");
            return result;
        }

        payment.setStatus(Payment.PaymentStatus.COMPLETED);
        paymentRepository.save(payment);

        // Determine the plan from the payment's own reference (encoded as
        // "SUB-<PLAN>-xxxxxxxx" at initiateSubscription time) rather than
        // trusting a client-supplied value at confirm time or parsing the
        // free-text description — the reference is unambiguous and was
        // already fixed when the purchase started.
        Subscription.Plan plan = planFromReference(payment.getReference());

        Subscription subscription = new Subscription();
        subscription.setUser(payment.getUser());
        subscription.setPlan(plan);
        subscription.setStatus(Subscription.Status.ACTIVE);
        subscription.setStartedAt(LocalDateTime.now());
        subscription.setExpiresAt(LocalDateTime.now().plusDays(30));
        subscription.setPaymentId(payment.getId());
        subscriptionRepository.save(subscription);

        Map<String, Object> result = new LinkedHashMap<>();
        result.put("status", "SUCCESS");
        result.put("message", "Subscription activated.");
        result.put("plan", plan.name());
        result.put("expiresAt", subscription.getExpiresAt().toString());
        return result;
    }

    /** Called by a scheduled job to flip past-due ACTIVE subscriptions to EXPIRED. */
    public int expireOverdueSubscriptions() {
        List<Subscription> overdue = subscriptionRepository.findByStatusAndExpiresAtBefore(
            Subscription.Status.ACTIVE, LocalDateTime.now()
        );
        for (Subscription s : overdue) {
            s.setStatus(Subscription.Status.EXPIRED);
        }
        subscriptionRepository.saveAll(overdue);
        return overdue.size();
    }

    private Subscription.Plan parsePlan(String planName) {
        try {
            return Subscription.Plan.valueOf(planName.toUpperCase());
        } catch (Exception e) {
            throw new RuntimeException("Unknown plan: " + planName);
        }
    }

    private Subscription.Plan planFromReference(String reference) {
        // Reference format: "SUB-<PLAN>-xxxxxxxx"
        if (reference == null) {
            throw new RuntimeException("Could not determine plan from payment record.");
        }
        String[] parts = reference.split("-");
        if (parts.length < 2) {
            throw new RuntimeException("Could not determine plan from payment record.");
        }
        try {
            return Subscription.Plan.valueOf(parts[1]);
        } catch (Exception e) {
            throw new RuntimeException("Could not determine plan from payment record.");
        }
    }

    private Map<String, Object> toPlanPayload(PlanDefinition def) {
        Map<String, Object> map = new LinkedHashMap<>();
        map.put("plan", def.plan().name());
        map.put("displayName", def.displayName());
        map.put("priceGhcPerMonth", def.priceGhcPerMonth());
        map.put("aiHomeworkDailyLimit", def.aiHomeworkDailyLimit());
        map.put("aiQuizDailyLimit", def.aiQuizDailyLimit());
        map.put("aiMatchDailyLimit", def.aiMatchDailyLimit());
        map.put("priorityBookingMinutes", def.priorityBookingMinutes());
        return map;
    }
}
