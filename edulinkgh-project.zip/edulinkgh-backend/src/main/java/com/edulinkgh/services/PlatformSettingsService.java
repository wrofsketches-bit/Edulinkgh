package com.edulinkgh.services;

import com.edulinkgh.models.PlatformSetting;
import com.edulinkgh.models.User;
import com.edulinkgh.repositories.PlatformSettingRepository;
import com.edulinkgh.repositories.UserRepository;
import org.springframework.stereotype.Service;

import java.util.LinkedHashMap;
import java.util.Map;

@Service
public class PlatformSettingsService {

    private static final String COMMISSION_RATE_KEY = "platform.commissionRatePercent";
    private static final double DEFAULT_COMMISSION_RATE_PERCENT = 10.0;

    private final PlatformSettingRepository settingRepository;
    private final UserRepository userRepository;

    public PlatformSettingsService(PlatformSettingRepository settingRepository, UserRepository userRepository) {
        this.settingRepository = settingRepository;
        this.userRepository = userRepository;
    }

    /** The platform-wide default commission rate, as a percentage (e.g. 10.0 = 10%). */
    public double getGlobalCommissionRatePercent() {
        return settingRepository.findById(COMMISSION_RATE_KEY)
            .map(s -> {
                try {
                    return Double.parseDouble(s.getSettingValue());
                } catch (NumberFormatException e) {
                    return DEFAULT_COMMISSION_RATE_PERCENT;
                }
            })
            .orElse(DEFAULT_COMMISSION_RATE_PERCENT);
    }

    public void setGlobalCommissionRatePercent(double percent) {
        if (percent < 0 || percent > 100) {
            throw new RuntimeException("Commission rate must be between 0 and 100.");
        }
        PlatformSetting setting = settingRepository.findById(COMMISSION_RATE_KEY)
            .orElseGet(() -> new PlatformSetting(COMMISSION_RATE_KEY, "0"));
        setting.setSettingValue(String.valueOf(percent));
        settingRepository.save(setting);
    }

    /**
     * The rate that actually applies to a specific teacher: their own
     * override if one is set, otherwise the platform global. This is the
     * single source of truth PaymentService should call — nothing else
     * should read the global rate or a teacher's override directly.
     */
    public double getEffectiveCommissionRatePercent(User teacher) {
        if (teacher.getCommissionRateOverride() != null) {
            return teacher.getCommissionRateOverride();
        }
        return getGlobalCommissionRatePercent();
    }

    public Map<String, Object> setTeacherOverride(Long teacherId, Double percent) {
        User teacher = userRepository.findById(teacherId)
            .orElseThrow(() -> new RuntimeException("Teacher not found."));
        if (teacher.getRole() != User.Role.TEACHER) {
            throw new RuntimeException("Commission overrides only apply to teacher accounts.");
        }
        if (percent != null && (percent < 0 || percent > 100)) {
            throw new RuntimeException("Commission rate must be between 0 and 100.");
        }
        teacher.setCommissionRateOverride(percent);
        userRepository.save(teacher);

        Map<String, Object> result = new LinkedHashMap<>();
        result.put("teacherId", teacher.getId());
        result.put("commissionRateOverride", teacher.getCommissionRateOverride());
        result.put("effectiveRate", getEffectiveCommissionRatePercent(teacher));
        return result;
    }

    public Map<String, Object> getSettings() {
        Map<String, Object> result = new LinkedHashMap<>();
        result.put("globalCommissionRatePercent", getGlobalCommissionRatePercent());
        return result;
    }
}
