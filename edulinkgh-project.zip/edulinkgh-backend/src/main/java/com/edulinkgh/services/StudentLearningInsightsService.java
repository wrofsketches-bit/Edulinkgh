package com.edulinkgh.services;

import com.edulinkgh.analytics.TimeSeriesBuilder;
import com.edulinkgh.analytics.TimeSeriesBuilder.DataPoint;
import com.edulinkgh.models.Session;
import com.edulinkgh.models.User;
import com.edulinkgh.repositories.SessionRepository;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class StudentLearningInsightsService {

    private final SessionRepository sessionRepository;
    private final UserService userService;

    public StudentLearningInsightsService(SessionRepository sessionRepository, UserService userService) {
        this.sessionRepository = sessionRepository;
        this.userService = userService;
    }

    public Map<String, Object> getInsights(String studentEmail, Integer days) {
        int window = (days != null && days > 0) ? days : 30;
        User student = userService.findByEmail(studentEmail);

        List<Session> completed = sessionRepository.findByEnrolledStudent(student).stream()
            .filter(s -> s.getStatus() == Session.SessionStatus.COMPLETED)
            .collect(Collectors.toList());

        List<DataPoint> sessionsSeries = TimeSeriesBuilder.dailyCounts(
            completed, s -> s.getScheduledAt().toLocalDate(), window
        );

        // "Time spent" is approximated from each session's stated duration —
        // there's no attendance/actual-time-in-session tracking, so this
        // reflects scheduled session length, not verified attendance time.
        int totalMinutes = completed.stream().mapToInt(Session::getDurationMinutes).sum();

        Map<String, Long> subjectCounts = completed.stream()
            .filter(s -> s.getSubject() != null && !s.getSubject().isBlank())
            .collect(Collectors.groupingBy(Session::getSubject, Collectors.counting()));

        List<Map<String, Object>> subjectBreakdown = subjectCounts.entrySet().stream()
            .sorted((a, b) -> Long.compare(b.getValue(), a.getValue()))
            .map(e -> {
                Map<String, Object> entry = new LinkedHashMap<>();
                entry.put("subject", e.getKey());
                entry.put("sessionCount", e.getValue());
                return entry;
            })
            .collect(Collectors.toList());

        // Distinct teachers studied with — a simple breadth-of-learning signal.
        long distinctTeachers = completed.stream().map(s -> s.getTeacher().getId()).distinct().count();

        Map<String, Object> result = new LinkedHashMap<>();
        result.put("windowDays", window);
        result.put("totalSessionsCompleted", completed.size());
        result.put("totalMinutesLearned", totalMinutes);
        result.put("distinctTeachersStudiedWith", distinctTeachers);
        result.put("subjectBreakdown", subjectBreakdown);
        result.put("sessionsSeries", sessionsSeries.stream().map(dp -> {
            Map<String, Object> point = new LinkedHashMap<>();
            point.put("date", dp.date().toString());
            point.put("value", dp.value());
            return point;
        }).collect(Collectors.toList()));
        return result;
    }
}
