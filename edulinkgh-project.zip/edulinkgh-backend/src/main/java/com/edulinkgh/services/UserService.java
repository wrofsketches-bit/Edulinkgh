package com.edulinkgh.services;

import com.edulinkgh.models.User;
import com.edulinkgh.repositories.PaymentRepository;
import com.edulinkgh.repositories.RatingRepository;
import com.edulinkgh.repositories.SessionRepository;
import com.edulinkgh.repositories.UserRepository;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.*;
import java.util.*;

@Service
public class UserService {

    private final UserRepository     userRepository;
    private final RatingRepository   ratingRepository;
    private final SessionRepository  sessionRepository;
    private final PaymentRepository  paymentRepository;
    private final PasswordEncoder    passwordEncoder;

    public UserService(UserRepository userRepository, RatingRepository ratingRepository,
                       SessionRepository sessionRepository, PaymentRepository paymentRepository,
                       PasswordEncoder passwordEncoder) {
        this.userRepository    = userRepository;
        this.ratingRepository  = ratingRepository;
        this.sessionRepository = sessionRepository;
        this.paymentRepository = paymentRepository;
        this.passwordEncoder   = passwordEncoder;
    }

    public Map<String, Object> getProfile(String email) {
        return buildUserMap(findByEmail(email));
    }

    public Map<String, Object> updateProfile(String email, Map<String, String> updates) {
        User user = findByEmail(email);
        if (updates.containsKey("fullName"))      user.setFullName(updates.get("fullName"));
        if (updates.containsKey("phone"))         user.setPhone(updates.get("phone"));
        if (updates.containsKey("bio"))           user.setBio(updates.get("bio"));
        if (updates.containsKey("schoolName"))    user.setSchoolName(updates.get("schoolName"));
        if (updates.containsKey("schoolLevel"))   user.setSchoolLevel(updates.get("schoolLevel"));
        if (updates.containsKey("subject"))       user.setSubject(updates.get("subject"));
        if (updates.containsKey("teachingLevel")) user.setTeachingLevel(updates.get("teachingLevel"));
        if (updates.containsKey("qualification")) user.setQualification(updates.get("qualification"));
        userRepository.save(user);
        return buildUserMap(user);
    }

    public Map<String, String> changePassword(String email, String currentPassword, String newPassword) {
        User user = findByEmail(email);
        if (!passwordEncoder.matches(currentPassword, user.getPassword())) {
            throw new RuntimeException("Current password is incorrect.");
        }
        user.setPassword(passwordEncoder.encode(newPassword));
        userRepository.save(user);
        return Map.of("message", "Password changed successfully.");
    }

    public Map<String, String> uploadCertificate(String email, MultipartFile file) throws IOException {
        User user = findByEmail(email);
        String ext  = getExtension(file.getOriginalFilename());
        String name = UUID.randomUUID() + "." + ext;
        Path uploadPath = Paths.get("uploads/certificates");
        Files.createDirectories(uploadPath);
        Files.copy(file.getInputStream(), uploadPath.resolve(name), StandardCopyOption.REPLACE_EXISTING);
        user.setCertificatePath("uploads/certificates/" + name);
        user.setStatus(User.AccountStatus.PENDING_VERIFICATION);
        userRepository.save(user);
        return Map.of("message", "Certificate uploaded.", "path", name);
    }

    public Map<String, String> uploadProfilePhoto(String email, MultipartFile file) throws IOException {
        User user = findByEmail(email);
        String ext  = getExtension(file.getOriginalFilename());
        String name = "photo_" + user.getId() + "." + ext;
        Path uploadPath = Paths.get("uploads/photos");
        Files.createDirectories(uploadPath);
        Files.copy(file.getInputStream(), uploadPath.resolve(name), StandardCopyOption.REPLACE_EXISTING);
        user.setProfilePhotoPath("uploads/photos/" + name);
        userRepository.save(user);
        return Map.of("message", "Profile photo updated.", "path", name);
    }

    public List<Map<String, Object>> getAllTeachers(String search, String subject,
                                                     String level, Double minRating) {
        List<User> teachers;
        if (search != null && !search.isBlank()) {
            teachers = userRepository.searchTeachers(search);
        } else {
            teachers = userRepository.findByRoleAndStatus(User.Role.TEACHER, User.AccountStatus.ACTIVE);
        }
        return teachers.stream()
            .filter(t -> subject == null || subject.equals("All") ||
                (t.getSubject() != null && t.getSubject().toLowerCase().contains(subject.toLowerCase())))
            .filter(t -> level == null || level.equals("All") ||
                (t.getTeachingLevel() != null && t.getTeachingLevel().contains(level)))
            .filter(t -> {
                if (minRating == null) return true;
                Double avg = ratingRepository.findAverageRatingByTeacher(t);
                return avg != null && avg >= minRating;
            })
            .map(this::buildUserMap)
            .toList();
    }

    public Map<String, Object> getTeacher(Long id) {
        User teacher = userRepository.findById(id)
            .orElseThrow(() -> new RuntimeException("Teacher not found."));
        return buildUserMap(teacher);
    }

    public Map<String, Object> buildUserMap(User user) {
        Double avgRating     = ratingRepository.findAverageRatingByTeacher(user);
        Long   reviewCount   = ratingRepository.countByTeacher(user);
        long   sessionCount  = sessionRepository.findByTeacher(user).size();
        Double totalEarnings = paymentRepository.getTotalEarningsByTeacher(user);

        Map<String, Object> map = new LinkedHashMap<>();
        map.put("id",                   user.getId());
        map.put("fullName",             orEmpty(user.getFullName()));
        map.put("email",                orEmpty(user.getEmail()));
        map.put("phone",                orEmpty(user.getPhone()));
        map.put("role",                 user.getRole() != null ? user.getRole().name() : "");
        map.put("status",               user.getStatus() != null ? user.getStatus().name() : "ACTIVE");
        map.put("schoolName",           orEmpty(user.getSchoolName()));
        map.put("schoolLevel",          orEmpty(user.getSchoolLevel()));
        map.put("subject",              orEmpty(user.getSubject()));
        map.put("teachingLevel",        orEmpty(user.getTeachingLevel()));
        map.put("qualification",        orEmpty(user.getQualification()));
        map.put("bio",                  orEmpty(user.getBio()));
        map.put("qualificationVerified",user.isQualificationVerified());
        map.put("averageRating",        avgRating   != null ? Math.round(avgRating*10.0)/10.0 : 0.0);
        map.put("reviewCount",          reviewCount != null ? reviewCount : 0L);
        map.put("sessionCount",         sessionCount);
        map.put("totalEarnings",        totalEarnings != null ? totalEarnings : 0.0);
        map.put("createdAt",            user.getCreatedAt() != null ? user.getCreatedAt().toString() : "");
        return map;
    }

    public User findByEmail(String email) {
        return userRepository.findByEmail(email)
            .orElseThrow(() -> new RuntimeException("User not found: " + email));
    }

    private String orEmpty(String s) { return s != null ? s : ""; }

    private String getExtension(String filename) {
        if (filename == null || !filename.contains(".")) return "bin";
        return filename.substring(filename.lastIndexOf('.')+1).toLowerCase();
    }
}
