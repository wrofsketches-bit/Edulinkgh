package com.edulinkgh.services;

import com.edulinkgh.ai.AiTutorProvider;
import com.edulinkgh.models.Session;
import com.edulinkgh.models.User;
import com.edulinkgh.repositories.SessionRepository;
import org.springframework.stereotype.Service;

import java.util.LinkedHashMap;
import java.util.Map;

@Service
public class AiLessonSummaryService {

    private final AiTutorProvider provider;
    private final SessionRepository sessionRepository;
    private final UserService userService;

    public AiLessonSummaryService(AiTutorProvider provider, SessionRepository sessionRepository, UserService userService) {
        this.provider = provider;
        this.sessionRepository = sessionRepository;
        this.userService = userService;
    }

    /**
     * Returns the cached topic summary if one already exists; otherwise
     * generates and caches one. Only the session's teacher or an enrolled
     * student may request this — same access model as viewing the session
     * itself.
     */
    public Map<String, Object> getOrGenerateSummary(Long sessionId, String requesterEmail) {
        Session session = sessionRepository.findById(sessionId)
            .orElseThrow(() -> new RuntimeException("Session not found."));

        User requester = userService.findByEmail(requesterEmail);
        boolean isTeacher = session.getTeacher().getId().equals(requester.getId());
        boolean isEnrolledStudent = session.getEnrolledStudents().stream()
            .anyMatch(s -> s.getId().equals(requester.getId()));
        if (!isTeacher && !isEnrolledStudent) {
            throw new RuntimeException("You don't have access to this session.");
        }

        if (session.getTopicSummary() == null || session.getTopicSummary().isBlank()) {
            if (!provider.isAvailable()) {
                throw new RuntimeException("Topic summaries aren't available right now. Please try again later.");
            }
            String summary = provider.generateLessonSummary(session.getSubject(), session.getDescription());
            session.setTopicSummary(summary);
            sessionRepository.save(session);
        }

        Map<String, Object> result = new LinkedHashMap<>();
        result.put("summary", session.getTopicSummary());
        // Framing note surfaced to the client too, not just baked into the
        // prompt — the UI should show this alongside the summary so it's
        // never mistaken for a record of what actually happened in class.
        result.put("disclaimer", "This is a general overview of the topic, not a record of what was covered in this specific session.");
        return result;
    }
}
