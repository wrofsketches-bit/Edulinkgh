package com.edulinkgh.subscriptions;

import com.edulinkgh.models.Subscription;

import java.util.Map;

/**
 * Static plan definitions. FREE has no price (never actually billed —
 * SubscriptionService treats "no active subscription" as FREE by default,
 * so there's rarely even a FREE row in the database except right after an
 * explicit downgrade/cancellation).
 */
public class SubscriptionPlanCatalog {

    public record PlanDefinition(
        Subscription.Plan plan,
        String displayName,
        double priceGhcPerMonth,
        int aiHomeworkDailyLimit,
        int aiQuizDailyLimit,
        int aiMatchDailyLimit,
        int priorityBookingMinutes // how many minutes early this plan can book a newly-opened session, 0 = no priority
    ) {}

    private static final Map<Subscription.Plan, PlanDefinition> PLANS = Map.of(
        Subscription.Plan.FREE, new PlanDefinition(
            Subscription.Plan.FREE, "Free", 0.0,
            30, 15, 10, 0
        ),
        Subscription.Plan.PLUS, new PlanDefinition(
            Subscription.Plan.PLUS, "Plus", 20.0,
            100, 50, 30, 10
        ),
        Subscription.Plan.PRO, new PlanDefinition(
            Subscription.Plan.PRO, "Pro", 45.0,
            1000, 200, 100, 15
        )
    );

    public static PlanDefinition get(Subscription.Plan plan) {
        return PLANS.get(plan);
    }

    public static Map<Subscription.Plan, PlanDefinition> all() {
        return PLANS;
    }
}
