package com.edulinkgh.subscriptions;

import com.edulinkgh.services.SubscriptionService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

/**
 * Flips ACTIVE subscriptions whose expiresAt has passed to EXPIRED. Without
 * this, a lapsed subscriber would keep their elevated AI limits/priority
 * booking forever, since getCurrentPlan() checks BOTH status=ACTIVE and
 * expiresAt in the future — so functionally this job isn't strictly
 * required for correctness (an unexpired-but-past-due row is already
 * treated as FREE by getCurrentPlan()'s own date check), but it keeps the
 * `status` column honest for admin views/reporting that query by status
 * directly rather than going through getCurrentPlan().
 */
@Component
public class SubscriptionExpiryJob {

    private static final Logger log = LoggerFactory.getLogger(SubscriptionExpiryJob.class);

    private final SubscriptionService subscriptionService;

    public SubscriptionExpiryJob(SubscriptionService subscriptionService) {
        this.subscriptionService = subscriptionService;
    }

    @Scheduled(fixedDelay = 60 * 60 * 1000) // hourly
    public void expireOverdueSubscriptions() {
        int expired = subscriptionService.expireOverdueSubscriptions();
        if (expired > 0) {
            log.info("Expired {} overdue subscription(s).", expired);
        }
    }
}
