package com.edulinkgh.models;

import jakarta.persistence.*;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.time.LocalDateTime;

@Entity
@Table(name = "promo_code_redemptions")
@EntityListeners(AuditingEntityListener.class)
public class PromoCodeRedemption {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "promo_code_id", nullable = false)
    private PromoCode promoCode;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    // The specific Payment this redemption was applied to — lets support
    // trace exactly which transaction a discount landed on.
    private Long paymentId;

    private double discountAmountGhc;

    @CreatedDate
    @Column(updatable = false)
    private LocalDateTime redeemedAt;

    public PromoCodeRedemption() {}

    public Long getId()                     { return id; }
    public PromoCode getPromoCode()         { return promoCode; }
    public User getUser()                   { return user; }
    public Long getPaymentId()              { return paymentId; }
    public double getDiscountAmountGhc()    { return discountAmountGhc; }
    public LocalDateTime getRedeemedAt()    { return redeemedAt; }

    public void setId(Long id)                             { this.id = id; }
    public void setPromoCode(PromoCode promoCode)          { this.promoCode = promoCode; }
    public void setUser(User user)                         { this.user = user; }
    public void setPaymentId(Long paymentId)               { this.paymentId = paymentId; }
    public void setDiscountAmountGhc(double amount)        { this.discountAmountGhc = amount; }
    public void setRedeemedAt(LocalDateTime redeemedAt)    { this.redeemedAt = redeemedAt; }
}
