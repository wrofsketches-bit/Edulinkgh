package com.edulinkgh.models;

import jakarta.persistence.*;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.time.LocalDateTime;

/**
 * One row per device a user has logged in on. A user may have several
 * (phone + tablet), so this is not unique on user alone — it's unique on
 * the FCM token itself, since the same physical device always reports the
 * same token until it's refreshed by the OS/Firebase.
 */
@Entity
@Table(name = "device_tokens", uniqueConstraints = @UniqueConstraint(columnNames = "fcm_token"))
@EntityListeners(AuditingEntityListener.class)
public class DeviceToken {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    @Column(name = "fcm_token", nullable = false, unique = true, length = 500)
    private String fcmToken;

    @Enumerated(EnumType.STRING)
    private Platform platform;

    @CreatedDate
    @Column(updatable = false)
    private LocalDateTime createdAt;

    public enum Platform { ANDROID, IOS }

    public DeviceToken() {}

    public Long getId()               { return id; }
    public User getUser()              { return user; }
    public String getFcmToken()       { return fcmToken; }
    public Platform getPlatform()     { return platform; }
    public LocalDateTime getCreatedAt(){ return createdAt; }

    public void setId(Long id)                       { this.id = id; }
    public void setUser(User user)                   { this.user = user; }
    public void setFcmToken(String fcmToken)         { this.fcmToken = fcmToken; }
    public void setPlatform(Platform platform)       { this.platform = platform; }
    public void setCreatedAt(LocalDateTime createdAt){ this.createdAt = createdAt; }
}
