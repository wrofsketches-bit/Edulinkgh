package com.edulinkgh.models;

import jakarta.persistence.*;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.time.LocalDateTime;

@Entity
@Table(name = "ratings",
    uniqueConstraints = @UniqueConstraint(columnNames = {"student_id","teacher_id"}))
@EntityListeners(AuditingEntityListener.class)
public class Rating {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "student_id", nullable = false)
    private User student;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "teacher_id", nullable = false)
    private User teacher;

    @Column(nullable = false)
    private int stars;

    private String comment;

    @CreatedDate
    @Column(updatable = false)
    private LocalDateTime createdAt;

    // ── Constructors ───────────────────────────────────────────────────────
    public Rating() {}

    // ── Getters ────────────────────────────────────────────────────────────
    public Long getId()               { return id; }
    public User getStudent()          { return student; }
    public User getTeacher()          { return teacher; }
    public int getStars()             { return stars; }
    public String getComment()        { return comment; }
    public LocalDateTime getCreatedAt(){ return createdAt; }

    // ── Setters ────────────────────────────────────────────────────────────
    public void setId(Long id)              { this.id = id; }
    public void setStudent(User student)    { this.student = student; }
    public void setTeacher(User teacher)    { this.teacher = teacher; }
    public void setStars(int stars)         { this.stars = stars; }
    public void setComment(String comment)  { this.comment = comment; }
    public void setCreatedAt(LocalDateTime t){ this.createdAt = t; }

    // ── Builder ────────────────────────────────────────────────────────────
    public static Builder builder() { return new Builder(); }

    public static class Builder {
        private final Rating r = new Rating();

        public Builder student(User v)   { r.student = v; return this; }
        public Builder teacher(User v)   { r.teacher = v; return this; }
        public Builder stars(int v)      { r.stars = v; return this; }
        public Builder comment(String v) { r.comment = v; return this; }
        public Rating build()            { return r; }
    }
}
