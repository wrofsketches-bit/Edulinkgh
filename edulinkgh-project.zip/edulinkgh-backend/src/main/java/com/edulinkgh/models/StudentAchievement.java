package com.edulinkgh.models;

import jakarta.persistence.*;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.time.LocalDateTime;

/**
 * A permanent record that a student unlocked a given achievement. The
 * achievement catalog itself (id, title, description, criteria) lives in
 * code (see AchievementCatalog) rather than the database — it's static
 * content, not something that needs runtime configuration, so a DB table
 * for the catalog would be unnecessary indirection. This entity only
 * records the "student X unlocked achievement Y at time Z" fact.
 */
@Entity
@Table(name = "student_achievements", uniqueConstraints = @UniqueConstraint(columnNames = {"student_id", "achievement_id"}))
@EntityListeners(AuditingEntityListener.class)
public class StudentAchievement {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "student_id", nullable = false)
    private User student;

    @Column(name = "achievement_id", nullable = false)
    private String achievementId; // matches an id in AchievementCatalog

    @CreatedDate
    @Column(updatable = false)
    private LocalDateTime unlockedAt;

    public StudentAchievement() {}

    public Long getId()                  { return id; }
    public User getStudent()             { return student; }
    public String getAchievementId()     { return achievementId; }
    public LocalDateTime getUnlockedAt() { return unlockedAt; }

    public void setId(Long id)                          { this.id = id; }
    public void setStudent(User student)                { this.student = student; }
    public void setAchievementId(String achievementId)  { this.achievementId = achievementId; }
    public void setUnlockedAt(LocalDateTime unlockedAt) { this.unlockedAt = unlockedAt; }
}
