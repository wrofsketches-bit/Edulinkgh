package com.edulinkgh.models;

import jakarta.persistence.*;

import java.time.LocalDateTime;

/**
 * A one-time password for the forgot-password flow. Not tied to a User
 * row directly (by email instead) since the code must exist even if we
 * later want to support "email not registered" responses without a leak —
 * though today AuthService still checks the user exists first; see
 * AuthService.forgotPassword for the current tradeoff.
 */
@Entity
@Table(name = "password_reset_otps")
public class PasswordResetOtp {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String email;

    @Column(nullable = false, length = 10)
    private String code;

    @Column(nullable = false)
    private LocalDateTime expiresAt;

    private boolean used = false;

    public PasswordResetOtp() {}

    public Long getId()                { return id; }
    public String getEmail()           { return email; }
    public String getCode()            { return code; }
    public LocalDateTime getExpiresAt(){ return expiresAt; }
    public boolean isUsed()            { return used; }

    public void setId(Long id)                       { this.id = id; }
    public void setEmail(String email)               { this.email = email; }
    public void setCode(String code)                 { this.code = code; }
    public void setExpiresAt(LocalDateTime expiresAt){ this.expiresAt = expiresAt; }
    public void setUsed(boolean used)                { this.used = used; }
}
