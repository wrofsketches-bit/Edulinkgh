package com.edulinkgh.models;

import jakarta.persistence.*;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "sessions")
@EntityListeners(AuditingEntityListener.class)
public class Session {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String subject;

    private String description;

    @Column(nullable = false)
    private LocalDateTime scheduledAt;

    private int durationMinutes;

    @Enumerated(EnumType.STRING)
    private SessionStatus status = SessionStatus.UPCOMING;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "teacher_id", nullable = false)
    private User teacher;

    @ManyToMany
    @JoinTable(
        name = "session_enrollments",
        joinColumns = @JoinColumn(name = "session_id"),
        inverseJoinColumns = @JoinColumn(name = "student_id")
    )
    private List<User> enrolledStudents = new ArrayList<>();

    private String meetingLink;
    private double feeGhc;

    // Cached AI-generated topic overview (see AiTutorProvider.generateLessonSummary).
    // Generated lazily on first request, then reused — regenerating on every
    // view would be wasteful since it's derived purely from subject+description,
    // which don't change after creation in the current flow.
    @Column(columnDefinition = "TEXT")
    private String topicSummary;

    // Video call room, created lazily on first join request — see
    // VideoCallService. Null until someone actually starts a call for this
    // session; providerRoomId/roomCode identify it with whichever
    // VideoCallProvider is active.
    private String videoRoomId;
    private String videoRoomCode;

    @CreatedDate
    @Column(updatable = false)
    private LocalDateTime createdAt;

    public enum SessionStatus { UPCOMING, LIVE, COMPLETED, CANCELLED }

    // ── Constructors ───────────────────────────────────────────────────────
    public Session() {}

    // ── Getters ────────────────────────────────────────────────────────────
    public Long getId()                        { return id; }
    public String getSubject()                 { return subject; }
    public String getDescription()             { return description; }
    public LocalDateTime getScheduledAt()      { return scheduledAt; }
    public int getDurationMinutes()            { return durationMinutes; }
    public SessionStatus getStatus()           { return status; }
    public User getTeacher()                   { return teacher; }
    public List<User> getEnrolledStudents()    { return enrolledStudents; }
    public String getMeetingLink()             { return meetingLink; }
    public double getFeeGhc()                  { return feeGhc; }
    public String getTopicSummary()            { return topicSummary; }
    public String getVideoRoomId()              { return videoRoomId; }
    public String getVideoRoomCode()            { return videoRoomCode; }
    public LocalDateTime getCreatedAt()        { return createdAt; }

    // ── Setters ────────────────────────────────────────────────────────────
    public void setId(Long id)                         { this.id = id; }
    public void setSubject(String subject)             { this.subject = subject; }
    public void setDescription(String description)     { this.description = description; }
    public void setScheduledAt(LocalDateTime t)        { this.scheduledAt = t; }
    public void setDurationMinutes(int d)              { this.durationMinutes = d; }
    public void setStatus(SessionStatus status)        { this.status = status; }
    public void setTeacher(User teacher)               { this.teacher = teacher; }
    public void setEnrolledStudents(List<User> list)   { this.enrolledStudents = list; }
    public void setMeetingLink(String link)            { this.meetingLink = link; }
    public void setFeeGhc(double fee)                  { this.feeGhc = fee; }
    public void setTopicSummary(String s)              { this.topicSummary = s; }
    public void setVideoRoomId(String videoRoomId)      { this.videoRoomId = videoRoomId; }
    public void setVideoRoomCode(String videoRoomCode)  { this.videoRoomCode = videoRoomCode; }
    public void setCreatedAt(LocalDateTime t)          { this.createdAt = t; }

    // ── Builder ────────────────────────────────────────────────────────────
    public static Builder builder() { return new Builder(); }

    public static class Builder {
        private final Session s = new Session();

        public Builder subject(String v)          { s.subject = v; return this; }
        public Builder description(String v)      { s.description = v; return this; }
        public Builder scheduledAt(LocalDateTime v){ s.scheduledAt = v; return this; }
        public Builder durationMinutes(int v)     { s.durationMinutes = v; return this; }
        public Builder status(SessionStatus v)    { s.status = v; return this; }
        public Builder teacher(User v)            { s.teacher = v; return this; }
        public Builder meetingLink(String v)      { s.meetingLink = v; return this; }
        public Builder feeGhc(double v)           { s.feeGhc = v; return this; }
        public Session build()                    { return s; }
    }
}
