package com.edulinkgh.models;

import jakarta.persistence.*;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.time.LocalDateTime;

@Entity
@Table(name = "chat_messages")
@EntityListeners(AuditingEntityListener.class)
public class ChatMessage {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // A conversation is identified by the unordered pair of participant ids,
    // normalized as "min-max" so both sides query the same conversationId.
    @Column(nullable = false)
    private String conversationId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "sender_id", nullable = false)
    private User sender;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "recipient_id", nullable = false)
    private User recipient;

    @Column(length = 2000)
    private String content;

    // Optional file attachment. When present, "content" may be empty (a
    // caption-less file) or hold a caption the user typed alongside it.
    private String attachmentPath;
    private String attachmentFileName;
    private String attachmentMimeType;

    private boolean read = false;

    @CreatedDate
    @Column(updatable = false)
    private LocalDateTime createdAt;

    public ChatMessage() {}

    public static String buildConversationId(Long userA, Long userB) {
        long a = Math.min(userA, userB);
        long b = Math.max(userA, userB);
        return a + "-" + b;
    }

    public Long getId()                     { return id; }
    public String getConversationId()       { return conversationId; }
    public User getSender()                 { return sender; }
    public User getRecipient()               { return recipient; }
    public String getContent()              { return content; }
    public String getAttachmentPath()       { return attachmentPath; }
    public String getAttachmentFileName()   { return attachmentFileName; }
    public String getAttachmentMimeType()   { return attachmentMimeType; }
    public boolean isRead()                 { return read; }
    public LocalDateTime getCreatedAt()      { return createdAt; }

    public void setId(Long id)                          { this.id = id; }
    public void setConversationId(String conversationId) { this.conversationId = conversationId; }
    public void setSender(User sender)                  { this.sender = sender; }
    public void setRecipient(User recipient)             { this.recipient = recipient; }
    public void setContent(String content)              { this.content = content; }
    public void setAttachmentPath(String attachmentPath) { this.attachmentPath = attachmentPath; }
    public void setAttachmentFileName(String attachmentFileName) { this.attachmentFileName = attachmentFileName; }
    public void setAttachmentMimeType(String attachmentMimeType) { this.attachmentMimeType = attachmentMimeType; }
    public void setRead(boolean read)                   { this.read = read; }
    public void setCreatedAt(LocalDateTime createdAt)    { this.createdAt = createdAt; }
}
