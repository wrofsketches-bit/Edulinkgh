package com.edulinkgh.models;

import jakarta.persistence.*;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.time.LocalDateTime;

/**
 * One row per successful referral: referrer entered their code and the
 * referee registered using it. Unique on referee — a given account can only
 * ever have been referred by one person, and only once (registration only
 * happens once per account, so this is naturally enforced, but the
 * constraint documents the intent and guards against any future code path
 * that might try to backfill/re-attribute one).
 */
@Entity
@Table(name = "referrals", uniqueConstraints = @UniqueConstraint(columnNames = "referee_id"))
@EntityListeners(AuditingEntityListener.class)
public class Referral {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "referrer_id", nullable = false)
    private User referrer;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "referee_id", nullable = false)
    private User referee;

    // Whether this referral has already been counted toward the referrer's
    // reward threshold and paid out — see ReferralService. A referral is
    // only ever rewarded once its rewardGranted transitions to true, which
    // happens exactly once (the 80-referral threshold check itself is
    // idempotent because of this flag, not because of any external lock).
    private boolean rewardGranted = false;

    @CreatedDate
    @Column(updatable = false)
    private LocalDateTime createdAt;

    public Referral() {}

    public Long getId()                { return id; }
    public User getReferrer()          { return referrer; }
    public User getReferee()           { return referee; }
    public boolean isRewardGranted()   { return rewardGranted; }
    public LocalDateTime getCreatedAt(){ return createdAt; }

    public void setId(Long id)                        { this.id = id; }
    public void setReferrer(User referrer)            { this.referrer = referrer; }
    public void setReferee(User referee)              { this.referee = referee; }
    public void setRewardGranted(boolean rewardGranted){ this.rewardGranted = rewardGranted; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
}
