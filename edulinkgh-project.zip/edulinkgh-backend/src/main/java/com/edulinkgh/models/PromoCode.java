package com.edulinkgh.models;

import jakarta.persistence.*;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.time.LocalDateTime;

@Entity
@Table(name = "promo_codes")
@EntityListeners(AuditingEntityListener.class)
public class PromoCode {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true)
    private String code; // stored uppercase, matched case-insensitively — see PromoCodeService

    @Column(nullable = false)
    private double percentOff; // e.g. 20.0 = 20% off

    private LocalDateTime expiresAt; // null = never expires

    // Overall cap across all users combined; null = unlimited.
    private Integer maxRedemptions;

    // Cap per individual user; null = unlimited (still subject to maxRedemptions).
    private Integer maxRedemptionsPerUser;

    private boolean active = true;

    @CreatedDate
    @Column(updatable = false)
    private LocalDateTime createdAt;

    public PromoCode() {}

    public Long getId()                        { return id; }
    public String getCode()                    { return code; }
    public double getPercentOff()              { return percentOff; }
    public LocalDateTime getExpiresAt()        { return expiresAt; }
    public Integer getMaxRedemptions()         { return maxRedemptions; }
    public Integer getMaxRedemptionsPerUser()  { return maxRedemptionsPerUser; }
    public boolean isActive()                  { return active; }
    public LocalDateTime getCreatedAt()        { return createdAt; }

    public void setId(Long id)                                   { this.id = id; }
    public void setCode(String code)                             { this.code = code; }
    public void setPercentOff(double percentOff)                 { this.percentOff = percentOff; }
    public void setExpiresAt(LocalDateTime expiresAt)            { this.expiresAt = expiresAt; }
    public void setMaxRedemptions(Integer maxRedemptions)        { this.maxRedemptions = maxRedemptions; }
    public void setMaxRedemptionsPerUser(Integer maxPerUser)     { this.maxRedemptionsPerUser = maxPerUser; }
    public void setActive(boolean active)                        { this.active = active; }
    public void setCreatedAt(LocalDateTime createdAt)            { this.createdAt = createdAt; }
}
