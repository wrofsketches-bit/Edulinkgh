package com.edulinkgh.models;

import jakarta.persistence.*;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.time.LocalDateTime;

@Entity
@Table(name = "ai_homework_questions")
@EntityListeners(AuditingEntityListener.class)
public class AiHomeworkQuestion {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "student_id", nullable = false)
    private User student;

    @Column(nullable = false, length = 2000)
    private String question;

    private String subjectContext;

    @Column(length = 4000)
    private String answer;

    @CreatedDate
    @Column(updatable = false)
    private LocalDateTime createdAt;

    public AiHomeworkQuestion() {}

    public Long getId()                { return id; }
    public User getStudent()           { return student; }
    public String getQuestion()        { return question; }
    public String getSubjectContext()  { return subjectContext; }
    public String getAnswer()          { return answer; }
    public LocalDateTime getCreatedAt(){ return createdAt; }

    public void setId(Long id)                         { this.id = id; }
    public void setStudent(User student)               { this.student = student; }
    public void setQuestion(String question)           { this.question = question; }
    public void setSubjectContext(String subjectContext){ this.subjectContext = subjectContext; }
    public void setAnswer(String answer)               { this.answer = answer; }
    public void setCreatedAt(LocalDateTime createdAt)  { this.createdAt = createdAt; }
}
