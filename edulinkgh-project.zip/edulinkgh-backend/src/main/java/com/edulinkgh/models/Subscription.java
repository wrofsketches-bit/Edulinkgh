package com.edulinkgh.models;

import jakarta.persistence.*;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.time.LocalDateTime;

/**
 * A user's subscription. One row per subscription period — renewing
 * creates a fresh row rather than mutating dates in place, so there's a
 * real history of what was paid for and when (useful for support disputes
 * and for analytics later). "Current" plan for a user is the most recent
 * row with status ACTIVE and expiresAt in the future — see
 * SubscriptionService.getCurrentPlan().
 */
@Entity
@Table(name = "subscriptions")
@EntityListeners(AuditingEntityListener.class)
public class Subscription {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private Plan plan;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private Status status;

    @Column(nullable = false)
    private LocalDateTime startedAt;

    @Column(nullable = false)
    private LocalDateTime expiresAt;

    // Links back to the Payment row that funded this subscription period —
    // null for the free plan (which has no payment) or for admin-granted
    // subscriptions (comped access, etc.).
    private Long paymentId;

    @CreatedDate
    @Column(updatable = false)
    private LocalDateTime createdAt;

    public enum Plan { FREE, PLUS, PRO }
    public enum Status { ACTIVE, EXPIRED, CANCELLED }

    public Subscription() {}

    public Long getId()               { return id; }
    public User getUser()             { return user; }
    public Plan getPlan()             { return plan; }
    public Status getStatus()         { return status; }
    public LocalDateTime getStartedAt() { return startedAt; }
    public LocalDateTime getExpiresAt() { return expiresAt; }
    public Long getPaymentId()        { return paymentId; }
    public LocalDateTime getCreatedAt() { return createdAt; }

    public void setId(Long id)                         { this.id = id; }
    public void setUser(User user)                     { this.user = user; }
    public void setPlan(Plan plan)                     { this.plan = plan; }
    public void setStatus(Status status)               { this.status = status; }
    public void setStartedAt(LocalDateTime startedAt)  { this.startedAt = startedAt; }
    public void setExpiresAt(LocalDateTime expiresAt)  { this.expiresAt = expiresAt; }
    public void setPaymentId(Long paymentId)           { this.paymentId = paymentId; }
    public void setCreatedAt(LocalDateTime createdAt)  { this.createdAt = createdAt; }
}
