package com.edulinkgh.models;

import jakarta.persistence.*;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "users")
@EntityListeners(AuditingEntityListener.class)
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String fullName;

    @Column(nullable = false, unique = true)
    private String email;

    @Column(nullable = false)
    private String password;

    @Column(nullable = false)
    private String phone;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private Role role;

    private String schoolName;
    private String schoolLevel;
    private String subject;
    private String teachingLevel;

    // Optional per-teacher commission rate override, as a percentage (e.g.
    // 8.0 = 8%). Null means "use the platform default" — see
    // PaymentService for how this is resolved. Meaningless for non-teacher
    // users; left null for students/admins.
    private Double commissionRateOverride;
    private String qualification;
    private String certificatePath;
    private String profilePhotoPath;

    // This user's own shareable referral code — generated once at
    // registration (see AuthService), stable for the life of the account.
    @Column(unique = true)
    private String referralCode;
    private String bio;

    @Enumerated(EnumType.STRING)
    private AccountStatus status = AccountStatus.ACTIVE;

    private boolean qualificationVerified = false;

    @CreatedDate
    @Column(updatable = false)
    private LocalDateTime createdAt;

    @LastModifiedDate
    private LocalDateTime updatedAt;

    @OneToMany(mappedBy = "teacher", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<Session> sessions = new ArrayList<>();

    @OneToMany(mappedBy = "teacher", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<Rating> ratingsReceived = new ArrayList<>();

    @OneToMany(mappedBy = "user", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<Payment> payments = new ArrayList<>();

    public enum Role { STUDENT, TEACHER, ADMIN }
    public enum AccountStatus { ACTIVE, SUSPENDED, PENDING_VERIFICATION }

    // ── Constructors ───────────────────────────────────────────────────────
    public User() {}

    // ── Getters ────────────────────────────────────────────────────────────
    public Long getId()                    { return id; }
    public String getFullName()            { return fullName; }
    public String getEmail()               { return email; }
    public String getPassword()            { return password; }
    public String getPhone()               { return phone; }
    public Role getRole()                  { return role; }
    public String getSchoolName()          { return schoolName; }
    public String getSchoolLevel()         { return schoolLevel; }
    public String getSubject()             { return subject; }
    public String getTeachingLevel()       { return teachingLevel; }
    public Double getCommissionRateOverride() { return commissionRateOverride; }
    public String getQualification()       { return qualification; }
    public String getCertificatePath()     { return certificatePath; }
    public String getProfilePhotoPath()    { return profilePhotoPath; }
    public String getReferralCode()        { return referralCode; }
    public String getBio()                 { return bio; }
    public AccountStatus getStatus()       { return status; }
    public boolean isQualificationVerified(){ return qualificationVerified; }
    public LocalDateTime getCreatedAt()    { return createdAt; }
    public LocalDateTime getUpdatedAt()    { return updatedAt; }
    public List<Session> getSessions()     { return sessions; }
    public List<Rating> getRatingsReceived(){ return ratingsReceived; }
    public List<Payment> getPayments()     { return payments; }

    // ── Setters ────────────────────────────────────────────────────────────
    public void setId(Long id)                         { this.id = id; }
    public void setFullName(String fullName)           { this.fullName = fullName; }
    public void setEmail(String email)                 { this.email = email; }
    public void setPassword(String password)           { this.password = password; }
    public void setPhone(String phone)                 { this.phone = phone; }
    public void setRole(Role role)                     { this.role = role; }
    public void setSchoolName(String schoolName)       { this.schoolName = schoolName; }
    public void setSchoolLevel(String schoolLevel)     { this.schoolLevel = schoolLevel; }
    public void setSubject(String subject)             { this.subject = subject; }
    public void setTeachingLevel(String teachingLevel) { this.teachingLevel = teachingLevel; }
    public void setCommissionRateOverride(Double rate) { this.commissionRateOverride = rate; }
    public void setQualification(String qualification) { this.qualification = qualification; }
    public void setCertificatePath(String path)        { this.certificatePath = path; }
    public void setProfilePhotoPath(String path)       { this.profilePhotoPath = path; }
    public void setReferralCode(String referralCode)    { this.referralCode = referralCode; }
    public void setBio(String bio)                     { this.bio = bio; }
    public void setStatus(AccountStatus status)        { this.status = status; }
    public void setQualificationVerified(boolean v)    { this.qualificationVerified = v; }
    public void setCreatedAt(LocalDateTime t)          { this.createdAt = t; }
    public void setUpdatedAt(LocalDateTime t)          { this.updatedAt = t; }

    // ── Builder ────────────────────────────────────────────────────────────
    public static Builder builder() { return new Builder(); }

    public static class Builder {
        private final User user = new User();

        public Builder fullName(String v)            { user.fullName = v; return this; }
        public Builder email(String v)               { user.email = v; return this; }
        public Builder password(String v)            { user.password = v; return this; }
        public Builder phone(String v)               { user.phone = v; return this; }
        public Builder role(Role v)                  { user.role = v; return this; }
        public Builder schoolName(String v)          { user.schoolName = v; return this; }
        public Builder schoolLevel(String v)         { user.schoolLevel = v; return this; }
        public Builder subject(String v)             { user.subject = v; return this; }
        public Builder teachingLevel(String v)       { user.teachingLevel = v; return this; }
        public Builder qualification(String v)       { user.qualification = v; return this; }
        public Builder bio(String v)                 { user.bio = v; return this; }
        public Builder status(AccountStatus v)       { user.status = v; return this; }
        public Builder qualificationVerified(boolean v){ user.qualificationVerified = v; return this; }
        public User build()                          { return user; }
    }
}
