package com.edulinkgh.models;

import jakarta.persistence.*;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.time.LocalDateTime;

@Entity
@Table(name = "payments")
@EntityListeners(AuditingEntityListener.class)
public class Payment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "session_id")
    private Session session;

    @Column(nullable = false)
    private double amountGhc;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private PaymentType type;

    @Enumerated(EnumType.STRING)
    private PaymentStatus status = PaymentStatus.COMPLETED;

    private String reference;
    private String providerReference; // the gateway's own reference (Paystack's, or the mock's) — used to match webhooks/confirms back to this row
    private Long promoCodeId; // set when a promo code was applied to this payment — see PromoCodeService
    private String description;

    @CreatedDate
    @Column(updatable = false)
    private LocalDateTime createdAt;

    public enum PaymentType  { SESSION_FEE, PAYOUT, REFUND, PLATFORM_FEE, SUBSCRIPTION }
    public enum PaymentStatus { PENDING, COMPLETED, FAILED }

    // ── Constructors ───────────────────────────────────────────────────────
    public Payment() {}

    // ── Getters ────────────────────────────────────────────────────────────
    public Long getId()              { return id; }
    public User getUser()            { return user; }
    public Session getSession()      { return session; }
    public double getAmountGhc()     { return amountGhc; }
    public PaymentType getType()     { return type; }
    public PaymentStatus getStatus() { return status; }
    public String getReference()     { return reference; }
    public String getProviderReference() { return providerReference; }
    public Long getPromoCodeId()         { return promoCodeId; }
    public String getDescription()   { return description; }
    public LocalDateTime getCreatedAt(){ return createdAt; }

    // ── Setters ────────────────────────────────────────────────────────────
    public void setId(Long id)                  { this.id = id; }
    public void setUser(User user)              { this.user = user; }
    public void setSession(Session session)     { this.session = session; }
    public void setAmountGhc(double amount)     { this.amountGhc = amount; }
    public void setType(PaymentType type)       { this.type = type; }
    public void setStatus(PaymentStatus status) { this.status = status; }
    public void setReference(String reference)  { this.reference = reference; }
    public void setProviderReference(String providerReference) { this.providerReference = providerReference; }
    public void setPromoCodeId(Long promoCodeId)                { this.promoCodeId = promoCodeId; }
    public void setDescription(String desc)     { this.description = desc; }
    public void setCreatedAt(LocalDateTime t)   { this.createdAt = t; }

    // ── Builder ────────────────────────────────────────────────────────────
    public static Builder builder() { return new Builder(); }

    public static class Builder {
        private final Payment p = new Payment();

        public Builder user(User v)            { p.user = v; return this; }
        public Builder session(Session v)      { p.session = v; return this; }
        public Builder amountGhc(double v)     { p.amountGhc = v; return this; }
        public Builder type(PaymentType v)     { p.type = v; return this; }
        public Builder status(PaymentStatus v) { p.status = v; return this; }
        public Builder reference(String v)     { p.reference = v; return this; }
        public Builder description(String v)   { p.description = v; return this; }
        public Payment build()                 { return p; }
    }
}
