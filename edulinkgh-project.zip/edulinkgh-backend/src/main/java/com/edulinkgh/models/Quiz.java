package com.edulinkgh.models;

import jakarta.persistence.*;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.time.LocalDateTime;

/**
 * A generated quiz. The questions themselves are stored as a JSON blob
 * (questionsJson) rather than a fully normalized Question/Option schema —
 * reasonable for v1 since quizzes are generated wholesale and read back
 * wholesale; a normalized schema would only pay off if individual
 * questions needed to be edited/reused independently later.
 */
@Entity
@Table(name = "quizzes")
@EntityListeners(AuditingEntityListener.class)
public class Quiz {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "created_by_id", nullable = false)
    private User createdBy;

    @Column(nullable = false)
    private String topic;

    private String difficulty;

    @Column(nullable = false, columnDefinition = "TEXT")
    private String questionsJson;

    @CreatedDate
    @Column(updatable = false)
    private LocalDateTime createdAt;

    public Quiz() {}

    public Long getId()                { return id; }
    public User getCreatedBy()         { return createdBy; }
    public String getTopic()           { return topic; }
    public String getDifficulty()      { return difficulty; }
    public String getQuestionsJson()   { return questionsJson; }
    public LocalDateTime getCreatedAt(){ return createdAt; }

    public void setId(Long id)                        { this.id = id; }
    public void setCreatedBy(User createdBy)          { this.createdBy = createdBy; }
    public void setTopic(String topic)                { this.topic = topic; }
    public void setDifficulty(String difficulty)      { this.difficulty = difficulty; }
    public void setQuestionsJson(String questionsJson){ this.questionsJson = questionsJson; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
}
