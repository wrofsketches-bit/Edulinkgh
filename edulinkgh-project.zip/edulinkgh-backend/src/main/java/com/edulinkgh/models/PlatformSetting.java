package com.edulinkgh.models;

import jakarta.persistence.*;

/**
 * A tiny generic key-value store for admin-adjustable settings that need to
 * change at runtime without a redeploy — application.properties can't do
 * that. Currently only holds the platform commission rate
 * ("platform.commissionRate"), but the shape generalizes to any future
 * single-value runtime setting without needing a new table each time.
 *
 * Fields are named settingKey/settingValue rather than key/value — "KEY" is
 * a reserved word in MySQL and would need to be quoted everywhere it's
 * referenced; renaming avoids that fragility entirely rather than relying
 * on Hibernate to auto-quote it correctly in every context.
 */
@Entity
@Table(name = "platform_settings")
public class PlatformSetting {

    @Id
    private String settingKey;

    @Column(nullable = false)
    private String settingValue;

    public PlatformSetting() {}

    public PlatformSetting(String settingKey, String settingValue) {
        this.settingKey = settingKey;
        this.settingValue = settingValue;
    }

    public String getSettingKey()   { return settingKey; }
    public String getSettingValue() { return settingValue; }

    public void setSettingKey(String settingKey)     { this.settingKey = settingKey; }
    public void setSettingValue(String settingValue) { this.settingValue = settingValue; }
}
