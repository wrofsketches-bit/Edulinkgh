package com.edulinkgh.models;

import jakarta.persistence.*;

import java.time.DayOfWeek;
import java.time.LocalTime;

/**
 * A recurring weekly availability window for a teacher, e.g. "Mondays,
 * 14:00–18:00". This is separate from Session — Session is a concrete,
 * bookable slot the teacher has actually created; TeacherAvailability is
 * the general "I'm usually free then" pattern students browse to decide
 * when to ask for a session. Kept intentionally simple (no per-date
 * overrides yet) since that's a reasonable v1 scope for a weekly recurring
 * schedule.
 */
@Entity
@Table(name = "teacher_availability")
public class TeacherAvailability {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "teacher_id", nullable = false)
    private User teacher;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private DayOfWeek dayOfWeek;

    @Column(nullable = false)
    private LocalTime startTime;

    @Column(nullable = false)
    private LocalTime endTime;

    public TeacherAvailability() {}

    public Long getId()              { return id; }
    public User getTeacher()          { return teacher; }
    public DayOfWeek getDayOfWeek()  { return dayOfWeek; }
    public LocalTime getStartTime()  { return startTime; }
    public LocalTime getEndTime()    { return endTime; }

    public void setId(Long id)                     { this.id = id; }
    public void setTeacher(User teacher)           { this.teacher = teacher; }
    public void setDayOfWeek(DayOfWeek dayOfWeek)  { this.dayOfWeek = dayOfWeek; }
    public void setStartTime(LocalTime startTime)  { this.startTime = startTime; }
    public void setEndTime(LocalTime endTime)      { this.endTime = endTime; }
}
