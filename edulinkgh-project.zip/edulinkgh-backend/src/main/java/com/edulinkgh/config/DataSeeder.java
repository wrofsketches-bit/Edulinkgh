package com.edulinkgh.config;

import com.edulinkgh.models.Session;
import com.edulinkgh.models.User;
import com.edulinkgh.repositories.SessionRepository;
import com.edulinkgh.repositories.UserRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;

@Component
public class DataSeeder implements CommandLineRunner {

    private final UserRepository    userRepository;
    private final SessionRepository sessionRepository;
    private final PasswordEncoder   passwordEncoder;

    public DataSeeder(UserRepository userRepository, SessionRepository sessionRepository,
                      PasswordEncoder passwordEncoder) {
        this.userRepository    = userRepository;
        this.sessionRepository = sessionRepository;
        this.passwordEncoder   = passwordEncoder;
    }

    @Override
    public void run(String... args) {
        if (userRepository.count() > 0) return;

        System.out.println("Seeding EduLink GH database...");

        userRepository.save(User.builder()
            .fullName("EduLink Admin").email("admin@edulinkgh.com")
            .password(passwordEncoder.encode("admin123"))
            .phone("0200000000").role(User.Role.ADMIN)
            .status(User.AccountStatus.ACTIVE).build());

        User abena = userRepository.save(User.builder()
            .fullName("Abena Mensah").email("abena.mensah@email.com")
            .password(passwordEncoder.encode("password123"))
            .phone("0241234567").role(User.Role.TEACHER)
            .subject("Mathematics").teachingLevel("JHS/SHS")
            .qualification("BSc Mathematics, UCC")
            .bio("Passionate mathematics educator with 8 years experience.")
            .qualificationVerified(true).status(User.AccountStatus.ACTIVE).build());

        User kwame = userRepository.save(User.builder()
            .fullName("Kwame Asante").email("kwame.asante@email.com")
            .password(passwordEncoder.encode("password123"))
            .phone("0551234567").role(User.Role.TEACHER)
            .subject("Science").teachingLevel("Primary/JHS")
            .qualification("BSc Education (Science), UG")
            .qualificationVerified(true).status(User.AccountStatus.ACTIVE).build());

        User ama = userRepository.save(User.builder()
            .fullName("Ama Osei").email("ama.osei@email.com")
            .password(passwordEncoder.encode("password123"))
            .phone("0271234567").role(User.Role.TEACHER)
            .subject("English").teachingLevel("Primary")
            .qualification("BA English, KNUST")
            .qualificationVerified(true).status(User.AccountStatus.ACTIVE).build());

        User kofi = userRepository.save(User.builder()
            .fullName("Kofi Boateng").email("kofi.boateng@email.com")
            .password(passwordEncoder.encode("password123"))
            .phone("0231234567").role(User.Role.TEACHER)
            .subject("Social Studies").teachingLevel("JHS")
            .qualification("BA Social Studies, UDS")
            .qualificationVerified(true).status(User.AccountStatus.ACTIVE).build());

        userRepository.save(User.builder()
            .fullName("Esi Mensah").email("esi.mensah@email.com")
            .password(passwordEncoder.encode("password123"))
            .phone("0244567890").role(User.Role.STUDENT)
            .schoolName("Achimota School").schoolLevel("JHS")
            .status(User.AccountStatus.ACTIVE).build());

        userRepository.save(User.builder()
            .fullName("Kojo Boateng").email("kojo.boateng@email.com")
            .password(passwordEncoder.encode("password123"))
            .phone("0209876543").role(User.Role.STUDENT)
            .schoolName("Accra Academy").schoolLevel("SHS")
            .status(User.AccountStatus.ACTIVE).build());

        sessionRepository.save(Session.builder()
            .subject("Mathematics")
            .description("Quadratic equations and factorization.")
            .scheduledAt(LocalDateTime.now().plusHours(1))
            .durationMinutes(60).feeGhc(45.00).teacher(abena)
            .status(Session.SessionStatus.LIVE)
            .meetingLink("https://meet.edulinkgh.com/session/1").build());

        sessionRepository.save(Session.builder()
            .subject("English Language")
            .description("Essay writing and comprehension.")
            .scheduledAt(LocalDateTime.now().plusHours(3))
            .durationMinutes(60).feeGhc(40.00).teacher(ama)
            .status(Session.SessionStatus.UPCOMING).build());

        sessionRepository.save(Session.builder()
            .subject("Integrated Science")
            .description("Photosynthesis and the human body systems.")
            .scheduledAt(LocalDateTime.now().plusDays(1).withHour(10))
            .durationMinutes(90).feeGhc(40.00).teacher(kwame)
            .status(Session.SessionStatus.UPCOMING).build());

        sessionRepository.save(Session.builder()
            .subject("Social Studies")
            .description("Ghana's independence and governance.")
            .scheduledAt(LocalDateTime.now().plusDays(1).withHour(14))
            .durationMinutes(60).feeGhc(35.00).teacher(kofi)
            .status(Session.SessionStatus.UPCOMING).build());

        System.out.println("✅ Database seeded!");
        System.out.println("------------------------------------------");
        System.out.println("Admin:   admin@edulinkgh.com   / admin123");
        System.out.println("Teacher: abena.mensah@email.com / password123");
        System.out.println("Student: esi.mensah@email.com   / password123");
        System.out.println("------------------------------------------");
    }
}
