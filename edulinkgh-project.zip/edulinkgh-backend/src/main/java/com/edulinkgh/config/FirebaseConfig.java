package com.edulinkgh.config;

import com.google.auth.oauth2.GoogleCredentials;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;

import java.io.IOException;
import java.io.InputStream;

/**
 * Initializes Firebase Admin SDK for push notifications.
 *
 * REQUIRED SETUP (you do this in the Firebase console, not in code):
 *   1. Create a Firebase project, add an Android app to it.
 *   2. Project Settings > Service Accounts > Generate new private key.
 *      Save the downloaded JSON as src/main/resources/firebase-service-account.json
 *      (this file is gitignored — never commit it).
 *   3. Set app.firebase.enabled=true in application.properties once the
 *      file is in place.
 *
 * Until that file exists, this bean logs a warning and push sending becomes
 * a no-op (PushNotificationService checks FirebaseApp availability before
 * sending) rather than crashing the whole application on startup.
 */
@Configuration
public class FirebaseConfig {

    private static final Logger log = LoggerFactory.getLogger(FirebaseConfig.class);

    private final ResourceLoader resourceLoader;

    @Value("${app.firebase.enabled:false}")
    private boolean firebaseEnabled;

    @Value("${app.firebase.credentials-path:classpath:firebase-service-account.json}")
    private String credentialsPath;

    public FirebaseConfig(ResourceLoader resourceLoader) {
        this.resourceLoader = resourceLoader;
    }

    @Bean
    public FirebaseApp firebaseApp() {
        if (!firebaseEnabled) {
            log.warn("Firebase push notifications are disabled (app.firebase.enabled=false). " +
                     "Set up a service account and enable this to send push notifications.");
            return null;
        }

        try {
            Resource resource = resourceLoader.getResource(credentialsPath);
            if (!resource.exists()) {
                log.warn("Firebase credentials file not found at {}. Push notifications disabled.", credentialsPath);
                return null;
            }

            try (InputStream serviceAccount = resource.getInputStream()) {
                FirebaseOptions options = FirebaseOptions.builder()
                    .setCredentials(GoogleCredentials.fromStream(serviceAccount))
                    .build();

                if (!FirebaseApp.getApps().isEmpty()) {
                    return FirebaseApp.getInstance();
                }
                return FirebaseApp.initializeApp(options);
            }
        } catch (IOException e) {
            log.error("Failed to initialize Firebase — push notifications disabled.", e);
            return null;
        }
    }
}
