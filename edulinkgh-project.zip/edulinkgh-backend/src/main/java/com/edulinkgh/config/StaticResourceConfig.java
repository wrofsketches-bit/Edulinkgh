package com.edulinkgh.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.lang.NonNull;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import java.nio.file.Path;

/**
 * Exposes the local "uploads/" directory (certificates, profile photos, chat
 * attachments) at /uploads/** so the paths already stored on User/ChatMessage
 * (e.g. "uploads/certificates/cert_3.pdf") are actually fetchable by clients.
 * Requires no auth at the HTTP layer here — SecurityConfig permits /uploads/**
 * — since these paths are unguessable-ish IDs, not sensitive by themselves;
 * tighten this later if certificates need to stay private to admins.
 */
@Configuration
public class StaticResourceConfig implements WebMvcConfigurer {

    @Override
    public void addResourceHandlers(@NonNull ResourceHandlerRegistry registry) {
        String uploadsAbsolutePath = Path.of("uploads").toAbsolutePath().toString();
        registry.addResourceHandler("/uploads/**")
            .addResourceLocations("file:" + uploadsAbsolutePath + "/");
    }
}
