package com.edulinkgh.analytics;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.function.Function;
import java.util.function.ToDoubleFunction;

/**
 * Groups a list of items into daily buckets over a trailing window, filling
 * in zero-value days that had no activity (so a chart doesn't show gaps —
 * a day with genuinely zero sessions/revenue should render as a 0 bar, not
 * be silently absent from the series).
 *
 * Deliberately does this in application code rather than a DB-side GROUP BY
 * DATE(...) — the data volumes here (a single tutoring platform's sessions/
 * payments) are small enough that this is simpler and more portable across
 * database engines than relying on MySQL-specific date functions.
 */
public class TimeSeriesBuilder {

    public record DataPoint(LocalDate date, double value) {}

    /**
     * @param items        the raw rows to bucket
     * @param dateOf       extracts the date to bucket each item under
     * @param valueOf      extracts the numeric value to sum per bucket (use x -> 1 for a count)
     * @param days         how many trailing days to include (e.g. 30)
     */
    public static <T> List<DataPoint> dailySeries(List<T> items, Function<T, LocalDate> dateOf,
                                                    ToDoubleFunction<T> valueOf, int days) {
        LocalDate today = LocalDate.now();
        LocalDate start = today.minusDays(days - 1L);

        Map<LocalDate, Double> totals = new HashMap<>();
        for (T item : items) {
            LocalDate date = dateOf.apply(item);
            if (date == null || date.isBefore(start) || date.isAfter(today)) continue;
            totals.merge(date, valueOf.applyAsDouble(item), Double::sum);
        }

        List<DataPoint> series = new ArrayList<>();
        for (long i = 0; i < days; i++) {
            LocalDate date = start.plusDays(i);
            series.add(new DataPoint(date, totals.getOrDefault(date, 0.0)));
        }
        return series;
    }

    /** Convenience for a straight count of items per day (e.g. sessions per day). */
    public static <T> List<DataPoint> dailyCounts(List<T> items, Function<T, LocalDate> dateOf, int days) {
        return dailySeries(items, dateOf, x -> 1.0, days);
    }
}
