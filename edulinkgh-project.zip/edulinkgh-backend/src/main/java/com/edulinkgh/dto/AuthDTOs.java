package com.edulinkgh.dto;

import com.edulinkgh.models.User;
import jakarta.validation.constraints.*;

public class AuthDTOs {

    // ── Register Request ───────────────────────────────────────────────────
    public static class RegisterRequest {
        @NotBlank private String fullName;
        @Email @NotBlank private String email;
        @NotBlank @Size(min = 6) private String password;
        @NotBlank private String phone;
        @NotNull private User.Role role;
        private String schoolName;
        private String schoolLevel;
        private String subject;
        private String teachingLevel;
        private String qualification;
        private String referralCode; // optional — the code of whoever referred this new user, if any

        public RegisterRequest() {}

        public String getFullName()       { return fullName; }
        public String getEmail()          { return email; }
        public String getPassword()       { return password; }
        public String getPhone()          { return phone; }
        public User.Role getRole()        { return role; }
        public String getSchoolName()     { return schoolName; }
        public String getSchoolLevel()    { return schoolLevel; }
        public String getSubject()        { return subject; }
        public String getTeachingLevel()  { return teachingLevel; }
        public String getQualification()  { return qualification; }
        public String getReferralCode()   { return referralCode; }

        public void setFullName(String v)      { this.fullName = v; }
        public void setEmail(String v)         { this.email = v; }
        public void setPassword(String v)      { this.password = v; }
        public void setPhone(String v)         { this.phone = v; }
        public void setRole(User.Role v)       { this.role = v; }
        public void setSchoolName(String v)    { this.schoolName = v; }
        public void setSchoolLevel(String v)   { this.schoolLevel = v; }
        public void setSubject(String v)       { this.subject = v; }
        public void setTeachingLevel(String v) { this.teachingLevel = v; }
        public void setQualification(String v) { this.qualification = v; }
        public void setReferralCode(String v)  { this.referralCode = v; }
    }

    // ── Login Request ──────────────────────────────────────────────────────
    public static class LoginRequest {
        @Email @NotBlank private String email;
        @NotBlank private String password;

        public LoginRequest() {}

        public String getEmail()    { return email; }
        public String getPassword() { return password; }
        public void setEmail(String v)    { this.email = v; }
        public void setPassword(String v) { this.password = v; }
    }

    // ── Auth Response ──────────────────────────────────────────────────────
    public static class AuthResponse {
        private String token;
        private String role;
        private Long userId;
        private String fullName;
        private String email;
        private boolean qualificationVerified;

        public AuthResponse() {}

        public String getToken()               { return token; }
        public String getRole()                { return role; }
        public Long getUserId()                { return userId; }
        public String getFullName()            { return fullName; }
        public String getEmail()               { return email; }
        public boolean isQualificationVerified(){ return qualificationVerified; }

        public void setToken(String v)                  { this.token = v; }
        public void setRole(String v)                   { this.role = v; }
        public void setUserId(Long v)                   { this.userId = v; }
        public void setFullName(String v)               { this.fullName = v; }
        public void setEmail(String v)                  { this.email = v; }
        public void setQualificationVerified(boolean v) { this.qualificationVerified = v; }

        // Builder
        public static Builder builder() { return new Builder(); }
        public static class Builder {
            private final AuthResponse r = new AuthResponse();
            public Builder token(String v)                  { r.token = v; return this; }
            public Builder role(String v)                   { r.role = v; return this; }
            public Builder userId(Long v)                   { r.userId = v; return this; }
            public Builder fullName(String v)               { r.fullName = v; return this; }
            public Builder email(String v)                  { r.email = v; return this; }
            public Builder qualificationVerified(boolean v) { r.qualificationVerified = v; return this; }
            public AuthResponse build()                     { return r; }
        }
    }
}
