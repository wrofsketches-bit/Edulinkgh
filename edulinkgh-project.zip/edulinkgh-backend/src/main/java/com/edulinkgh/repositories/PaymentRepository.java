package com.edulinkgh.repositories;

import com.edulinkgh.models.Payment;
import com.edulinkgh.models.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Repository
public interface PaymentRepository extends JpaRepository<Payment, Long> {
    List<Payment> findByUserOrderByCreatedAtDesc(User user);
    Optional<Payment> findByProviderReference(String providerReference);

    @Query("SELECT p FROM Payment p WHERE p.status = 'PENDING' " +
           "AND p.type = 'SESSION_FEE' AND p.createdAt < :before")
    List<Payment> findStalePendingPayments(@Param("before") LocalDateTime before);

    @Query("SELECT SUM(p.amountGhc) FROM Payment p WHERE p.user = :teacher " +
           "AND p.type = 'SESSION_FEE' AND p.status = 'COMPLETED'")
    Double getTotalEarningsByTeacher(User teacher);

    @Query("SELECT SUM(p.amountGhc) FROM Payment p WHERE p.type = 'SESSION_FEE' " +
           "AND p.status = 'COMPLETED'")
    Double getTotalPlatformRevenue();

    @Query("SELECT COUNT(DISTINCT p.user) FROM Payment p WHERE p.type = 'SESSION_FEE'")
    Long countActiveStudents();

    // Platform commission (PLATFORM_FEE, stored as a negative amountGhc —
    // see PaymentService) since a given date, for revenue-over-time
    // analytics. The negation happens in AdminAnalyticsService, not here.
    @Query("SELECT p FROM Payment p WHERE p.type = 'PLATFORM_FEE' " +
           "AND p.status = 'COMPLETED' AND p.createdAt >= :since")
    List<Payment> findPlatformFeesSince(@Param("since") LocalDateTime since);
}
