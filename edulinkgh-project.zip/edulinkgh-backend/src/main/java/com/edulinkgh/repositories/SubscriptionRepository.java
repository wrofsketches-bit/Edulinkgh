package com.edulinkgh.repositories;

import com.edulinkgh.models.Subscription;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

public interface SubscriptionRepository extends JpaRepository<Subscription, Long> {

    Optional<Subscription> findTopByUser_IdAndStatusOrderByExpiresAtDesc(Long userId, Subscription.Status status);

    List<Subscription> findByUser_IdOrderByCreatedAtDesc(Long userId);

    List<Subscription> findByStatusAndExpiresAtBefore(Subscription.Status status, LocalDateTime cutoff);
}
