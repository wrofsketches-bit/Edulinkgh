package com.edulinkgh.repositories;

import com.edulinkgh.models.Quiz;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDateTime;
import java.util.List;

public interface QuizRepository extends JpaRepository<Quiz, Long> {
    List<Quiz> findByCreatedBy_IdOrderByCreatedAtDesc(Long userId);

    @Query("SELECT COUNT(q) FROM Quiz q WHERE q.createdBy.id = :userId AND q.createdAt > :since")
    long countByCreatorSince(@Param("userId") Long userId, @Param("since") LocalDateTime since);
}
