package com.edulinkgh.repositories;

import com.edulinkgh.models.Rating;
import com.edulinkgh.models.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface RatingRepository extends JpaRepository<Rating, Long> {
    List<Rating> findByTeacher(User teacher);
    List<Rating> findByStudent(User student);
    Optional<Rating> findByStudentAndTeacher(User student, User teacher);
    boolean existsByStudentAndTeacher(User student, User teacher);

    @Query("SELECT AVG(r.stars) FROM Rating r WHERE r.teacher = :teacher")
    Double findAverageRatingByTeacher(User teacher);

    @Query("SELECT COUNT(r) FROM Rating r WHERE r.teacher = :teacher")
    Long countByTeacher(User teacher);
}
