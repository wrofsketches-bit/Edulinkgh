package com.edulinkgh.repositories;

import com.edulinkgh.models.StudentAchievement;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

public interface StudentAchievementRepository extends JpaRepository<StudentAchievement, Long> {
    List<StudentAchievement> findByStudent_IdOrderByUnlockedAtDesc(Long studentId);

    default Set<String> getUnlockedAchievementIds(Long studentId) {
        return findByStudent_IdOrderByUnlockedAtDesc(studentId).stream()
            .map(StudentAchievement::getAchievementId)
            .collect(Collectors.toSet());
    }
}
