package com.edulinkgh.repositories;

import com.edulinkgh.models.AiHomeworkQuestion;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDateTime;
import java.util.List;

public interface AiHomeworkQuestionRepository extends JpaRepository<AiHomeworkQuestion, Long> {

    List<AiHomeworkQuestion> findByStudent_IdOrderByCreatedAtDesc(Long studentId);

    @Query("SELECT COUNT(q) FROM AiHomeworkQuestion q WHERE q.student.id = :studentId AND q.createdAt > :since")
    long countByStudentSince(@Param("studentId") Long studentId, @Param("since") LocalDateTime since);
}
