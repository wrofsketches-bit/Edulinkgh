package com.edulinkgh.repositories;

import com.edulinkgh.models.PromoCodeRedemption;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface PromoCodeRedemptionRepository extends JpaRepository<PromoCodeRedemption, Long> {
    List<PromoCodeRedemption> findByPromoCode_Id(Long promoCodeId);
    List<PromoCodeRedemption> findByPromoCode_IdAndUser_Id(Long promoCodeId, Long userId);
    long countByPromoCode_Id(Long promoCodeId);
    long countByPromoCode_IdAndUser_Id(Long promoCodeId, Long userId);
}
