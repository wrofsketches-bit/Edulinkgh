package com.edulinkgh.repositories;

import com.edulinkgh.models.ChatMessage;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface ChatMessageRepository extends JpaRepository<ChatMessage, Long> {

    List<ChatMessage> findByConversationIdOrderByCreatedAtAsc(String conversationId);

    @Query("SELECT DISTINCT m.conversationId FROM ChatMessage m " +
           "WHERE m.sender.id = :userId OR m.recipient.id = :userId")
    List<String> findConversationIdsForUser(@Param("userId") Long userId);

    long countByConversationIdAndRecipient_IdAndReadFalse(String conversationId, Long recipientId);
}
