package com.edulinkgh.repositories;

import com.edulinkgh.models.Session;
import com.edulinkgh.models.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface SessionRepository extends JpaRepository<Session, Long> {
    List<Session> findByTeacher(User teacher);
    List<Session> findByStatus(Session.SessionStatus status);
    List<Session> findByTeacherAndStatus(User teacher, Session.SessionStatus status);

    @Query("SELECT s FROM Session s JOIN s.enrolledStudents st WHERE st = :student")
    List<Session> findByEnrolledStudent(User student);

    @Query("SELECT s FROM Session s WHERE s.status IN ('UPCOMING','LIVE') ORDER BY s.scheduledAt ASC")
    List<Session> findUpcomingAndLive();

    @Query("SELECT s FROM Session s WHERE s.scheduledAt >= :since")
    List<Session> findScheduledSince(@Param("since") java.time.LocalDateTime since);
}
