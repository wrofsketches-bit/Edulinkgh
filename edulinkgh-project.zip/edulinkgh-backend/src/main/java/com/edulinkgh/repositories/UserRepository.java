package com.edulinkgh.repositories;

import com.edulinkgh.models.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {
    Optional<User> findByEmail(String email);
    Optional<User> findByReferralCode(String referralCode);
    boolean existsByEmail(String email);
    List<User> findByRole(User.Role role);
    List<User> findByRoleAndStatus(User.Role role, User.AccountStatus status);

    @Query("SELECT u FROM User u WHERE u.role = 'TEACHER' AND " +
           "LOWER(u.fullName) LIKE LOWER(CONCAT('%', :query, '%')) OR " +
           "LOWER(u.subject) LIKE LOWER(CONCAT('%', :query, '%'))")
    List<User> searchTeachers(String query);
}
