package com.edulinkgh.repositories;

import com.edulinkgh.models.Referral;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ReferralRepository extends JpaRepository<Referral, Long> {
    List<Referral> findByReferrer_IdOrderByCreatedAtDesc(Long referrerId);
    long countByReferrer_Id(Long referrerId);
    long countByReferrer_IdAndRewardGrantedFalse(Long referrerId);
    boolean existsByReferee_Id(Long refereeId);
}
