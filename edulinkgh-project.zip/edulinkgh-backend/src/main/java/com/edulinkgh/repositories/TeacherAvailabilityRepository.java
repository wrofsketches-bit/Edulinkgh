package com.edulinkgh.repositories;

import com.edulinkgh.models.TeacherAvailability;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface TeacherAvailabilityRepository extends JpaRepository<TeacherAvailability, Long> {
    List<TeacherAvailability> findByTeacher_IdOrderByDayOfWeekAscStartTimeAsc(Long teacherId);
    void deleteByIdAndTeacher_Id(Long id, Long teacherId);
}
