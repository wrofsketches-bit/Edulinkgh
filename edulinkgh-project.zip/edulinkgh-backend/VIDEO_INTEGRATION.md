# Wiring In Real Video Calls (100ms)

The video call system is built against a `VideoCallProvider` interface
(`com.edulinkgh.video.VideoCallProvider`), the same pattern used for
payments (`PaymentProvider`) and AI (`AiTutorProvider`) — so swapping the
mock for real 100ms doesn't touch `VideoCallService`, the controller, or
most of the mobile app.

## 1. Create a 100ms account and app

Sign up at https://dashboard.100ms.live, create an app. You'll get:
- An **App Access Key** and **App Secret** (for server-side room/token management)
- A **Template ID** (100ms's term for a room configuration — roles, layout, etc.)

## 2. Backend: implement HundredMsVideoCallProvider

Create `com.edulinkgh.video.HundredMsVideoCallProvider implements VideoCallProvider`:

- `createRoom(...)` → `POST https://api.100ms.live/v2/rooms` with your
  Management Token (100ms's server-auth JWT, generated from your App
  Access Key + Secret — see their docs for the exact signing algorithm)
  in the `Authorization` header. Store the returned room `id`.
- `generateJoinToken(...)` → `POST https://api.100ms.live/v2/room-codes/room/{roomId}/role/{role}`
  or use their auth-token JWT signing directly (100ms supports both a
  REST call and local JWT generation — check their current docs, this
  changes between SDK versions). Map our `Role.HOST`/`Role.GUEST` to
  whatever role names you configure in your 100ms Template (their roles
  are user-defined, not fixed — you'll set these up in the dashboard).
- `isAvailable()` → true once your App Access Key/Secret are configured.

Add your credentials to `application.properties` the same way OpenAI's key
is handled — via an environment variable, never hardcoded:
```
app.video.hundredms.access-key=${HUNDREDMS_ACCESS_KEY:}
app.video.hundredms.secret=${HUNDREDMS_SECRET:}
app.video.hundredms.template-id=${HUNDREDMS_TEMPLATE_ID:}
```

## 3. Switch the provider

Remove `@Component` from `MockVideoCallProvider` (or delete it) so
`HundredMsVideoCallProvider` is the only implementation Spring finds.

## 4. Mobile: install the real SDK

```
npm install @100mslive/react-native-hms
```

This needs native config (permissions for camera/mic, possibly a config
plugin depending on the current SDK version — check 100ms's React Native
quickstart for the exact steps, since this evolves). **This means plain
Expo Go will no longer work for testing video calls** — you'll need
`expo run:android`/`expo run:ios` or an EAS dev build, the same
requirement already noted for push notifications.

## 5. Replace the placeholder in VideoCallScreen

`src/screens/VideoCallScreen.tsx` currently shows a labeled placeholder
card instead of real video. Replace its render with 100ms's `<HMSView>`
component (or their newer prebuilt UI kit, if you prefer less custom
work), initialized with the `roomId`/`token` already being fetched from
`getVideoCallJoinInfo` — that part doesn't change, since the backend
already hands the mobile app exactly what a real room/token pair needs.

Everything else (access control, room creation, the "who can join"
rules) is already correct and won't need changes.
