# EduLink GH — Backend

## Quick Start

### 1. Make sure MySQL is running (XAMPP or MySQL service)

### 2. Update your MySQL password
Open `src/main/resources/application.properties` and change:
```
spring.datasource.password=your_password_here
```
To your actual MySQL password. If using XAMPP with no password, leave it empty.

### 3. Run the backend
```bash
mvn spring-boot:run
```

### 4. Look for this success message:
```
✅ Database seeded!
Admin:   admin@edulinkgh.com   / admin123
Teacher: abena.mensah@email.com / password123
Student: esi.mensah@email.com   / password123
Tomcat started on port(s): 8080
```

---

## Test Credentials

| Role    | Email                      | Password     |
|---------|----------------------------|--------------|
| Admin   | admin@edulinkgh.com        | admin123     |
| Teacher | abena.mensah@email.com     | password123  |
| Teacher | kwame.asante@email.com     | password123  |
| Teacher | ama.osei@email.com         | password123  |
| Student | esi.mensah@email.com       | password123  |
| Student | kojo.boateng@email.com     | password123  |

---

## API Base URL
http://localhost:8080/api

## Role Access
- Student  → Home dashboard + Find Teachers
- Teacher  → My Sessions dashboard only
- Admin    → Admin panel only
