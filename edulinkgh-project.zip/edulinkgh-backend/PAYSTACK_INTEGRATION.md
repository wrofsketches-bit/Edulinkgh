# Wiring In Real Paystack

The payment system is built against a `PaymentProvider` interface
(`com.edulinkgh.payments.PaymentProvider`) so that swapping the mock
implementation for real Paystack charging doesn't touch `PaymentService`,
`PaymentController`, or the mobile app at all — only a new class and a
couple of deletions.

## 1. Get your Paystack keys

Create a Paystack account, get your **secret key** (starts `sk_test_...` for
test mode, `sk_live_...` once verified) from the Paystack dashboard under
Settings > API Keys & Webhooks.

## 2. Add the secret key to configuration

In `application.properties`:
```
app.payments.paystack.secret-key=sk_test_xxxxxxxxxxxx
```
(Better: pull this from an environment variable in production —
`${PAYSTACK_SECRET_KEY}` — never commit a real key to source control.)

## 3. Implement PaystackPaymentProvider

Create `com.edulinkgh.payments.PaystackPaymentProvider implements PaymentProvider`:

- `initializePayment(...)` → POST to `https://api.paystack.co/transaction/initialize`
  with `email`, `amount` (in **kobo/pesewas — multiply GHC by 100**), and
  `reference` set to your `internalReference`. Paystack returns an
  `authorization_url` — that's your `checkoutUrl` — and its own `reference`
  (Paystack's reference == what you sent, so you can actually just reuse
  `internalReference` as the `providerReference` here, simplifying things).

- `verifyPayment(...)` → GET
  `https://api.paystack.co/transaction/verify/{reference}` with your secret
  key as a Bearer token. Check `data.status == "success"` and
  `data.amount / 100` matches what you expected.

Use Spring's `RestTemplate` or `WebClient` — either is fine, this codebase
doesn't currently use either so pick whichever you're comfortable with.

## 4. Set up the real webhook

Paystack will POST to a webhook URL you configure in their dashboard when a
payment completes — don't rely solely on the client calling `/confirm`,
since a user closing the app mid-checkout would leave the payment stuck
PENDING forever otherwise. Add a `POST /api/payments/webhook/paystack`
endpoint that:

1. Verifies the `x-paystack-signature` header (HMAC-SHA512 of the raw body
   using your secret key — see Paystack's webhook docs for the exact
   algorithm) — **never process a webhook without verifying this signature**,
   or anyone could POST a fake "payment succeeded" event.
2. Calls the same `PaymentService.confirmPayment(reference)` the mobile
   client calls today.

This endpoint needs to be in `SecurityConfig`'s permitAll list (webhooks
don't carry your app's JWT — the signature check IS the authentication) —
add it there, matching the pattern used for the mock endpoints.

## 5. Switch the provider and clean up

- Remove `@Component` from `MockPaymentProvider` (or delete the class
  entirely) so `PaystackPaymentProvider` is the only implementation.
- Delete `MockCheckoutController.java`.
- Remove the `/api/payments/mock-checkout` and `/api/payments/mock-confirm`
  lines from `SecurityConfig`.
- Remove the `otp` field from `AuthService.forgotPassword`'s response if you
  haven't already wired up real email delivery for that separately.

## 6. Mobile side

No changes needed — `initiateSessionPayment`/`confirmPayment` already call
the same endpoints; they'll just return real Paystack checkout URLs instead
of the mock page.
