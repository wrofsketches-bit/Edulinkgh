# EduLinkGH — Rebuilt Project

- **edulinkgh-backend/** — Spring Boot 3.2 API (Java 17, MySQL, JWT auth,
  WebSocket/STOMP chat, Firebase push, OpenAI-backed AI features, Docker/
  Prometheus/structured logging, and swappable provider abstractions for
  payments, AI, and video calling).
- **edulinkgh-mobile/** — React Native (Expo) app for iOS and Android,
  replacing the original JavaFX desktop client.
- **Deployment infrastructure** — `docker-compose.yml`, `Caddyfile`, CI
  workflow — see `DEPLOYMENT.md`.

## 1. Before you do anything: compile-check the backend

**This has not been compiler-verified.** The environment this was built in
has no Maven and no network access to Maven Central, so backend code was
written from careful manual review — checked for structural correctness
(brace/paren balance, package declarations, cross-file method signatures)
but never actually compiled. Run this first:

```
cd edulinkgh-backend
mvn compile
```

The mobile app, by contrast, **is** verified continuously — clean
TypeScript strict-mode typechecks and real Metro bundler exports at every
step of development, right up through this final package. The CI
workflow (`.github/workflows/ci.yml`) will also catch backend compile
errors automatically once pushed to GitHub.

## 2. Read this before deploying: security fixes made along the way

Several real, pre-existing vulnerabilities were found and fixed during
this rebuild (not introduced by it):

- **Password reset was a full account-takeover hole** — anyone knowing a
  user's email could reset their password with zero verification. Now
  uses a real OTP (generated, expiring, single-use). **The OTP is
  currently returned directly in the API response** as a placeholder
  until real email/SMS delivery is wired up — search `AuthService.java`
  for `TODO(you)` and remove that field before going live.
- **The JWT signing secret and database credentials were hardcoded in
  `application.properties`** — anyone with repo access could forge valid
  login tokens for any user, including admins. Now environment-variable
  driven (see `.env.example`); the checked-in fallback is explicitly
  labeled local-dev-only.
- Duplicate session payments and a negative-amount withdrawal exploit —
  both fixed.
- Any user could cancel any other user's session — fixed.
- A teacher's private stats endpoint was accidentally publicly reachable
  due to a broad `permitAll()` pattern catching more than intended —
  fixed, then generalized (`/api/teachers/me/**` → `authenticated()`) so
  the same mistake can't recur for future endpoints in that namespace.
- Several smaller authorization/validation gaps (rating range bounds,
  self-messaging, self-rating, negative promo/commission values, etc.).

## 3. What's implemented

**Core**: JWT auth, registration, forgot/reset password (OTP), dark mode,
glassmorphism-style UI, skeleton loaders.

**Student**: browse/search teachers, weekly availability view, book + pay
for sessions (with promo codes), ratings/reviews, real-time chat
(WebSocket) with file attachments, typing indicators, read receipts, push
notifications, calendar view, streaks & achievements, learning insights,
referral program.

**Teacher**: dashboard with real success statistics and performance
trends over time, create sessions (validated against their own stated
availability, with priority booking windows for subscribers), manage
availability, earnings + withdrawals, calendar view, referral program.

**AI features** (OpenAI-backed, one shared provider abstraction —
`com.edulinkgh.ai.AiTutorProvider`): homework helper with **live
streaming responses** (SSE), quiz generator (validated JSON output),
smart teacher matching (only ranks real teachers from your database),
lesson/topic summaries (clearly labeled as general overviews, not records
of what was taught). Per-feature limits scale with subscription plan.

**Payments**: swappable `PaymentProvider` abstraction with a working mock
implementation (real init → checkout → confirm flow, testable end-to-end
today) plus scheduled reconciliation for stuck payments. See
`edulinkgh-backend/PAYSTACK_INTEGRATION.md` for going live with real
Paystack.

**Monetization**: three-tier subscriptions (Free/Plus/Pro — higher AI
limits, priority booking), percentage-off promo codes (discount comes
from platform revenue, never the teacher's earnings), configurable
commission (global rate + per-teacher overrides), and a referral program
(80 referrals → 1 free day of Plus, reusing the same subscription
mechanism as a real purchase).

**Analytics**: admin revenue/session-volume trends, teacher performance
trends, student learning insights — all real, time-series charts built on
one shared `TimeSeriesBuilder`.

**Video calling**: a full `VideoCallProvider` abstraction and real join
flow (access control, room lifecycle) working end-to-end against a mock
provider today — the actual video *rendering* is a clearly-labeled
placeholder pending a real 100ms account. See
`edulinkgh-backend/VIDEO_INTEGRATION.md`.

**Admin**: platform stats, teacher verification/suspension, student
management, session oversight, manual payouts, payment reconciliation,
promo code management, commission settings.

## 4. Setup required before this fully works

- **Database**: point `application.properties` (or the `DB_*` env vars) at
  your MySQL instance.
- **AI features**: set `OPENAI_API_KEY`. Degrades gracefully without it.
- **Payments**: works today against the mock provider. See
  `PAYSTACK_INTEGRATION.md` when ready to go live.
- **Video calls**: works today (join flow, access control) against the
  mock provider; real video needs a 100ms account. See
  `VIDEO_INTEGRATION.md`.
- **Push notifications**: see `edulinkgh-mobile/PUSH_NOTIFICATIONS_SETUP.md`
  — needs a Firebase project. Everything else works without this.
- **Expo Go limitation**: push notifications and real video calls need a
  real dev build (`expo run:android` / EAS build) — plain Expo Go can't
  support either. Everything else works fine in plain Expo Go.
- **App Store / Play Store submission**: build-ready, not submitted — needs
  your own Apple Developer / Google Play Developer accounts.

## 5. Not yet built

Collaborative whiteboard, screen sharing, SMS notifications, a marketing
landing page. Ask if you want to scope one of these next.

## 6. Running the mobile app

```
cd edulinkgh-mobile
npm install
npx expo start
```

Scan the QR code with Expo Go, or press `a`/`i` for an emulator. Set your
backend's reachable address in `src/api/client.ts` (`API_BASE_URL`) —
`localhost` won't work from a physical device.

## 7. Production deployment (Docker, HTTPS, CI, monitoring)

```
cp .env.example .env
# edit .env — set DB_PASSWORD and JWT_SECRET at minimum
docker compose up -d --build
```

Runs MySQL, the backend, and Caddy (automatic HTTPS reverse proxy) as
three containers — provider-agnostic, runs on any VPS or Docker-capable
host. Includes health checks, Prometheus metrics (authenticated, not
publicly exposed), structured JSON logging, and CI that builds/tests on
every push (not yet wired to auto-deploy — see the comments in
`.github/workflows/ci.yml` for what to add once you pick a host).

**Full guide: `DEPLOYMENT.md`.**

## 8. A note on how this was built

Everything above followed the same discipline throughout: real research
before adding a dependency or calling an external API (never guessed at
a library's shape), a typecheck + bundle-export after every mobile change,
careful manual review of every backend change given the inability to
compile in this environment, and — critically — self-caught mistakes were
fixed immediately rather than left in. Several real bugs (a security hole,
a miscalibrated pricing formula, missing imports, a moved file's broken
relative paths, a MySQL reserved-word collision) were found and corrected
during development, not after. That said: **you should still review this
code before trusting it in production**, especially anywhere money moves.
